//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cxof5gv8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/src/routes/__root.tsx",
		children: [
			"/",
			"/history",
			"/exercises/$exerciseId",
			"/programs/$programId",
			"/session/$workoutId",
			"/workouts/$workoutId",
			"/exercises/",
			"/nutrition/",
			"/programs/",
			"/workouts/",
			"/nutrition/foods/$foodId",
			"/nutrition/foods/"
		],
		css: ["/assets/index-pE5nYxUh.css"],
		preloads: [
			"/assets/index-_xQD0Vlq.js",
			"/assets/link-Cdkys2yX.js",
			"/assets/preload-helper-B32On_yT.js",
			"/assets/exercises._exerciseId-DLuE4YvT.js",
			"/assets/programs._programId-DcjdED_j.js",
			"/assets/session._workoutId-WoNztM4n.js",
			"/assets/workouts._workoutId-CsHZTS_Q.js",
			"/assets/nutrition.foods._foodId-Dot7Bx3L.js",
			"/assets/programs._programId._dayId-BJzMGckj.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-_xQD0Vlq.js"
		} }]
	},
	"/": {
		filePath: "/app/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DF2pI73e.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/chevron-left-D2GhjD3O.js",
			"/assets/flame-2Xm1cGJI.js",
			"/assets/play-P_VZEYN7.js",
			"/assets/plus-Dnm8b8EY.js",
			"/assets/utensils-B0GrCEJP.js"
		]
	},
	"/history": {
		filePath: "/app/src/routes/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-BVSx9m79.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/trash-2-DIUpAkCD.js",
			"/assets/ConfirmSheet-7PRBQJSq.js"
		]
	},
	"/exercises/$exerciseId": {
		filePath: "/app/src/routes/exercises.$exerciseId.tsx",
		children: void 0,
		preloads: [
			"/assets/exercises._exerciseId-BXn9WZ8e.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/arrow-right-CYVhHAb1.js",
			"/assets/check-Bi2RhKHQ.js",
			"/assets/pencil-CTglH7KY.js",
			"/assets/save-D0Fs2SGk.js",
			"/assets/trash-2-DIUpAkCD.js"
		]
	},
	"/programs/$programId": {
		filePath: "/app/src/routes/programs.$programId.tsx",
		children: ["/programs/$programId/$dayId"],
		preloads: [
			"/assets/programs._programId-DJ9IzqQd.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/arrow-right-CYVhHAb1.js",
			"/assets/grip-vertical-DTfzu41i.js",
			"/assets/pencil-CTglH7KY.js",
			"/assets/play-P_VZEYN7.js",
			"/assets/plus-Dnm8b8EY.js",
			"/assets/save-D0Fs2SGk.js",
			"/assets/trash-2-DIUpAkCD.js",
			"/assets/ConfirmSheet-7PRBQJSq.js",
			"/assets/sortable.esm-BG7F_2py.js"
		]
	},
	"/session/$workoutId": {
		filePath: "/app/src/routes/session.$workoutId.tsx",
		children: void 0,
		preloads: [
			"/assets/session._workoutId-DNDSsEaI.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/check-Bi2RhKHQ.js",
			"/assets/chevron-left-D2GhjD3O.js",
			"/assets/copy-Dc66pDK3.js",
			"/assets/Stepper-8P_lumwJ.js",
			"/assets/play-P_VZEYN7.js",
			"/assets/plus-Dnm8b8EY.js",
			"/assets/search-q5c_ZZBZ.js",
			"/assets/ConfirmSheet-7PRBQJSq.js"
		]
	},
	"/workouts/$workoutId": {
		filePath: "/app/src/routes/workouts.$workoutId.tsx",
		children: void 0,
		preloads: [
			"/assets/workouts._workoutId-SaGidrWo.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/arrow-right-CYVhHAb1.js",
			"/assets/grip-vertical-DTfzu41i.js",
			"/assets/Stepper-8P_lumwJ.js",
			"/assets/plus-Dnm8b8EY.js",
			"/assets/trash-2-DIUpAkCD.js"
		]
	},
	"/exercises/": {
		filePath: "/app/src/routes/exercises.index.tsx",
		children: void 0,
		preloads: [
			"/assets/exercises.index-BNMDC_HM.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/chevron-left-D2GhjD3O.js",
			"/assets/plus-Dnm8b8EY.js",
			"/assets/search-q5c_ZZBZ.js",
			"/assets/sliders-horizontal-Cn5T5dmG.js",
			"/assets/sparkles-BdihtG1m.js",
			"/assets/trash-2-DIUpAkCD.js",
			"/assets/ConfirmSheet-7PRBQJSq.js"
		]
	},
	"/nutrition/": {
		filePath: "/app/src/routes/nutrition.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.index-BA32r4H9.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/arrow-left-DBY1RoA7.js",
			"/assets/chevron-left-D2GhjD3O.js",
			"/assets/Stepper-8P_lumwJ.js",
			"/assets/plus-Dnm8b8EY.js",
			"/assets/shuffle-DtA2UPKj.js",
			"/assets/trash-2-DIUpAkCD.js",
			"/assets/utensils-B0GrCEJP.js"
		]
	},
	"/programs/": {
		filePath: "/app/src/routes/programs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/programs.index--q18E-Dl.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/arrow-left-DBY1RoA7.js",
			"/assets/copy-Dc66pDK3.js",
			"/assets/plus-Dnm8b8EY.js",
			"/assets/sparkles-BdihtG1m.js",
			"/assets/trash-2-DIUpAkCD.js",
			"/assets/ConfirmSheet-7PRBQJSq.js"
		]
	},
	"/workouts/": {
		filePath: "/app/src/routes/workouts.index.tsx",
		children: void 0,
		preloads: [
			"/assets/workouts.index-t2Ly3WFj.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js"
		]
	},
	"/nutrition/foods/$foodId": {
		filePath: "/app/src/routes/nutrition.foods.$foodId.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.foods._foodId-RMsBc1Mv.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/arrow-right-CYVhHAb1.js",
			"/assets/check-Bi2RhKHQ.js",
			"/assets/Stepper-8P_lumwJ.js",
			"/assets/shuffle-DtA2UPKj.js",
			"/assets/trash-2-DIUpAkCD.js"
		]
	},
	"/programs/$programId/$dayId": {
		filePath: "/app/src/routes/programs.$programId.$dayId.tsx",
		children: void 0,
		preloads: [
			"/assets/programs._programId._dayId-xe_TW6tQ.js",
			"/assets/flame-2Xm1cGJI.js",
			"/assets/Stepper-8P_lumwJ.js",
			"/assets/search-q5c_ZZBZ.js",
			"/assets/sliders-horizontal-Cn5T5dmG.js"
		]
	},
	"/nutrition/foods/": {
		filePath: "/app/src/routes/nutrition.foods.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.foods.index-J7qR6Nv_.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DMZk8qlw.js",
			"/assets/arrow-right-CYVhHAb1.js",
			"/assets/plus-Dnm8b8EY.js",
			"/assets/search-q5c_ZZBZ.js",
			"/assets/sparkles-BdihtG1m.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
