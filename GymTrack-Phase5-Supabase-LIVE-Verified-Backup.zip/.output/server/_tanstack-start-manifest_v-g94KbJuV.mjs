//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-g94KbJuV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/src/routes/__root.tsx",
		children: [
			"/",
			"/history",
			"/exercises/$exerciseId",
			"/programs/$programId",
			"/session/$workoutId",
			"/workouts/$workoutId",
			"/exercises/",
			"/nutrition/",
			"/programs/",
			"/workouts/",
			"/nutrition/foods/$foodId",
			"/nutrition/foods/"
		],
		css: ["/assets/index-pE5nYxUh.css"],
		preloads: [
			"/assets/index-Cno3l4LC.js",
			"/assets/link-Cdkys2yX.js",
			"/assets/preload-helper-B32On_yT.js",
			"/assets/exercises._exerciseId-YTz0quzb.js",
			"/assets/programs._programId-6V86skL_.js",
			"/assets/session._workoutId-Da3pIrcd.js",
			"/assets/workouts._workoutId-7HNpkZ0x.js",
			"/assets/nutrition.foods._foodId-BLFQ74WM.js",
			"/assets/programs._programId._dayId-BGCF_lFL.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cno3l4LC.js"
		} }]
	},
	"/": {
		filePath: "/app/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DoTm83IX.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/chevron-left-B7FVXN2b.js",
			"/assets/flame-fpgKfivz.js",
			"/assets/play-rCvuXq3G.js",
			"/assets/plus-BaSyDNef.js",
			"/assets/utensils-BPit-_uK.js"
		]
	},
	"/history": {
		filePath: "/app/src/routes/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-aBhOzWfs.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/trash-2-BCYwUQS4.js",
			"/assets/ConfirmSheet-BUAW3wC9.js"
		]
	},
	"/exercises/$exerciseId": {
		filePath: "/app/src/routes/exercises.$exerciseId.tsx",
		children: void 0,
		preloads: [
			"/assets/exercises._exerciseId-DVFs_veN.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/arrow-right-jepyK2DM.js",
			"/assets/check-hp5lHNkx.js",
			"/assets/pencil-CuCr3ixH.js",
			"/assets/save-CfcP_OqX.js",
			"/assets/trash-2-BCYwUQS4.js"
		]
	},
	"/programs/$programId": {
		filePath: "/app/src/routes/programs.$programId.tsx",
		children: ["/programs/$programId/$dayId"],
		preloads: [
			"/assets/programs._programId-DI3tMLu8.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/arrow-right-jepyK2DM.js",
			"/assets/grip-vertical-DK-9atfh.js",
			"/assets/pencil-CuCr3ixH.js",
			"/assets/play-rCvuXq3G.js",
			"/assets/plus-BaSyDNef.js",
			"/assets/save-CfcP_OqX.js",
			"/assets/trash-2-BCYwUQS4.js",
			"/assets/ConfirmSheet-BUAW3wC9.js",
			"/assets/sortable.esm-BG7F_2py.js"
		]
	},
	"/session/$workoutId": {
		filePath: "/app/src/routes/session.$workoutId.tsx",
		children: void 0,
		preloads: [
			"/assets/session._workoutId-BzI_emPp.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/check-hp5lHNkx.js",
			"/assets/chevron-left-B7FVXN2b.js",
			"/assets/copy-BySAeERR.js",
			"/assets/Stepper-DjYnUDQ8.js",
			"/assets/play-rCvuXq3G.js",
			"/assets/plus-BaSyDNef.js",
			"/assets/search-CyKGpUQR.js",
			"/assets/ConfirmSheet-BUAW3wC9.js"
		]
	},
	"/workouts/$workoutId": {
		filePath: "/app/src/routes/workouts.$workoutId.tsx",
		children: void 0,
		preloads: [
			"/assets/workouts._workoutId-0igazDp8.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/arrow-right-jepyK2DM.js",
			"/assets/grip-vertical-DK-9atfh.js",
			"/assets/Stepper-DjYnUDQ8.js",
			"/assets/plus-BaSyDNef.js",
			"/assets/trash-2-BCYwUQS4.js"
		]
	},
	"/exercises/": {
		filePath: "/app/src/routes/exercises.index.tsx",
		children: void 0,
		preloads: [
			"/assets/exercises.index-kunciKGY.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/chevron-left-B7FVXN2b.js",
			"/assets/plus-BaSyDNef.js",
			"/assets/search-CyKGpUQR.js",
			"/assets/sliders-horizontal-Jb3eCrxG.js",
			"/assets/sparkles--kWIXEdw.js",
			"/assets/trash-2-BCYwUQS4.js",
			"/assets/ConfirmSheet-BUAW3wC9.js"
		]
	},
	"/nutrition/": {
		filePath: "/app/src/routes/nutrition.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.index-DHLQSUsl.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/arrow-left-iigH5Asi.js",
			"/assets/chevron-left-B7FVXN2b.js",
			"/assets/Stepper-DjYnUDQ8.js",
			"/assets/plus-BaSyDNef.js",
			"/assets/shuffle-LiIdhWR0.js",
			"/assets/trash-2-BCYwUQS4.js",
			"/assets/utensils-BPit-_uK.js"
		]
	},
	"/programs/": {
		filePath: "/app/src/routes/programs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/programs.index-aPUfd5rh.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/arrow-left-iigH5Asi.js",
			"/assets/copy-BySAeERR.js",
			"/assets/plus-BaSyDNef.js",
			"/assets/sparkles--kWIXEdw.js",
			"/assets/trash-2-BCYwUQS4.js",
			"/assets/ConfirmSheet-BUAW3wC9.js"
		]
	},
	"/workouts/": {
		filePath: "/app/src/routes/workouts.index.tsx",
		children: void 0,
		preloads: [
			"/assets/workouts.index-DmzfRHIM.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js"
		]
	},
	"/nutrition/foods/$foodId": {
		filePath: "/app/src/routes/nutrition.foods.$foodId.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.foods._foodId-CFilU9p1.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/arrow-right-jepyK2DM.js",
			"/assets/check-hp5lHNkx.js",
			"/assets/Stepper-DjYnUDQ8.js",
			"/assets/shuffle-LiIdhWR0.js",
			"/assets/trash-2-BCYwUQS4.js"
		]
	},
	"/programs/$programId/$dayId": {
		filePath: "/app/src/routes/programs.$programId.$dayId.tsx",
		children: void 0,
		preloads: [
			"/assets/programs._programId._dayId-WhnH7Ywz.js",
			"/assets/flame-fpgKfivz.js",
			"/assets/Stepper-DjYnUDQ8.js",
			"/assets/search-CyKGpUQR.js",
			"/assets/sliders-horizontal-Jb3eCrxG.js"
		]
	},
	"/nutrition/foods/": {
		filePath: "/app/src/routes/nutrition.foods.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.foods.index-BCdFkR2r.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-C4Wu9JpU.js",
			"/assets/arrow-right-jepyK2DM.js",
			"/assets/plus-BaSyDNef.js",
			"/assets/search-CyKGpUQR.js",
			"/assets/sparkles--kWIXEdw.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
