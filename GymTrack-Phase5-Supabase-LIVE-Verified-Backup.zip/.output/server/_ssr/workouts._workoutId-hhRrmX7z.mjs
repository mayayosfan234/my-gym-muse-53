import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workouts._workoutId-hhRrmX7z.js
var $$splitComponentImporter = () => import("./workouts._workoutId-BB84MtLC.mjs");
var Route = createFileRoute("/workouts/$workoutId")({
	head: () => ({ meta: [{ title: "עורך אימון — הרוטינה שלי" }, {
		property: "og:title",
		content: "עורך אימון — הרוטינה שלי"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
