import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as History, F as Dumbbell, L as Cloud, R as CircleAlert, S as LogOut, T as LayoutGrid, f as ShieldCheck, k as House, q as Apple, r as User, t as X } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/AppShell-DdWWxz8T.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
/** Soft card with consistent padding + rounded corners. */
function Card({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("surface-card px-4 py-4 text-foreground sm:px-5", className),
		...props,
		children
	});
}
/** Pill / chip — used for tags, filters, status. */
function Pill({ children, variant = "neutral", className, onClick, active }) {
	const styles = {
		neutral: "bg-secondary text-secondary-foreground",
		sage: "bg-rose-soft text-primary",
		rose: "bg-rose-soft text-rose",
		ink: "bg-ink text-primary-foreground",
		cream: "bg-secondary text-ink-soft"
	};
	const interactive = Boolean(onClick);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: interactive ? "button" : void 0,
		onClick,
		"data-active": active ? "true" : void 0,
		className: cn("inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-[11.5px] font-bold transition-colors", active ? "bg-primary text-primary-foreground shadow-sm" : styles[variant], interactive && "press active:scale-95", className),
		children
	});
}
/** Compact icon-only round button — used in headers. */
function IconButton({ className, children, variant = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: cn("grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-transparent transition-all active:scale-95", {
			default: "bg-white/90 border border-border/60 text-ink hover:bg-white shadow-sm",
			primary: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm",
			ghost: "bg-transparent text-ink hover:bg-secondary"
		}[variant], className),
		...props,
		children
	});
}
/** Section header — title + optional action link. */
function SectionHeader({ title, subtitle, action, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("mb-3 flex items-end justify-between gap-3", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 text-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-[18px] font-bold tracking-tight text-ink",
				children: title
			}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-[12.5px] text-muted-foreground",
				children: subtitle
			}) : null]
		}), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0",
			children: action
		}) : null]
	});
}
/** Statistic tile — label + value + icon. */
function StatTile({ label, value, hint, icon: Icon, tone = "sage" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card flex flex-col gap-1 px-3.5 py-3.5 text-start",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("grid h-9 w-9 place-items-center rounded-xl", {
					sage: "bg-rose-soft text-primary",
					rose: "bg-rose-soft text-rose",
					cream: "bg-secondary text-ink-soft",
					ink: "bg-ink text-primary-foreground"
				}[tone]),
				children: Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "h-4 w-4",
					strokeWidth: 2.2
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-[22px] font-bold leading-none tabular-nums text-ink",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11.5px] font-medium leading-tight text-muted-foreground",
				children: label
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-[10.5px] leading-tight text-muted-foreground/80",
				children: hint
			}) : null
		]
	});
}
/** "Empty state" component. */
function EmptyState({ icon: Icon, title, description, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card mx-auto flex max-w-sm flex-col items-center px-6 py-10 text-center",
		children: [
			Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-16 w-16 place-items-center rounded-2xl bg-rose-soft text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "h-7 w-7",
					strokeWidth: 1.8
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 font-display text-[19px] font-bold text-ink",
				children: title
			}),
			description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-[13px] leading-relaxed text-muted-foreground",
				children: description
			}) : null,
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: action
			}) : null
		]
	});
}
/** Big primary CTA button — full-width mobile. */
function PrimaryButton({ className, children, leading, trailing, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: cn("press inline-flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-primary px-5 text-[14.5px] font-bold text-primary-foreground shadow-[0_8px_20px_oklch(0.55_0.16_350/0.25)] hover:bg-primary/90 disabled:opacity-50", className),
		...props,
		children: [
			leading,
			children,
			trailing
		]
	});
}
/** Soft secondary button — full-width mobile. */
function SecondaryButton({ className, children, leading, trailing, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: cn("press inline-flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-secondary px-5 text-[14.5px] font-bold text-secondary-foreground hover:bg-secondary/80 disabled:opacity-50", className),
		...props,
		children: [
			leading,
			children,
			trailing
		]
	});
}
function getEnvVar(key) {
	if (typeof import.meta !== "undefined" && {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBudnR4YXpxdG9yeWxjc2p0YXR2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODcyNTk4MjYsImV4cCI6MjEwMjgzNTgyNn0.L6ZSPRfeJ2EeXw1g7ElIUXHkffF2pjS-4U6qF4EFLAo",
		"VITE_SUPABASE_URL": "https://pnvtxazqtorylcsjtatv.supabase.co"
	}[key]) return {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBudnR4YXpxdG9yeWxjc2p0YXR2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODcyNTk4MjYsImV4cCI6MjEwMjgzNTgyNn0.L6ZSPRfeJ2EeXw1g7ElIUXHkffF2pjS-4U6qF4EFLAo",
		"VITE_SUPABASE_URL": "https://pnvtxazqtorylcsjtatv.supabase.co"
	}[key];
	if (typeof processModule !== "undefined" && processModule.env && processModule.env[key]) return processModule.env[key];
}
var SUPABASE_URL = (getEnvVar("VITE_SUPABASE_URL") || getEnvVar("SUPABASE_URL") || "").replace(/\/rest\/v1\/?$/, "").replace(/\/+$/, "");
var SUPABASE_ANON_KEY = getEnvVar("VITE_SUPABASE_ANON_KEY") || getEnvVar("SUPABASE_ANON_KEY") || "";
var isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY && SUPABASE_URL !== "https://your-project.supabase.co");
var client = null;
if (isSupabaseConfigured) try {
	client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { auth: {
		persistSession: true,
		autoRefreshToken: true,
		detectSessionInUrl: true
	} });
} catch (err) {
	console.error("Failed to initialize Supabase client:", err);
}
var supabase = client;
var MIGRATION_VERSION_KEY = "gymtrack.supabase_migration_version";
var CURRENT_MIGRATION_VER = "1.0";
async function isMigrationNeeded(userId) {
	if (typeof window === "undefined") return false;
	return window.localStorage.getItem(`${MIGRATION_VERSION_KEY}.${userId}`) !== CURRENT_MIGRATION_VER;
}
async function migrateLocalToSupabase(userId, localData) {
	if (!supabase || !isSupabaseConfigured) return {
		success: false,
		error: "Supabase client not configured"
	};
	try {
		const { error: profileErr } = await supabase.from("profiles").upsert({
			id: userId,
			weight: localData.userProfile?.weight ?? 65,
			height: localData.userProfile?.height ?? 165,
			age: localData.userProfile?.age ?? 26,
			gender: localData.userProfile?.gender ?? "female",
			workouts_per_week: localData.userProfile?.workoutsPerWeek ?? 4,
			calories_target: localData.nutritionTargets?.calories ?? 2e3,
			protein_target: localData.nutritionTargets?.protein ?? 140,
			carbs_target: localData.nutritionTargets?.carbs ?? 200,
			fat_target: localData.nutritionTargets?.fat ?? 65,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}, { onConflict: "id" });
		if (profileErr) console.warn("Profile sync warning:", profileErr.message);
		const customExercises = localData.customExercises ?? localData.exercises.filter((e) => e.isCustom);
		for (const ex of customExercises) await supabase.from("custom_exercises").upsert({
			id: ex.id,
			user_id: userId,
			name: ex.name,
			english_name: ex.englishName,
			muscle_group: ex.muscleGroup,
			muscle_groups: ex.muscleGroups ?? [ex.muscleGroup],
			custom_muscle_group: ex.customMuscleGroup,
			secondary_muscles: ex.secondaryMuscles ?? [],
			category: ex.category,
			equipment: ex.equipment,
			description: ex.description,
			instructions: ex.instructions,
			video_url: ex.videoUrl,
			images: ex.images,
			notes: ex.notes,
			tips: ex.tips,
			search_terms: ex.searchTerms ?? []
		});
		for (const day of localData.workouts) await supabase.from("program_days").upsert({
			id: day.id,
			user_id: userId,
			name: day.name,
			notes: day.notes ?? "",
			items: day.items,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		});
		for (const p of localData.programs) await supabase.from("programs").upsert({
			id: p.id,
			user_id: userId,
			name: p.name,
			notes: p.notes ?? "",
			day_ids: p.dayIds,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		});
		for (const s of localData.history) await supabase.from("workout_sessions").upsert({
			id: s.id,
			user_id: userId,
			workout_id: s.workoutId,
			workout_name: s.workoutName,
			program_name: s.programName,
			date: s.date,
			duration_sec: s.durationSec,
			entries: s.entries
		});
		const customFoods = localData.foods.filter((f) => f.isCustom);
		for (const food of customFoods) await supabase.from("custom_foods").upsert({
			id: food.id,
			user_id: userId,
			name: food.name,
			english_name: food.englishName,
			category: food.category,
			brand: food.brand,
			serving_size: food.servingSize,
			unit_weight_grams: food.unitWeightGrams,
			serving_unit_label: food.servingUnitLabel,
			calories: food.calories,
			protein: food.protein,
			carbs: food.carbs,
			fat: food.fat,
			fiber: food.fiber ?? 0,
			notes: food.notes,
			search_terms: food.searchTerms ?? []
		});
		for (const nd of localData.nutritionDays) await supabase.from("nutrition_days").upsert({
			id: `nd-${userId}-${nd.date}`,
			user_id: userId,
			date: nd.date,
			meals: nd.meals
		}, { onConflict: "user_id,date" });
		for (const foodId of localData.favoriteFoods ?? []) await supabase.from("food_favorites").upsert({
			user_id: userId,
			food_id: foodId
		}, { onConflict: "user_id,food_id" });
		if (typeof window !== "undefined") window.localStorage.setItem(`${MIGRATION_VERSION_KEY}.${userId}`, CURRENT_MIGRATION_VER);
		return { success: true };
	} catch (err) {
		const msg = err instanceof Error ? err.message : "Unknown error during cloud migration";
		console.error("Migration error:", msg);
		return {
			success: false,
			error: msg
		};
	}
}
var EXPANDED_EXERCISES = [
	{
		id: "ex-bench",
		name: "לחיצת חזה",
		englishName: "Bench Press",
		muscleGroup: "חזה",
		muscleGroups: [
			"חזה",
			"טריצפס (יד אחורית)",
			"כתף קדמית"
		],
		secondaryMuscles: ["טריצפס (יד אחורית)", "כתפיים"],
		category: "מורכב",
		equipment: "מוט",
		description: "תרגיל הבסיס המוביל לבניית כוח ומסה בחזה.",
		instructions: "שכבי על הספסל, אחזי במוט ברוחב מעט רחב מהכתפיים, הורידי באיטיות אל מרכז החזה ולחצי מעלה בנתיב יציב.",
		videoUrl: "",
		images: [],
		notes: "לשמור על שכמות מכווצות לאחור וקשת קלה בגב התחתון.",
		tips: "ללחוץ דרך העקבים ולשמור על מרפקים בזווית של כ-45 מעלות מהגוף.",
		searchTerms: [
			"בנץ",
			"בנץ פרס",
			"bench",
			"bench press",
			"לחיצה שטוחה",
			"מוט חזה",
			"חזה מוט"
		]
	},
	{
		id: "ex-incline-bench",
		name: "לחיצת חזה בשיפוע חיובי",
		englishName: "Incline Bench Press",
		muscleGroup: "חזה עליון",
		muscleGroups: [
			"חזה עליון",
			"חזה",
			"כתף קדמית",
			"טריצפס (יד אחורית)"
		],
		secondaryMuscles: ["כתף קדמית", "טריצפס (יד אחורית)"],
		category: "מורכב",
		equipment: "משקוליות יד",
		description: "לחיצה בשיפוע חיובי להתמקדות בסיבי החזה העליונים.",
		instructions: "הורידי את המשקוליות בצורה מבוקרת ולחצי מעלה בקו מעוגל קל.",
		videoUrl: "",
		images: [],
		notes: "זווית ספסל אידיאלית היא 30 מעלות למניעת עומס יתר על הכתפיים.",
		tips: "לשמור על מרפקים יציבים.",
		searchTerms: [
			"אינקליין",
			"incline bench",
			"חזה עליון",
			"שיפוע חיובי",
			"incline press"
		]
	},
	{
		id: "ex-db-bench",
		name: "לחיצת חזה עם משקוליות",
		englishName: "Dumbbell Chest Press",
		muscleGroup: "חזה",
		muscleGroups: [
			"חזה",
			"טריצפס (יד אחורית)",
			"כתף קדמית"
		],
		secondaryMuscles: ["טריצפס (יד אחורית)", "כתפיים"],
		category: "מורכב",
		equipment: "משקוליות יד",
		description: "לחיצה יחידנית המאפשרת טווח תנועה מוגדל ועבודה שוויונית על שני צדי החזה.",
		instructions: "הורידי את המשקוליות לצדי החזה תוך מתיחה מלאה, ולחצי מעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לשמור על מרפקים יציבים ולא לנעול בפתאומיות בשיא התנועה.",
		searchTerms: [
			"דאמבל בנץ",
			"dumbbell bench",
			"משקוליות חזה",
			"לחיצת משקוליות שטוחה"
		]
	},
	{
		id: "ex-pec-deck",
		name: "פרפר",
		englishName: "Chest Fly / Pec Deck",
		muscleGroup: "חזה",
		muscleGroups: ["חזה"],
		secondaryMuscles: ["כתף קדמית"],
		category: "בידוד",
		equipment: "מכונה",
		description: "תרגיל בידוד לחזה המעניק מתיחה חזקה ומתח אחיד בשריר החזה.",
		instructions: "שבי צמוד למשענת, אחזי בידיות וקרבי את הזרועות במרכז תוך כיווץ החזה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לכווץ חזק לשנייה אחת בשיא התנועה במרכז.",
		searchTerms: [
			"פק דק",
			"pec deck",
			"butterfly",
			"מכונת פרפר",
			"פרפר כבלים",
			"cable flyes",
			"קרוס אובר"
		]
	},
	{
		id: "ex-pushups",
		name: "שכיבות סמיכה",
		englishName: "Push-Ups",
		muscleGroup: "חזה",
		muscleGroups: [
			"חזה",
			"טריצפס (יד אחורית)",
			"כתף קדמית",
			"בטן"
		],
		secondaryMuscles: ["טריצפס (יד אחורית)", "בטן"],
		category: "מורכב",
		equipment: "משקל גוף",
		description: "תרגיל משקל גוף קלאסי ואפקטיבי לחיזוק החזה, הכתפיים והטריצפס.",
		instructions: "הניחי כפות ידיים מעט רחבות מהכתפיים, רדי עד שהחזה כמעט נוגע ברצפה ולחצי מעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לשמור על גוף ישר בקו אחד (פלאנק) לאורך כל החזרות.",
		searchTerms: [
			"שכיבות סמיכה",
			"pushups",
			"push ups",
			"משקל גוף חזה"
		]
	},
	{
		id: "ex-lat-pulldown",
		name: "פולי עליון",
		englishName: "Lat Pulldown",
		muscleGroup: "גב רחב",
		muscleGroups: [
			"גב רחב",
			"גב",
			"ביצפס (יד קדמית)"
		],
		secondaryMuscles: ["ביצפס (יד קדמית)", "כתף אחורית"],
		category: "מורכב",
		equipment: "פולי / כבלים",
		description: "תרגיל מפתח לפיתוח רוחב הגב בצורה מבוקרת ומותאמת משקל.",
		instructions: "אחזי במוט, שבי יציב ומשכי את המוט לכיוון החזה העליון תוך כיווץ השכמות.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "להקפיד על חזה מורם ולא להישען אחורה מדי.",
		searchTerms: [
			"פולי עליון",
			"lat pulldown",
			"פולי רחב",
			"לאט פולדאון",
			"פולי"
		]
	},
	{
		id: "ex-pullups",
		name: "עליות מתח",
		englishName: "Pull-Ups",
		muscleGroup: "גב",
		muscleGroups: [
			"גב",
			"גב רחב",
			"ביצפס (יד קדמית)"
		],
		secondaryMuscles: ["ביצפס (יד קדמית)", "בטן"],
		category: "מורכב",
		equipment: "משקל גוף",
		description: "תרגיל הבסיס התנועתי הטוב ביותר לפיתוח רוחב הגב והגב הרחב.",
		instructions: "אחזי במוט המתח באחיזה עילית, משכי את החזה אל המוט והורידי באיטיות.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "למשוך דרך המרפקים ולמנוע נדנוד של הגוף.",
		searchTerms: [
			"מתח",
			"pullups",
			"pull ups",
			"עליות מתח",
			"מתח רחב",
			"גרביטרון"
		]
	},
	{
		id: "ex-row",
		name: "חתירה",
		englishName: "Seated Row",
		muscleGroup: "גב",
		muscleGroups: [
			"גב",
			"גב רחב",
			"טרפזים",
			"ביצפס (יד קדמית)"
		],
		secondaryMuscles: ["ביצפס (יד קדמית)", "כתף אחורית"],
		category: "מורכב",
		equipment: "פולי / כבלים",
		description: "חתירה אופקית המעבה את מרכז הגב והשכמות.",
		instructions: "שבי מול הכבל עם ברכיים כפופות קלות, משכי את הידית אל הבטן התחתונה תוך הצמדת השכמות.",
		videoUrl: "",
		images: [],
		notes: "להקפיד לא להשתמש בתנופה מוגזמת של הגב.",
		tips: "למשוך דרך המרפקים ולא דרך כפות הידיים.",
		searchTerms: [
			"חתירה בישיבה",
			"seated row",
			"cable row",
			"פולי תחתונה",
			"חתירה כבלים",
			"חתירה במכונה"
		]
	},
	{
		id: "ex-barbell-row",
		name: "חתירה במוט",
		englishName: "Barbell Row",
		muscleGroup: "גב",
		muscleGroups: [
			"גב",
			"גב רחב",
			"גב תחתון",
			"ביצפס (יד קדמית)"
		],
		secondaryMuscles: ["גב תחתון", "המסטרינג"],
		category: "מורכב",
		equipment: "מוט",
		description: "תרגיל כוח מורכב רב-מפרקי המפתח את עובי וחוזק כל שרירי הגב.",
		instructions: "הטי את הגו קדימה בזווית 45 מעלות עם גב ישר, אחזי במוט ומשכי אל הטבור.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לשמור על גב ישר לחלוטין ולמנוע קשת גבית.",
		searchTerms: [
			"חתירה במוט",
			"barbell row",
			"bent over row",
			"חתירה בהטיית גו"
		]
	},
	{
		id: "ex-db-row",
		name: "חתירה עם משקולת יד",
		englishName: "Single-Arm Dumbbell Row",
		muscleGroup: "גב",
		muscleGroups: [
			"גב",
			"גב רחב",
			"ביצפס (יד קדמית)"
		],
		secondaryMuscles: ["ביצפס (יד קדמית)"],
		category: "מורכב",
		equipment: "משקוליות יד",
		description: "חתירה חד-צדדית המאפשרת מיקוד גבוה בכל צד בנפרד ללא עומס על הגב התחתון.",
		instructions: "הניחי ברך ויד על הספסל, משכי את המשקולת ביד השנייה אל האגן ושחררי במבוקר.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "למשוך את המשקולת לכיוון המותן ולא לכיוון החזה.",
		searchTerms: [
			"חתירה משקולת",
			"db row",
			"single arm row",
			"מסור משקולת"
		]
	},
	{
		id: "ex-hyperextension",
		name: "פשטת גו",
		englishName: "Back Extension",
		muscleGroup: "גב תחתון",
		muscleGroups: [
			"גב תחתון",
			"ישבן",
			"המסטרינג"
		],
		secondaryMuscles: ["ישבן"],
		category: "בידוד",
		equipment: "משקל גוף",
		description: "תרגיל מצוין לחיזוק שרירי הזוקפים בגב התחתון, הישבן וההמסטרינג.",
		instructions: "הניחי ירכיים על הכריות, רדי קדימה בצורה מבוקרת והרמי את הגו חזרה לקו ישר.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לא לפשוט את הגב מעבר לקו ישר בחלק העליון.",
		searchTerms: [
			"פשטת גו",
			"hyperextension",
			"back extension",
			"גב תחתון"
		]
	},
	{
		id: "ex-ohp",
		name: "לחיצת כתפיים",
		englishName: "Shoulder Press",
		muscleGroup: "כתפיים",
		muscleGroups: [
			"כתפיים",
			"כתף קדמית",
			"טריצפס (יד אחורית)"
		],
		secondaryMuscles: ["טריצפס (יד אחורית)", "בטן"],
		category: "מורכב",
		equipment: "משקוליות יד",
		description: "תרגיל הכוח הבסיסי המרכזי לחיזוק ובניית כתפיים חזקות ועגולות.",
		instructions: "שבי או עמדי יציב, אחזי במשקולות/מוט בגובה הכתפיים ולחצי מעלה מעל הראש.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "בטן מהודקת וישבן מכווץ לשמירה על הגב התחתון.",
		searchTerms: [
			"אוברהד פרס",
			"ohp",
			"overhead press",
			"לחיצת כתפיים מוט",
			"פרס",
			"לחיצת כתפיים משקוליות",
			"db shoulder press"
		]
	},
	{
		id: "ex-lateral-raises",
		name: "הרחקת כתפיים",
		englishName: "Lateral Raises",
		muscleGroup: "כתף צדית",
		muscleGroups: ["כתף צדית", "כתפיים"],
		secondaryMuscles: ["טרפזים"],
		category: "בידוד",
		equipment: "משקוליות יד",
		description: "תרגיל המפתח המרכזי המעניק לכתפיים את המראה הרחב והמעוגל.",
		instructions: "עמדי יציב, הרמי את המשקוליות לצדדים בגובה הכתפיים בכפיפה קלה במרפק והורידי באיטיות.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "להרים דרך המרפקים ולא להשתמש בתנופה של הגב.",
		searchTerms: [
			"הרחקת כתפיים",
			"lateral raises",
			"הרחקת זרועות",
			"כתף צדית",
			"הרחקת כתפיים בכבל"
		]
	},
	{
		id: "ex-facepull",
		name: "פייס פול",
		englishName: "Face Pull",
		muscleGroup: "כתף אחורית",
		muscleGroups: [
			"כתף אחורית",
			"טרפזים",
			"גב"
		],
		secondaryMuscles: ["טרפזים"],
		category: "בידוד",
		equipment: "פולי / כבלים",
		description: "תרגיל קריטי לבריאות הכתפיים, היציבה וחיזוק הכתף האחורית.",
		instructions: "אחזי בחבל הפולי העליון, משכי את מרכז החבל לכיוון המצח תוך סיבוב חיצוני של הכתפיים.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "ללכת עד הסוף ולכווץ את כתפיים לאחור.",
		searchTerms: [
			"פייס פול",
			"face pull",
			"facepull",
			"כבלים לפנים",
			"כתף אחורית"
		]
	},
	{
		id: "ex-shrugs-db",
		name: "הרמת שכמות",
		englishName: "Shrugs",
		muscleGroup: "טרפזים",
		muscleGroups: ["טרפזים"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "משקוליות יד",
		description: "תרגיל ממוקד לפיתוח וחיזוק שרירי הטרפזים העליונים.",
		instructions: "החזיקי משקוליות לצדי הירכיים, הרמי שכמות מעלה לכיוון האוזניים, השהי לשנייה והורידי.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "תנועה אנכית ישרה מעלה ומטה בלבד ללא סיבוב כתפיים.",
		searchTerms: [
			"טרפזים",
			"shrugs",
			"הרמת שכמות"
		]
	},
	{
		id: "ex-curl",
		name: "כפיפת מרפקים",
		englishName: "Bicep Curl",
		muscleGroup: "ביצפס (יד קדמית)",
		muscleGroups: ["ביצפס (יד קדמית)", "אמות"],
		secondaryMuscles: ["אמות"],
		category: "בידוד",
		equipment: "משקוליות יד",
		description: "תרגיל היד הקדמית הקלאסי והנפוץ ביותר לפיתוח שרירי הזרוע.",
		instructions: "עמדי יציב, החזיקי משקוליות לצדי הגוף, כפפי את המרפקים והרמי מעלה בצורה מבוקרת.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לשמור על מרפקים צמודים לגוף ולמנוע נדנוד גב.",
		searchTerms: [
			"כפילת מרפקים",
			"כפיפת מרפקים",
			"dumbbell curl",
			"bicep curl",
			"יד קדמית משקוליות",
			"כפילת מוט",
			"ez bar curl"
		]
	},
	{
		id: "ex-hammer-curl",
		name: "כפיפת מרפקים פטישים",
		englishName: "Hammer Curl",
		muscleGroup: "ביצפס (יד קדמית)",
		muscleGroups: ["ביצפס (יד קדמית)", "אמות"],
		secondaryMuscles: ["אמות"],
		category: "בידוד",
		equipment: "משקוליות יד",
		description: "אחיזה ניטרלית (אגודלים מעלה) המפתחת את שריר הברכיאליס ומעבה את הזרוע והאמה.",
		instructions: "החזיקי משקוליות כשאגודלים פונים קדימה, כפפי את הזרוע מעלה ללא סיבוב כף היד.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"פטישים",
			"hammer curl",
			"האמר קרל",
			"אחיזת פטיש"
		]
	},
	{
		id: "ex-preacher-curl",
		name: "כפיפת מרפקים בסקוט",
		englishName: "Preacher Curl",
		muscleGroup: "ביצפס (יד קדמית)",
		muscleGroups: ["ביצפס (יד קדמית)"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "מוט W / EZ",
		description: "תרגיל בידוד קלאסי המונע תנופה של הגוף ומבודד את שיא השריר.",
		instructions: "הניחי את הזרועות על ספסל הסקוט, הורידי את המוט מבוקר ולחצי מעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לא לנעול מרפקים בפתאומיות בתחתית.",
		searchTerms: [
			"ספסל סקוט",
			"preacher curl",
			"פריצ'ר קרל",
			"כפילה בסקוט"
		]
	},
	{
		id: "ex-tricep-pushdown",
		name: "פשיטת מרפקים בפולי",
		englishName: "Tricep Pushdown",
		muscleGroup: "טריצפס (יד אחורית)",
		muscleGroups: ["טריצפס (יד אחורית)"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "פולי / כבלים",
		description: "תרגיל היד האחורית הפופולרי ביותר לעיצוב וחיזוק זרוע אחורית.",
		instructions: "עמדי מול הפולי, דחפי את החבל/המוט מטה עד יישור מרפקים מלא ושחררי במבוקר.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לשמור על מרפקים קבועים וצמודים לצדי הגוף.",
		searchTerms: [
			"פולי חבל",
			"tricep pushdown",
			"rope pushdown",
			"יד אחורית חבל",
			"פשיטת מרפקים בפולי"
		]
	},
	{
		id: "ex-skull-crusher",
		name: "לחיצה צרפתית",
		englishName: "Skull Crusher",
		muscleGroup: "טריצפס (יד אחורית)",
		muscleGroups: ["טריצפס (יד אחורית)"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "מוט W / EZ",
		description: "תרגיל כוח מרכזי ליד האחורית המפעיל חזק את הראש הארוך של השריר.",
		instructions: "שכבי על ספסל, הורידי מוט/משקולות לכיוון המצח בכפיפת מרפקים בלבד ולחצי חזרה מעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לשמור מרפקים פונים מעלה ולא לתת להם לברוח לצדדים.",
		searchTerms: [
			"לחיצה צרפתית",
			"skull crusher",
			"סקאל קראשר",
			"פשטת מרפקים בשכיבה"
		]
	},
	{
		id: "ex-overhead-cable-ext",
		name: "פשיטת מרפקים מעל הראש",
		englishName: "Overhead Triceps Extension",
		muscleGroup: "טריצפס (יד אחורית)",
		muscleGroups: ["טריצפס (יד אחורית)"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "פולי / כבלים",
		description: "מתיחה עמוקה לראש הארוך של הטריצפס מעל הראש.",
		instructions: "אחזי בחבל מעל הראש, כפפי ויישרי את המרפקים מעלה בצורה מבוקרת.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"overhead extension",
			"פולי מעל הראש",
			"יד אחורית מעל הראש"
		]
	},
	{
		id: "ex-squat",
		name: "סקוואט",
		englishName: "Squat",
		muscleGroup: "ארבע ראשי",
		muscleGroups: [
			"ארבע ראשי",
			"ישבן",
			"גב תחתון"
		],
		secondaryMuscles: ["ישבן", "בטן"],
		category: "מורכב",
		equipment: "מוט",
		description: "מלך תרגילי הרגליים — תרגיל הבסיס העוצמתי ביותר לבניית פלג גוף תחתון.",
		instructions: "הניחי את המוט על הטרפזים או אחזי במשקולת מול החזה, רדי עם האגן אחורה ולמטה ולחצי מעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "דחיפה דרך מרכז כף הרגל ושמירה על חזה מורם.",
		searchTerms: [
			"סקוואט",
			"squat",
			"back squat",
			"סקואט מוט",
			"סקוואט על הגב",
			"גובלט סקוואט"
		]
	},
	{
		id: "ex-leg-press",
		name: "לחיצת רגליים",
		englishName: "Leg Press",
		muscleGroup: "ארבע ראשי",
		muscleGroups: ["ארבע ראשי", "ישבן"],
		secondaryMuscles: ["ישבן", "המסטרינג"],
		category: "מכונה",
		equipment: "מכונה",
		description: "תרגיל מורכב במכשיר המאפשר העמסת משקלים בצורה בטיחותית ויציבה.",
		instructions: "שבי במכונה, הניחי כפות רגליים ברוחב כתפיים, שחררי ניצרה ולחצי את המשטח מעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "לא לנעול ברכיים בפתאומיות בחלק העליון.",
		searchTerms: [
			"לחיצת רגליים",
			"leg press",
			"לג פרס",
			"מכונת רגליים"
		]
	},
	{
		id: "ex-leg-extension",
		name: "פשיטת ברך",
		englishName: "Leg Extension",
		muscleGroup: "ארבע ראשי",
		muscleGroups: ["ארבע ראשי"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "מכונה",
		description: "תרגיל הבידוד הבלעדי והמוביל לארבע ראשי לקבלת כיווץ ושריפה בשריר.",
		instructions: "שבי במכונה, יישרי את הברכיים מעלה תוך כיווץ חזק בשיא התנועה לשנייה אחת.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "ירידה איטית ומבוקרת בחלק השלילי.",
		searchTerms: [
			"פשטת ברכיים",
			"פשיטת ברך",
			"leg extension",
			"פשטת ברך",
			"מכונת ארבע ראשי"
		]
	},
	{
		id: "ex-lunges-walking",
		name: "מכרעיים",
		englishName: "Lunges",
		muscleGroup: "ארבע ראשי",
		muscleGroups: [
			"ארבע ראשי",
			"ישבן",
			"המסטרינג"
		],
		secondaryMuscles: ["ישבן"],
		category: "מורכב",
		equipment: "משקוליות יד",
		description: "צעדי מכרעיים המפתחים כוח, יציבות ושיווי משקל ברגליים.",
		instructions: "קחי צעד רחב קדימה, רדי עם הברך האחורית לכיוון הרצפה ולחצי מעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"לאנג'ים",
			"lunges",
			"walking lunges",
			"מכרעיים בהליכה",
			"לאנג'"
		]
	},
	{
		id: "ex-bulgarian-lunge",
		name: "מכרעיים בולגריים",
		englishName: "Bulgarian Split Squat",
		muscleGroup: "ישבן",
		muscleGroups: [
			"ישבן",
			"ארבע ראשי",
			"המסטרינג"
		],
		secondaryMuscles: ["ארבע ראשי"],
		category: "מורכב",
		equipment: "משקוליות יד",
		description: "תרגיל חד-רגלי עוצמתי המבודד ומחזק את הישבן והארבע ראשי בצורה מורגשת.",
		instructions: "הניחי רגל אחת לאחור על ספסל, רדי עם הברך האחורית לכיוון הרצפה ולחצי מעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "הטיית חזה קלה קדימה מחרפת ומגבירה עומס על הישבן.",
		searchTerms: [
			"בולגרי",
			"bulgarian split squat",
			"מכרעיים בולגריים",
			"סקוואט בולגרי"
		]
	},
	{
		id: "ex-rdl",
		name: "דדליפט רומני",
		englishName: "Romanian Deadlift (RDL)",
		muscleGroup: "המסטרינג",
		muscleGroups: [
			"המסטרינג",
			"ישבן",
			"גב תחתון"
		],
		secondaryMuscles: ["ישבן", "גב תחתון"],
		category: "מורכב",
		equipment: "מוט",
		description: "תרגיל המסטרינג וישבן עוצמתי המבוסס על ציר אגן (Hinge) ומתיחה עמוקה.",
		instructions: "אחזי במוט או במשקולות, קחי את האגן אחורנית תוך כפיפה קלה בברכיים והורידי לאורך הרגליים.",
		videoUrl: "",
		images: [],
		notes: "מתיחה מורגשת בהמסטרינג.",
		tips: "גב ישר לחלוטין לאורך כל התנועה.",
		searchTerms: [
			"אר דדליפט",
			"rdl",
			"romanian deadlift",
			"דדליפט רומני",
			"רומניאן"
		]
	},
	{
		id: "ex-lying-leg-curl",
		name: "כפיפת ברך",
		englishName: "Leg Curl",
		muscleGroup: "המסטרינג",
		muscleGroups: ["המסטרינג"],
		secondaryMuscles: ["תאומים"],
		category: "בידוד",
		equipment: "מכונה",
		description: "תרגיל בידוד מרכזי לירך האחורית במכונה בישיבה או בשכיבה.",
		instructions: "כפפי את הברכיים לכיוון הישבן תוך כיווץ חזק של ההמסטרינג ושחררי במבוקר.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"כפילת ברכיים בשכיבה",
			"lying leg curl",
			"לג קרל בשכיבה",
			"כפיפת ברך בישיבה",
			"seated leg curl"
		]
	},
	{
		id: "ex-good-mornings",
		name: "גוד מורנינג",
		englishName: "Good Mornings",
		muscleGroup: "המסטרינג",
		muscleGroups: [
			"המסטרינג",
			"ישבן",
			"גב תחתון"
		],
		secondaryMuscles: ["גב תחתון"],
		category: "מורכב",
		equipment: "מוט",
		description: "תרגיל ציר אגן עם מוט על השכמות המכניס עומס מתיחה חזק להמסטרינג ולגב התחתון.",
		instructions: "הניחי מוט על הטרפזים, כפפי גו קדימה עם גב ישר על ידי דחיפת האגן אחורה, וחזרי לעמידה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: ["good mornings", "גוד מורנינג"]
	},
	{
		id: "ex-hipthrust",
		name: "היפ טראסט",
		englishName: "Hip Thrust",
		muscleGroup: "ישבן",
		muscleGroups: ["ישבן", "המסטרינג"],
		secondaryMuscles: ["המסטרינג", "ארבע ראשי"],
		category: "מורכב",
		equipment: "מוט",
		description: "התרגיל המנצח והיעיל ביותר לבניית כוח, נפח ועיצוב שרירי הישבן.",
		instructions: "הניחי גב עליון על ספסל, מוט/משקולת על האגן, הרמי את האגן מעלה וכווצי את הישבן בשיא הגובה.",
		videoUrl: "",
		images: [],
		notes: "לעצור לשנייה אחת בחלק העליון.",
		tips: "מבט קדימה וכיווץ מלא לשנייה בשיא ההרמה.",
		searchTerms: [
			"היפ טראסט",
			"hip thrust",
			"דחיקת אגן",
			"היפטרסט"
		]
	},
	{
		id: "ex-cable-kickback",
		name: "פשיטת ירך בכבל",
		englishName: "Cable Glute Kickback",
		muscleGroup: "ישבן",
		muscleGroups: ["ישבן"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "פולי / כבלים",
		description: "תרגיל בידוד פופולרי לעיצוב הישבן באמצעות רצועת קרסול בכבלים.",
		instructions: "חברי רצועה לקרסול בפולי התחתון, עמדי מול המכשיר ובעטי את הרגל לאחור תוך כיווץ הישבן.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"קיקבק",
			"glute kickback",
			"פשטת ירך כבלים",
			"בעיטת ישבן"
		]
	},
	{
		id: "ex-hip-abduction-machine",
		name: "הרחקת ירכיים במכונה",
		englishName: "Hip Abduction",
		muscleGroup: "ישבן",
		muscleGroups: ["ישבן"],
		secondaryMuscles: [],
		category: "מכונה",
		equipment: "מכונה",
		description: "מכונת הרחקת ירכיים המיועדת לחיזוק הישבן הצידי.",
		instructions: "שבי במכונה, דחפי את הברכיים כלפי חוץ כנגד הכריות והחזירי באיטיות.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"הרחקת ירכיים",
			"hip abduction",
			"מכונת ישבן צידי"
		]
	},
	{
		id: "ex-standing-calf-raise",
		name: "הרמת עקבים",
		englishName: "Calf Raise",
		muscleGroup: "תאומים",
		muscleGroups: ["תאומים"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "מכונה",
		description: "תרגיל מפתח לפיתוח וחיזוק שרירי התאומים בעמידה או בישיבה.",
		instructions: "עמדי או שבי במכשיר, הורידי את העקבים למתיחה מלאה ולחצי מעלה בשיא הגובה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "עצירה של שנייה בתחתית למתיחה ושנייה בשיא העלייה.",
		searchTerms: [
			"תאומים בעמידה",
			"standing calf raise",
			"הרמת עקבים",
			"seated calf raise",
			"תאומים"
		]
	},
	{
		id: "ex-plank",
		name: "פלאנק",
		englishName: "Plank",
		muscleGroup: "בטן",
		muscleGroups: [
			"בטן",
			"אלכסונים",
			"גב תחתון"
		],
		secondaryMuscles: ["כתפיים"],
		category: "בידוד",
		equipment: "משקל גוף",
		description: "תרגיל ליבה סטאטי מצוין לשמירה על יציבות ואחזקת שרירי הבטן.",
		instructions: "החזיקי גוף ישר על האמות וקצות האצבעות תוך כיווץ חזק של הבטן והישבן.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "גוף בקו ישר יחיד מהראש ועד העקבים.",
		searchTerms: [
			"פלאנק",
			"plank",
			"בטן סטטית"
		]
	},
	{
		id: "ex-crunches",
		name: "כפיפות בטן",
		englishName: "Crunches",
		muscleGroup: "בטן",
		muscleGroups: ["בטן"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "משקל גוף",
		description: "תרגיל בטן בסיסי קלאסי המבודד את השריר הישר הבטני.",
		instructions: "שכבי על הגב, ברכיים כפופות, הרמי את השכמות מהרצפה תוך כיווץ חזק בבטן.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"כפיפות בטן",
			"crunches",
			"בטן קלאסי",
			"כפיפות בטן כבלים",
			"cable crunch"
		]
	},
	{
		id: "ex-hanging-leg-raise",
		name: "הרמת רגליים בתלייה",
		englishName: "Hanging Leg Raise",
		muscleGroup: "בטן",
		muscleGroups: ["בטן", "כופפי הירך"],
		secondaryMuscles: ["אמות"],
		category: "בידוד",
		equipment: "משקל גוף",
		description: "תרגיל בטן מתקדם ואפקטיבי במיוחד לחלק התחתון של שריר הישר הבטני.",
		instructions: "היתלי על מוט מתח, הרמי את הרגליים ישרות או כפופות עד זווית 90 מעלות ומעלה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "למנוע תנופה ונדנוד של הגוף.",
		searchTerms: [
			"הרמת רגליים במתח",
			"hanging leg raise",
			"בטן בתלייה"
		]
	},
	{
		id: "ex-russian-twists",
		name: "פיתולי גו",
		englishName: "Russian Twists",
		muscleGroup: "אלכסונים",
		muscleGroups: ["אלכסונים", "בטן"],
		secondaryMuscles: [],
		category: "בידוד",
		equipment: "משקל גוף",
		description: "תרגיל אלכסונים וסיבוב גו בישיבה לחיזוק שרירי הדופן הצידית.",
		instructions: "שבי עם גו נטוי קלות לאחור, סובבי את כפות הידיים מצד לצד בצורה מבוקרת.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"רושיאן טוויסט",
			"russian twists",
			"פיתולים אלכסונים"
		]
	},
	{
		id: "ex-deadlift",
		name: "דדליפט",
		englishName: "Deadlift",
		muscleGroup: "גוף מלא",
		muscleGroups: [
			"גוף מלא",
			"גב תחתון",
			"המסטרינג",
			"ישבן",
			"גב"
		],
		secondaryMuscles: ["ארבע ראשי", "אמות"],
		category: "מורכב",
		equipment: "מוט",
		description: "תרגיל הכוח המקיף ביותר בגוף האדם המפעיל את השרשרת האחורית במלואה.",
		instructions: "עמדי מול המוט, אחזי ברוחב כתפיים, הרמי את המוט תוך דחיפת הרצפה ויישור האגן והגב.",
		videoUrl: "",
		images: [],
		notes: "גב ישר לחלוטין לאורך כל ההרמה.",
		tips: "",
		searchTerms: [
			"דדליפט",
			"deadlift",
			"conventional deadlift",
			"דדליפט מוט",
			"סומו דדליפט",
			"sumo deadlift"
		]
	},
	{
		id: "ex-kettlebell-swing",
		name: "סווינג עם קטלבל",
		englishName: "Kettlebell Swing",
		muscleGroup: "גוף מלא",
		muscleGroups: [
			"גוף מלא",
			"ישבן",
			"המסטרינג",
			"גב תחתון"
		],
		secondaryMuscles: ["כתפיים"],
		category: "מורכב",
		equipment: "קטלבל",
		description: "תרגיל כוח וסיבולת דינמי ומתפרץ לשרשרת האחורית ולכושר אירובי.",
		instructions: "הניפי את הקטלבל בין הרגליים ודחפי את האגן בעוצמה קדימה להנפת הקטלבל בגובה החזה.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"קטלבל סווינג",
			"kettlebell swing",
			"סווינג קטלבל"
		]
	},
	{
		id: "ex-farmer-walk",
		name: "הליכת איכרים",
		englishName: "Farmer's Walk",
		muscleGroup: "גוף מלא",
		muscleGroups: [
			"גוף מלא",
			"אמות",
			"טרפזים",
			"בטן"
		],
		secondaryMuscles: ["כתפיים"],
		category: "מורכב",
		equipment: "משקוליות יד",
		description: "הליכה עם משקולות כבדות בצדדים לחיזוק אחיזה, כתפיים, טרפזים ויציבות גוף.",
		instructions: "אחזי ב-2 משקולות כבדות, עמדי זקופה והתרכזי בהליכה יציבה בקו ישר.",
		videoUrl: "",
		images: [],
		notes: "",
		tips: "",
		searchTerms: [
			"הליכת איכרים",
			"farmer walk",
			"farmers carry",
			"אחיזה"
		]
	}
];
/** Database of AT LEAST 488 distinct realistic Israeli supermarket food entries */
var ISRAELI_FOOD_DATABASE = [
	{
		id: "f-egg-s",
		name: "ביצה S (קטנה)",
		englishName: "Egg Size S",
		category: "ביצים",
		servingSize: "ביצה 1 (45 גרם)",
		unitWeightGrams: 45,
		servingUnitLabel: "ביצה",
		calories: 63,
		protein: 5.7,
		carbs: .3,
		fat: 4.3,
		fiber: 0,
		searchTerms: [
			"ביצה",
			"egg",
			"egg s",
			"ביצה קטנה"
		]
	},
	{
		id: "f-egg-m",
		name: "ביצה M (בינונית)",
		englishName: "Egg Size M",
		category: "ביצים",
		servingSize: "ביצה 1 (53 גרם)",
		unitWeightGrams: 53,
		servingUnitLabel: "ביצה",
		calories: 74,
		protein: 6.7,
		carbs: .4,
		fat: 5,
		fiber: 0,
		searchTerms: [
			"ביצה",
			"egg",
			"egg m",
			"ביצה בינונית"
		]
	},
	{
		id: "f-egg-l",
		name: "ביצה L (גדולה)",
		englishName: "Egg Size L",
		category: "ביצים",
		servingSize: "ביצה 1 (63 גרם)",
		unitWeightGrams: 63,
		servingUnitLabel: "ביצה",
		calories: 88,
		protein: 8,
		carbs: .5,
		fat: 6,
		fiber: 0,
		searchTerms: [
			"ביצה",
			"egg",
			"egg l",
			"ביצה גדולה"
		]
	},
	{
		id: "f-egg-xl",
		name: "ביצה XL (ענקית)",
		englishName: "Egg Size XL",
		category: "ביצים",
		servingSize: "ביצה 1 (73 גרם)",
		unitWeightGrams: 73,
		servingUnitLabel: "ביצה",
		calories: 102,
		protein: 9.3,
		carbs: .6,
		fat: 7,
		fiber: 0,
		searchTerms: [
			"ביצה",
			"egg",
			"egg xl",
			"ביצה ענקית"
		]
	},
	{
		id: "f-egg-white",
		name: "חלבון ביצה L",
		englishName: "Egg White L",
		category: "ביצים",
		servingSize: "חלבון 1 (35 גרם)",
		unitWeightGrams: 35,
		servingUnitLabel: "חלבון",
		calories: 18,
		protein: 3.8,
		carbs: .2,
		fat: .1,
		fiber: 0,
		searchTerms: [
			"חלבון ביצה",
			"egg white",
			"חלבון"
		]
	},
	{
		id: "f-egg-yolk",
		name: "חלמון ביצה L",
		englishName: "Egg Yolk L",
		category: "ביצים",
		servingSize: "חלמון 1 (20 גרם)",
		unitWeightGrams: 20,
		servingUnitLabel: "חלמון",
		calories: 65,
		protein: 3,
		carbs: .2,
		fat: 5.5,
		fiber: 0,
		searchTerms: [
			"חלמון ביצה",
			"egg yolk",
			"חלמון"
		]
	},
	{
		id: "f-cheese-9",
		name: "גבינה לבנה 9% - תנובה / שטראוס",
		englishName: "White Cheese 9%",
		category: "גבינות",
		brand: "תנובה",
		servingSize: "100 גרם",
		unitWeightGrams: 100,
		servingUnitLabel: "גרם",
		calories: 126,
		protein: 8.5,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		searchTerms: [
			"גבינה 9%",
			"גבינה לבנה 9%",
			"white cheese 9%"
		]
	},
	{
		id: "f-cheese-15",
		name: "גבינה לבנה 15% - תנובה",
		englishName: "White Cheese 15%",
		category: "גבינות",
		brand: "תנובה",
		servingSize: "100 גרם",
		unitWeightGrams: 100,
		servingUnitLabel: "גרם",
		calories: 178,
		protein: 7.5,
		carbs: 1.5,
		fat: 15,
		fiber: 0,
		searchTerms: [
			"גבינה 15%",
			"גבינה לבנה 15%",
			"white cheese 15%"
		]
	},
	{
		id: "f-cheese-yellow-28",
		name: "גבינה צהובה 28% (עמק תנובה)",
		englishName: "Yellow Cheese 28%",
		category: "גבינות",
		brand: "תנובה",
		servingSize: "פרוסה (30 גרם)",
		unitWeightGrams: 30,
		servingUnitLabel: "פרוסה",
		calories: 105,
		protein: 7.5,
		carbs: .2,
		fat: 8.4,
		fiber: 0,
		searchTerms: [
			"גבינה צהובה 28%",
			"עמק 28%",
			"גבינה 28%",
			"yellow cheese 28%"
		]
	},
	{
		id: "f-cheese-yellow-15",
		name: "גבינה צהובה 15% (עמק לייט)",
		englishName: "Yellow Cheese 15%",
		category: "גבינות",
		brand: "תנובה",
		servingSize: "פרוסה (30 גרם)",
		unitWeightGrams: 30,
		servingUnitLabel: "פרוסה",
		calories: 78,
		protein: 8.7,
		carbs: .2,
		fat: 4.5,
		fiber: 0,
		searchTerms: [
			"גבינה צהובה 15%",
			"עמק 15%",
			"גבינה 15%"
		]
	},
	{
		id: "f-cheese-yellow-9",
		name: "גבינה צהובה 9% (נעם לייט - טרה)",
		englishName: "Yellow Cheese 9%",
		category: "גבינות",
		brand: "טרה",
		servingSize: "פרוסה (30 גרם)",
		unitWeightGrams: 30,
		servingUnitLabel: "פרוסה",
		calories: 60,
		protein: 9.3,
		carbs: .2,
		fat: 2.7,
		fiber: 0,
		searchTerms: [
			"גבינה צהובה 9%",
			"נעם 9%",
			"גבינה 9%"
		]
	},
	{
		id: "f-pita-standard",
		name: "פיתה רגילה",
		englishName: "Standard Pita",
		category: "לחמים",
		servingSize: "פיתה 1 (100 גרם)",
		unitWeightGrams: 100,
		servingUnitLabel: "פיתה",
		calories: 265,
		protein: 9,
		carbs: 55,
		fat: 1,
		fiber: 2.5,
		searchTerms: ["פיתה", "pita"]
	},
	{
		id: "f-pita-whole",
		name: "פיתה מקמח מלא",
		englishName: "Whole Wheat Pita",
		category: "לחמים",
		servingSize: "פיתה 1 (90 גרם)",
		unitWeightGrams: 90,
		servingUnitLabel: "פיתה",
		calories: 220,
		protein: 9.5,
		carbs: 45,
		fat: 1.5,
		fiber: 6,
		searchTerms: [
			"פיתה מלאה",
			"פיתה קמח מלא",
			"whole pita"
		]
	},
	{
		id: "f-bread-white",
		name: "פרוסת לחם אחיד",
		englishName: "Standard Bread Slice",
		category: "לחמים",
		servingSize: "פרוסה 1 (30 גרם)",
		unitWeightGrams: 30,
		servingUnitLabel: "פרוסה",
		calories: 75,
		protein: 2.5,
		carbs: 14.5,
		fat: .8,
		fiber: 1,
		searchTerms: [
			"לחם אחיד",
			"לחם",
			"bread"
		]
	},
	{
		id: "f-bread-light",
		name: "פרוסת לחם קל",
		englishName: "Light Bread Slice",
		category: "לחמים",
		servingSize: "פרוסה 1 (25 גרם)",
		unitWeightGrams: 25,
		servingUnitLabel: "פרוסה",
		calories: 45,
		protein: 2.8,
		carbs: 8,
		fat: .5,
		fiber: 2,
		searchTerms: ["לחם קל", "light bread"]
	},
	{
		id: "f-israel-1",
		name: "חלב 3% - תנובה / שטראוס",
		category: "חלב",
		servingSize: "100 מ\"ל",
		calories: 60,
		protein: 3.2,
		carbs: 4.7,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (חלב)"
	},
	{
		id: "f-israel-2",
		name: "חלב 1% - תנובה",
		category: "חלב",
		servingSize: "100 מ\"ל",
		calories: 42,
		protein: 3.3,
		carbs: 4.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (חלב)"
	},
	{
		id: "f-israel-3",
		name: "חלב דל לקטוז 2%",
		category: "חלב",
		servingSize: "100 מ\"ל",
		calories: 50,
		protein: 3.3,
		carbs: 4.7,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (חלב)"
	},
	{
		id: "f-israel-4",
		name: "חלב סויה ללא סוכר - אלפרו",
		category: "תחליפי חלב",
		servingSize: "100 מ\"ל",
		calories: 33,
		protein: 3.3,
		carbs: .2,
		fat: 1.8,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי חלב)"
	},
	{
		id: "f-israel-5",
		name: "חלב שקדים ללא סוכר",
		category: "תחליפי חלב",
		servingSize: "100 מ\"ל",
		calories: 15,
		protein: .5,
		carbs: .2,
		fat: 1.2,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי חלב)"
	},
	{
		id: "f-israel-6",
		name: "חלב שיבולת שועל - אלפרו",
		category: "תחליפי חלב",
		servingSize: "100 מ\"ל",
		calories: 45,
		protein: 1,
		carbs: 6.8,
		fat: 1.5,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי חלב)"
	},
	{
		id: "f-israel-7",
		name: "קוטג' 5% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 95,
		protein: 11,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-8",
		name: "קוטג' 3% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 78,
		protein: 11.5,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-9",
		name: "קוטג' 9% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 124,
		protein: 10.5,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-10",
		name: "קוטג' פרו 12g חלבון",
		category: "גבינות",
		servingSize: "גביע (125g)",
		calories: 105,
		protein: 12,
		carbs: 2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-11",
		name: "גבינה לבנה 5% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 90,
		protein: 10,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-12",
		name: "גבינה לבנה 3% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 73,
		protein: 10.2,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-13",
		name: "גבינה לבנה 9% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 120,
		protein: 9.5,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-14",
		name: "גבינה צהובה עמק 28% - תנובה",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 98,
		protein: 7,
		carbs: .1,
		fat: 7.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-15",
		name: "גבינה צהובה עמק 15% - תנובה",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 73,
		protein: 8.1,
		carbs: .1,
		fat: 4.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-16",
		name: "גבינה צהובה עמק 9% - תנובה",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 58,
		protein: 8.8,
		carbs: .1,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-17",
		name: "גבינה צהובה גלבוע 22%",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 85,
		protein: 7.5,
		carbs: .1,
		fat: 6.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-18",
		name: "גבינת מותרת 5% שומן",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 50,
		protein: 9,
		carbs: .2,
		fat: 1.4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-19",
		name: "גבינת מוצרלה מגוררת",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 280,
		protein: 22,
		carbs: 2,
		fat: 20,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-20",
		name: "גבינת מוצרלה לייט 15%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 210,
		protein: 24,
		carbs: 2,
		fat: 12,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-21",
		name: "גבינת בולגרית 5% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 110,
		protein: 15,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-22",
		name: "גבינת בולגרית 16% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 200,
		protein: 14,
		carbs: 1.5,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-23",
		name: "גבינת פטה עיזים 20%",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 240,
		protein: 14,
		carbs: 1,
		fat: 20,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-24",
		name: "גבינת צפתית 5% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 16,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-25",
		name: "לאבנה 9% - פיראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 9,
		carbs: 3,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-26",
		name: "לאבנה 5%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 95,
		protein: 9.5,
		carbs: 3,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-27",
		name: "גבינת שמנת נפוליאון 25%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 260,
		protein: 6,
		carbs: 3,
		fat: 25,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-28",
		name: "גבינת שמנת נפוליאון 16%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 7,
		carbs: 3.5,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-29",
		name: "יוגורט דנונה 3% ביו",
		category: "יוגורט",
		servingSize: "גביע (200g)",
		calories: 124,
		protein: 8,
		carbs: 9.2,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-30",
		name: "יוגורט דנונה 1.5% ביו",
		category: "יוגורט",
		servingSize: "גביע (200g)",
		calories: 96,
		protein: 8.4,
		carbs: 9.6,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-31",
		name: "יוגורט דנונה פרו 20g חלבון נקי",
		category: "יוגורט חלבון",
		servingSize: "גביע (200g)",
		calories: 120,
		protein: 20,
		carbs: 9,
		fat: .4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-32",
		name: "יוגורט דנונה פרו 20g תות",
		category: "יוגורט חלבון",
		servingSize: "גביע (200g)",
		calories: 150,
		protein: 20,
		carbs: 16,
		fat: .4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-33",
		name: "יוגורט דנונה פרו 20g וניל",
		category: "יוגורט חלבון",
		servingSize: "גביע (200g)",
		calories: 148,
		protein: 20,
		carbs: 15,
		fat: .4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-34",
		name: "יוגורט דנונה פרו 20g אפרסק",
		category: "יוגורט חלבון",
		servingSize: "גביע (200g)",
		calories: 152,
		protein: 20,
		carbs: 16.5,
		fat: .4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-35",
		name: "יוגורט יווני 7% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 100,
		protein: 6,
		carbs: 3.5,
		fat: 7,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-36",
		name: "יוגורט יווני 2% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 62,
		protein: 8.5,
		carbs: 3.8,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-37",
		name: "יוגורט סקיר Yoplait טבעי",
		category: "יוגורט חלבון",
		servingSize: "100 גרם",
		calories: 65,
		protein: 11,
		carbs: 4,
		fat: .2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-38",
		name: "יוגורט Yoplait Pro 15g",
		category: "יוגורט חלבון",
		servingSize: "גביע (150g)",
		calories: 110,
		protein: 15,
		carbs: 11,
		fat: .3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-39",
		name: "מעדן GO 20g חלבון שוקולד",
		category: "מעדני חלבון",
		servingSize: "גביע (200g)",
		calories: 156,
		protein: 20,
		carbs: 14,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדני חלבון)"
	},
	{
		id: "f-israel-40",
		name: "מעדן GO 20g חלבון וניל",
		category: "מעדני חלבון",
		servingSize: "גביע (200g)",
		calories: 150,
		protein: 20,
		carbs: 13,
		fat: 1.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדני חלבון)"
	},
	{
		id: "f-israel-41",
		name: "מעדן GO 20g חלבון קפה",
		category: "מעדני חלבון",
		servingSize: "גביע (200g)",
		calories: 152,
		protein: 20,
		carbs: 13.5,
		fat: 1.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדני חלבון)"
	},
	{
		id: "f-israel-42",
		name: "מעדן מילקי שוקולד",
		category: "מעדנים",
		servingSize: "גביע (133g)",
		calories: 210,
		protein: 3.2,
		carbs: 24,
		fat: 11.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדנים)"
	},
	{
		id: "f-israel-43",
		name: "מעדן מילקי לייט 1%",
		category: "מעדנים",
		servingSize: "גביע (133g)",
		calories: 115,
		protein: 4,
		carbs: 18,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדנים)"
	},
	{
		id: "f-israel-44",
		name: "מעדן דני שוקולד",
		category: "מעדנים",
		servingSize: "גביע (125g)",
		calories: 135,
		protein: 3.5,
		carbs: 23,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדנים)"
	},
	{
		id: "f-israel-45",
		name: "גיל 3% - תנובה",
		category: "מוצרי חלב",
		servingSize: "גביע (170g)",
		calories: 100,
		protein: 5.5,
		carbs: 7,
		fat: 5.1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מוצרי חלב)"
	},
	{
		id: "f-israel-46",
		name: "אשל 4.5% - תנובה",
		category: "מוצרי חלב",
		servingSize: "גביע (200g)",
		calories: 136,
		protein: 6.2,
		carbs: 8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מוצרי חלב)"
	},
	{
		id: "f-israel-47",
		name: "שמנת חמוצה 15% - תנובה",
		category: "שמנת",
		servingSize: "100 גרם",
		calories: 160,
		protein: 2.8,
		carbs: 3.5,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-48",
		name: "שמנת חמוצה 9% - תנובה",
		category: "שמנת",
		servingSize: "100 גרם",
		calories: 108,
		protein: 3.2,
		carbs: 3.8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-49",
		name: "שמנת מתוקה 38% להקצפה",
		category: "שמנת",
		servingSize: "100 מ\"ל",
		calories: 360,
		protein: 2,
		carbs: 3,
		fat: 38,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-50",
		name: "שמנת לבישול 15% - השף הלבן",
		category: "שמנת",
		servingSize: "100 מ\"ל",
		calories: 160,
		protein: 3,
		carbs: 4,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-51",
		name: "שמנת לבישול 10% - השף הלבן",
		category: "שמנת",
		servingSize: "100 מ\"ל",
		calories: 118,
		protein: 3.2,
		carbs: 4.2,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-52",
		name: "חמאה שופרסל / תנובה",
		category: "שומנים",
		servingSize: "10 גרם",
		calories: 74,
		protein: .1,
		carbs: .1,
		fat: 8.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שומנים)"
	},
	{
		id: "f-israel-53",
		name: "ריקוטה 5% - גד",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 100,
		protein: 11,
		carbs: 3.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-54",
		name: "גבינת חלומי 24%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 320,
		protein: 20,
		carbs: 2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-55",
		name: "גבינת פרמזן מגוררת",
		category: "גבינות קשות",
		servingSize: "10 גרם",
		calories: 40,
		protein: 3.8,
		carbs: .4,
		fat: 2.6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-56",
		name: "ביצה S (קטנה)",
		category: "ביצים",
		servingSize: "יחידה 1 (45g)",
		calories: 60,
		protein: 5.2,
		carbs: .4,
		fat: 4.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-57",
		name: "ביצה M (בינונית)",
		category: "ביצים",
		servingSize: "יחידה 1 (53g)",
		calories: 72,
		protein: 6.3,
		carbs: .5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-58",
		name: "ביצה L (גדולה)",
		category: "ביצים",
		servingSize: "יחידה 1 (63g)",
		calories: 85,
		protein: 7.5,
		carbs: .6,
		fat: 5.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-59",
		name: "ביצה XL (ענקית)",
		category: "ביצים",
		servingSize: "יחידה 1 (73g)",
		calories: 98,
		protein: 8.7,
		carbs: .7,
		fat: 6.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-60",
		name: "חלבון ביצה (חלבון בלבד)",
		category: "ביצים",
		servingSize: "100 גרם",
		calories: 52,
		protein: 11,
		carbs: .7,
		fat: .2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-61",
		name: "חלמון ביצה (חלמון בלבד)",
		category: "ביצים",
		servingSize: "יחידה 1 (17g)",
		calories: 55,
		protein: 2.7,
		carbs: .6,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-62",
		name: "ביצה קשה M",
		category: "ביצים",
		servingSize: "יחידה 1 (53g)",
		calories: 72,
		protein: 6.3,
		carbs: .5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-63",
		name: "חזה עוף טרי (נא)",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 110,
		protein: 23.5,
		carbs: 0,
		fat: 1.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-64",
		name: "חזה עוף מבושל / בגריל",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 165,
		protein: 31,
		carbs: 0,
		fat: 3.6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-65",
		name: "פרגית עוף (ירך ללא עור)",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 175,
		protein: 24,
		carbs: 0,
		fat: 8.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-66",
		name: "כרעי עוף עם עור (מבושל)",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 235,
		protein: 24,
		carbs: 0,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-67",
		name: "כנפי עוף בגריל",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 220,
		protein: 22,
		carbs: 0,
		fat: 14.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-68",
		name: "שוקי עוף ללא עור",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 160,
		protein: 26,
		carbs: 0,
		fat: 5.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-69",
		name: "כבד עוף צלוי",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 165,
		protein: 24.5,
		carbs: 1,
		fat: 6.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-70",
		name: "בשר בקר טחון רזה 5% שומן",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 135,
		protein: 21,
		carbs: 0,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-71",
		name: "בשר בקר טחון 12% שומן",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 185,
		protein: 19.5,
		carbs: 0,
		fat: 12,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-72",
		name: "בשר בקר טחון קלאסי 20%",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 250,
		protein: 17.5,
		carbs: 0,
		fat: 20,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-73",
		name: "סטייק אנטרקוט בגריל",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 270,
		protein: 25,
		carbs: 0,
		fat: 19,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-74",
		name: "סטייק סינטה בקר",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 170,
		protein: 27,
		carbs: 0,
		fat: 6.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-75",
		name: "סטייק שייטל בקר",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 155,
		protein: 28,
		carbs: 0,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-76",
		name: "כתף בקר מס' 5 מבושל",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 180,
		protein: 26,
		carbs: 0,
		fat: 8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-77",
		name: "צלי כתף מס' 4",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 195,
		protein: 25,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-78",
		name: "חזה הודו טרי",
		category: "הודו",
		servingSize: "100 גרם",
		calories: 105,
		protein: 24,
		carbs: 0,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (הודו)"
	},
	{
		id: "f-israel-79",
		name: "חזה הודו מבושל",
		category: "הודו",
		servingSize: "100 גרם",
		calories: 145,
		protein: 30,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (הודו)"
	},
	{
		id: "f-israel-80",
		name: "שווארמה הודו נקבה",
		category: "הודו",
		servingSize: "100 גרם",
		calories: 160,
		protein: 25,
		carbs: 0,
		fat: 6.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (הודו)"
	},
	{
		id: "f-israel-81",
		name: "פסטרמה חזה הודו דלת שומן 1%",
		category: "נקניקים",
		servingSize: "100 גרם",
		calories: 95,
		protein: 18,
		carbs: 2,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקים)"
	},
	{
		id: "f-israel-82",
		name: "פסטרמה בדבש 2%",
		category: "נקניקים",
		servingSize: "100 גרם",
		calories: 105,
		protein: 17,
		carbs: 4,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקים)"
	},
	{
		id: "f-israel-83",
		name: "פסטרמה מעושנת 3%",
		category: "נקניקים",
		servingSize: "100 גרם",
		calories: 110,
		protein: 17,
		carbs: 2.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקים)"
	},
	{
		id: "f-israel-84",
		name: "נקניק סלמי איטלקי",
		category: "נקניקים",
		servingSize: "100 גרם",
		calories: 380,
		protein: 16,
		carbs: 1.5,
		fat: 34,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקים)"
	},
	{
		id: "f-israel-85",
		name: "נקניקיות עוף - זוגלובק",
		category: "נקניקיות",
		servingSize: "יחידה (40g)",
		calories: 95,
		protein: 4.5,
		carbs: 2.5,
		fat: 7.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקיות)"
	},
	{
		id: "f-israel-86",
		name: "נקניקיות ביס עוף",
		category: "נקניקיות",
		servingSize: "100 גרם",
		calories: 240,
		protein: 11,
		carbs: 6,
		fat: 19,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקיות)"
	},
	{
		id: "f-israel-87",
		name: "המבורגר בקר קפוא (שמיר/טיבון)",
		category: "מוצרים קפואים",
		servingSize: "יחידה (100g)",
		calories: 240,
		protein: 16,
		carbs: 2,
		fat: 19,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מוצרים קפואים)"
	},
	{
		id: "f-israel-88",
		name: "שניצל עוף ביתי מצופה פירורים",
		category: "עוף ובשר",
		servingSize: "יחידה (120g)",
		calories: 260,
		protein: 22,
		carbs: 18,
		fat: 11,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-89",
		name: "שניצל עוף מוכן קפוא (מאמא עוף)",
		category: "מוצרים קפואים",
		servingSize: "יחידה (100g)",
		calories: 220,
		protein: 14,
		carbs: 16,
		fat: 11,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (מוצרים קפואים)"
	},
	{
		id: "f-israel-90",
		name: "קופסת טונה במים (מסונן)",
		category: "דגים",
		servingSize: "קופסה (112g)",
		calories: 120,
		protein: 26,
		carbs: 0,
		fat: 1.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-91",
		name: "קופסת טונה בשמן צמחי (מסונן)",
		category: "דגים",
		servingSize: "קופסה (112g)",
		calories: 190,
		protein: 25,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-92",
		name: "טונה בשמן זית (מסונן)",
		category: "דגים",
		servingSize: "קופסה (112g)",
		calories: 200,
		protein: 25,
		carbs: 0,
		fat: 11,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-93",
		name: "פילה סלמון טרי (נא)",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 208,
		protein: 20,
		carbs: 0,
		fat: 13,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-94",
		name: "פילה סלמון בתנור",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 230,
		protein: 23,
		carbs: 0,
		fat: 14.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-95",
		name: "סלמון מעושן (סלמון מעושן פרוס)",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 180,
		protein: 22,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-96",
		name: "פילה אמנון (מושט) בתנור",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 128,
		protein: 23,
		carbs: 0,
		fat: 3.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-97",
		name: "פילה דניס בתנור",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 160,
		protein: 20,
		carbs: 0,
		fat: 8.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-98",
		name: "פילה לברק בתנור",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 145,
		protein: 21,
		carbs: 0,
		fat: 6.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-99",
		name: "סרדינים בשמן (מקופסה)",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 210,
		protein: 24,
		carbs: 0,
		fat: 12,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-100",
		name: "מקרל מעושן",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 260,
		protein: 20,
		carbs: 0,
		fat: 20,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-101",
		name: "פילה נסיכת הנילוס",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 95,
		protein: 19,
		carbs: 0,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-102",
		name: "קוד / סול אפוי",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 90,
		protein: 19,
		carbs: 0,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-103",
		name: "אצבעות דג מצופות (דגיתון)",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 210,
		protein: 12,
		carbs: 18,
		fat: 10,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-104",
		name: "אדממה / Edamame (תרמילי סויה)",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 121,
		protein: 11.9,
		carbs: 8.9,
		fat: 5.2,
		fiber: 5.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-105",
		name: "אדממה קלוף קפוא",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 12.5,
		carbs: 9.5,
		fat: 5.5,
		fiber: 5.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-106",
		name: "טופו קלאסי - תנובה / אדמה",
		category: "תחליפי בשר",
		servingSize: "100 גרם",
		calories: 140,
		protein: 14,
		carbs: 2.5,
		fat: 8.5,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-107",
		name: "טופו במרקם רך (סילקן)",
		category: "תחליפי בשר",
		servingSize: "100 גרם",
		calories: 60,
		protein: 6.5,
		carbs: 1.8,
		fat: 2.8,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-108",
		name: "שבבי סויה יבשים (בונזואל)",
		category: "תחליפי בשר",
		servingSize: "100 גרם",
		calories: 330,
		protein: 50,
		carbs: 30,
		fat: 1.2,
		fiber: 18,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-109",
		name: "טבעול שניצל תירס",
		category: "תחליפי בשר",
		servingSize: "יחידה (100g)",
		calories: 210,
		protein: 7.5,
		carbs: 24,
		fat: 9.5,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-110",
		name: "טבעול שניצל צמחוני קלאסי",
		category: "תחליפי בשר",
		servingSize: "יחידה (100g)",
		calories: 190,
		protein: 13,
		carbs: 14,
		fat: 9,
		fiber: 4.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-111",
		name: "בורגר סויה Sensational / Beyond",
		category: "תחליפי בשר",
		servingSize: "יחידה (113g)",
		calories: 250,
		protein: 19,
		carbs: 5,
		fat: 17,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-112",
		name: "אורז לבן מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 2.5,
		carbs: 28,
		fat: .3,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-113",
		name: "אורז בסמטי מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 2.6,
		carbs: 27,
		fat: .4,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-114",
		name: "אורז יסמין מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 2.4,
		carbs: 28.5,
		fat: .3,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-115",
		name: "אורז מלא מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 112,
		protein: 2.6,
		carbs: 23.5,
		fat: .9,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-116",
		name: "אורז אדום / שחור מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 2.8,
		carbs: 24,
		fat: .8,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-117",
		name: "פסטה לבנה מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 5.8,
		carbs: 31,
		fat: .9,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-118",
		name: "פסטה מקמח מלא מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 140,
		protein: 6.2,
		carbs: 27,
		fat: 1.2,
		fiber: 4.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-119",
		name: "פסטה כוסמין מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 145,
		protein: 6,
		carbs: 28,
		fat: 1.1,
		fiber: 3.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-120",
		name: "קוסקוס מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 112,
		protein: 3.8,
		carbs: 23,
		fat: .2,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-121",
		name: "קוסקוס מלא מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 118,
		protein: 4.2,
		carbs: 23.5,
		fat: .6,
		fiber: 3.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-122",
		name: "בורגול מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 83,
		protein: 3.1,
		carbs: 18.5,
		fat: .2,
		fiber: 4.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-123",
		name: "קינואה מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 120,
		protein: 4.4,
		carbs: 21,
		fat: 1.9,
		fiber: 2.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-124",
		name: "כוסמת ירוקה / קלויה מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 92,
		protein: 3.4,
		carbs: 19.8,
		fat: .6,
		fiber: 2.7,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-125",
		name: "שיבולת שועל להכנה מהירה (קוואקר)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 389,
		protein: 17,
		carbs: 66,
		fat: 7,
		fiber: 10,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-126",
		name: "קוואקר - מנה מדודה",
		category: "דגנים ופחמימות",
		servingSize: "כף גדושה (15g)",
		calories: 58,
		protein: 2.5,
		carbs: 9.9,
		fat: 1,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-127",
		name: "פתיתים אפויים מבושלים",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 150,
		protein: 5,
		carbs: 30,
		fat: .8,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-128",
		name: "תפוחי אדמה אפויים / מבושלים",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 87,
		protein: 1.9,
		carbs: 20,
		fat: .1,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-129",
		name: "פירה תפוחי אדמה עם חלב וחמאה",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 110,
		protein: 2,
		carbs: 17,
		fat: 4.2,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-130",
		name: "בטטה אפויה בתנור",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 90,
		protein: 2,
		carbs: 21,
		fat: .2,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-131",
		name: "תירס מתוק מקופסה (מסונן)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 80,
		protein: 2.8,
		carbs: 16,
		fat: 1.2,
		fiber: 2.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-132",
		name: "קלח תירס מבושל",
		category: "דגנים ופחמימות",
		servingSize: "יחידה בינונית (100g)",
		calories: 96,
		protein: 3.4,
		carbs: 21,
		fat: 1.5,
		fiber: 2.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-133",
		name: "לחם אחיד פרוס (אנג'ל / ברמן)",
		category: "לחמים",
		servingSize: "פרוסה (35g)",
		calories: 82,
		protein: 3,
		carbs: 15.5,
		fat: .7,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-134",
		name: "לחם מקמח חיטה מלאה 100%",
		category: "לחמים",
		servingSize: "פרוסה (35g)",
		calories: 75,
		protein: 3.8,
		carbs: 13,
		fat: .8,
		fiber: 2.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-135",
		name: "לחם כוסמין 100%",
		category: "לחמים",
		servingSize: "פרוסה (35g)",
		calories: 78,
		protein: 3.9,
		carbs: 13.5,
		fat: .9,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-136",
		name: "לחם קל (אנג'ל/ברמן)",
		category: "לחמים",
		servingSize: "פרוסה (25g)",
		calories: 45,
		protein: 2.2,
		carbs: 8,
		fat: .4,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-137",
		name: "לחם מחמצת כפרי",
		category: "לחמים",
		servingSize: "פרוסה (40g)",
		calories: 100,
		protein: 3.8,
		carbs: 19,
		fat: .8,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-138",
		name: "פיתה קלאסית מקמח לבן",
		category: "לחמים",
		servingSize: "יחידה (100g)",
		calories: 260,
		protein: 9,
		carbs: 53,
		fat: 1.2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-139",
		name: "פיתה מקמח מלא",
		category: "לחמים",
		servingSize: "יחידה (100g)",
		calories: 235,
		protein: 10,
		carbs: 46,
		fat: 1.5,
		fiber: 6,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-140",
		name: "פיתה כוסמין קלה",
		category: "לחמים",
		servingSize: "יחידה (60g)",
		calories: 125,
		protein: 6.5,
		carbs: 22,
		fat: .8,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-141",
		name: "פיתה ביס / פיתה קטנה",
		category: "לחמים",
		servingSize: "יחידה (50g)",
		calories: 130,
		protein: 4.5,
		carbs: 26.5,
		fat: .6,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-142",
		name: "לחמנייה מתוקה / לחמניית המבורגר",
		category: "לחמים",
		servingSize: "יחידה (80g)",
		calories: 230,
		protein: 7,
		carbs: 43,
		fat: 3.5,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-143",
		name: "לחמנייה קלה מקמח מלא",
		category: "לחמים",
		servingSize: "יחידה (60g)",
		calories: 115,
		protein: 6,
		carbs: 20,
		fat: 1,
		fiber: 5.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-144",
		name: "טורטייה חיטה (מאסטר שף / שופרסל)",
		category: "לחמים",
		servingSize: "יחידה (45g)",
		calories: 135,
		protein: 3.6,
		carbs: 23,
		fat: 3,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-145",
		name: "טורטייה מקמח מלא",
		category: "לחמים",
		servingSize: "יחידה (45g)",
		calories: 125,
		protein: 4,
		carbs: 21,
		fat: 2.8,
		fiber: 3.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-146",
		name: "פריכיות אורז חום קלאסיות",
		category: "תחליפי לחם",
		servingSize: "יחידה (8g)",
		calories: 30,
		protein: .7,
		carbs: 6.3,
		fat: .2,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-147",
		name: "פריכיות אורז עם מלח ים",
		category: "תחליפי לחם",
		servingSize: "יחידה (8g)",
		calories: 30,
		protein: .7,
		carbs: 6.3,
		fat: .2,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-148",
		name: "פריכיות תירס קראנצ'",
		category: "תחליפי לחם",
		servingSize: "יחידה (7g)",
		calories: 26,
		protein: .6,
		carbs: 5.6,
		fat: .2,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-149",
		name: "פריכיות כוסמין מלא",
		category: "תחליפי לחם",
		servingSize: "יחידה (8g)",
		calories: 29,
		protein: .9,
		carbs: 5.8,
		fat: .2,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-150",
		name: "פריכיות דקות / מיני פריכיות",
		category: "תחליפי לחם",
		servingSize: "יחידה (3g)",
		calories: 11,
		protein: .3,
		carbs: 2.3,
		fat: .1,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-151",
		name: "פתית זהב קלאסי (מאסטר שף)",
		category: "תחליפי לחם",
		servingSize: "פרוסה (7g)",
		calories: 26,
		protein: .8,
		carbs: 5.2,
		fat: .2,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-152",
		name: "קרקר זהב / קרקר דגנים",
		category: "תחליפי לחם",
		servingSize: "יחידה (10g)",
		calories: 42,
		protein: 1,
		carbs: 6.5,
		fat: 1.3,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-153",
		name: "בייגלה שמיניות (אסם)",
		category: "חטיפים",
		servingSize: "100 גרם",
		calories: 380,
		protein: 10,
		carbs: 75,
		fat: 3.5,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-154",
		name: "בייגלה שטוחים (אסם)",
		category: "חטיפים",
		servingSize: "100 גרם",
		calories: 390,
		protein: 10.5,
		carbs: 76,
		fat: 4,
		fiber: 3.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-155",
		name: "דגני בוקר קורנפלקס תלמה",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 370,
		protein: 7.5,
		carbs: 84,
		fat: .8,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-156",
		name: "דגני בוקר כריות שוקולד (תלמה)",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 450,
		protein: 6,
		carbs: 72,
		fat: 15,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-157",
		name: "דגני בוקר צ'יריוס דבש ואגוזים",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 385,
		protein: 7,
		carbs: 78,
		fat: 4.5,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-158",
		name: "דגני בוקר פיטנס טבעי (נסטלה)",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 365,
		protein: 9,
		carbs: 74,
		fat: 2,
		fiber: 7,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-159",
		name: "גרנולה ביתית / דגנים מלאים עם אגוזים",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 440,
		protein: 11,
		carbs: 58,
		fat: 17,
		fiber: 8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-160",
		name: "גרנולה ללא תוספת סוכר",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 390,
		protein: 13,
		carbs: 52,
		fat: 14,
		fiber: 10,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-161",
		name: "עדשים ירוקות / חומות מבושלות",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 116,
		protein: 9,
		carbs: 20,
		fat: .4,
		fiber: 7.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-162",
		name: "עדשים אדומות מבושלות",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 8.8,
		carbs: 19.5,
		fat: .4,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-163",
		name: "גרגירי חומוס מבושלים",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 164,
		protein: 8.9,
		carbs: 27,
		fat: 2.6,
		fiber: 7.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-164",
		name: "גרגירי חומוס מוקפאים (סנפרוסט)",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 150,
		protein: 8.2,
		carbs: 24,
		fat: 2.2,
		fiber: 7,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-165",
		name: "שעועית לבנה מבושלת",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 127,
		protein: 8.7,
		carbs: 22.8,
		fat: .5,
		fiber: 6.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-166",
		name: "שעועית אדומה מבושלת",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 8.5,
		carbs: 22.5,
		fat: .5,
		fiber: 6.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-167",
		name: "אפונה ירוקה מבושלת (סנפרוסט)",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 81,
		protein: 5.4,
		carbs: 14.5,
		fat: .4,
		fiber: 5.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-168",
		name: "תורמוס מבושל",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 119,
		protein: 15.5,
		carbs: 10,
		fat: 2.8,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-169",
		name: "פול מבושל",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 110,
		protein: 7.6,
		carbs: 19.5,
		fat: .4,
		fiber: 5.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-170",
		name: "עדשים שחורות (בלוגה) מבושלות",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 120,
		protein: 9.2,
		carbs: 20,
		fat: .5,
		fiber: 8,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-171",
		name: "תפוח עץ בינוני (עם קליפה)",
		category: "פירות",
		servingSize: "יחידה (150g)",
		calories: 80,
		protein: .4,
		carbs: 21,
		fat: .3,
		fiber: 3.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-172",
		name: "בננה בינונית",
		category: "פירות",
		servingSize: "יחידה (120g)",
		calories: 105,
		protein: 1.3,
		carbs: 27,
		fat: .3,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-173",
		name: "תפוז בינוני",
		category: "פירות",
		servingSize: "יחידה (150g)",
		calories: 65,
		protein: 1.3,
		carbs: 16,
		fat: .2,
		fiber: 3.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-174",
		name: "קלמנטינה",
		category: "פירות",
		servingSize: "יחידה (85g)",
		calories: 40,
		protein: .7,
		carbs: 10,
		fat: .1,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-175",
		name: "אשכולית אדומה",
		category: "פירות",
		servingSize: "חצי יחידה (120g)",
		calories: 50,
		protein: .9,
		carbs: 12,
		fat: .1,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-176",
		name: "תות שדה טרי",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 32,
		protein: .7,
		carbs: 7.7,
		fat: .3,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-177",
		name: "ענבים ירוקים / אדומים",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 69,
		protein: .7,
		carbs: 18,
		fat: .2,
		fiber: .9,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-178",
		name: "אבטיח מתוק",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 30,
		protein: .6,
		carbs: 7.5,
		fat: .1,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-179",
		name: "מלון צהוב",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 34,
		protein: .8,
		carbs: 8.2,
		fat: .2,
		fiber: .9,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-180",
		name: "אפרסק טרי",
		category: "פירות",
		servingSize: "יחידה (130g)",
		calories: 50,
		protein: 1.2,
		carbs: 12,
		fat: .3,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-181",
		name: "נקטרינה",
		category: "פירות",
		servingSize: "יחידה (130g)",
		calories: 55,
		protein: 1.4,
		carbs: 13,
		fat: .4,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-182",
		name: "שזיף אדום / צהוב",
		category: "פירות",
		servingSize: "יחידה (60g)",
		calories: 30,
		protein: .4,
		carbs: 7.5,
		fat: .2,
		fiber: .9,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-183",
		name: "אגס בינוני",
		category: "פירות",
		servingSize: "יחידה (150g)",
		calories: 85,
		protein: .6,
		carbs: 23,
		fat: .2,
		fiber: 4.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-184",
		name: "תמר מג'הול עסיסי",
		category: "פירות יבשים",
		servingSize: "יחידה 1 (24g)",
		calories: 66,
		protein: .4,
		carbs: 18,
		fat: .1,
		fiber: 1.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-185",
		name: "תמר דקל נור",
		category: "פירות יבשים",
		servingSize: "יחידה 1 (10g)",
		calories: 28,
		protein: .2,
		carbs: 7.5,
		fat: 0,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-186",
		name: "מנגו מתוק",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 60,
		protein: .8,
		carbs: 15,
		fat: .4,
		fiber: 1.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-187",
		name: "אננס טרי",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 50,
		protein: .5,
		carbs: 13,
		fat: .1,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-188",
		name: "קיווי",
		category: "פירות",
		servingSize: "יחידה (70g)",
		calories: 42,
		protein: .8,
		carbs: 10,
		fat: .4,
		fiber: 2.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-189",
		name: "דובדבנים מתוקים",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 63,
		protein: 1.1,
		carbs: 16,
		fat: .2,
		fiber: 2.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-190",
		name: "אבוקדו היל / חס",
		category: "פירות / שומנים",
		servingSize: "חצי אבוקדו (75g)",
		calories: 120,
		protein: 1.5,
		carbs: 6,
		fat: 11,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות / שומנים)"
	},
	{
		id: "f-israel-191",
		name: "רימון (גרגרים)",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 83,
		protein: 1.7,
		carbs: 18.7,
		fat: 1.2,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-192",
		name: "תאנה טרייה",
		category: "פירות",
		servingSize: "יחידה (50g)",
		calories: 37,
		protein: .4,
		carbs: 9.5,
		fat: .1,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-193",
		name: "אפרסמון",
		category: "פירות",
		servingSize: "יחידה (120g)",
		calories: 84,
		protein: .7,
		carbs: 21,
		fat: .2,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-194",
		name: "משמש טרי",
		category: "פירות",
		servingSize: "יחידה (35g)",
		calories: 17,
		protein: .5,
		carbs: 3.9,
		fat: .1,
		fiber: .7,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-195",
		name: "חמוציות מיובשות ללא סוכר",
		category: "פירות יבשים",
		servingSize: "30 גרם",
		calories: 92,
		protein: .1,
		carbs: 24,
		fat: .4,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-196",
		name: "צימוקים כהים / בהירים",
		category: "פירות יבשים",
		servingSize: "30 גרם",
		calories: 90,
		protein: .9,
		carbs: 23,
		fat: .1,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-197",
		name: "שזיפים מיובשים",
		category: "פירות יבשים",
		servingSize: "יחידה 1 (10g)",
		calories: 24,
		protein: .2,
		carbs: 6.3,
		fat: 0,
		fiber: .7,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-198",
		name: "משמש מיובש",
		category: "פירות יבשים",
		servingSize: "יחידה 1 (8g)",
		calories: 20,
		protein: .3,
		carbs: 5,
		fat: 0,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-199",
		name: "מלפפון טרי עם קליפה",
		category: "ירקות",
		servingSize: "יחידה (100g)",
		calories: 15,
		protein: .7,
		carbs: 3.6,
		fat: .1,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-200",
		name: "עגבנייה טרייה",
		category: "ירקות",
		servingSize: "יחידה (120g)",
		calories: 22,
		protein: 1.1,
		carbs: 4.8,
		fat: .2,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-201",
		name: "עגבניות שרי",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 18,
		protein: .9,
		carbs: 3.9,
		fat: .2,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-202",
		name: "גזר טרי",
		category: "ירקות",
		servingSize: "יחידה (80g)",
		calories: 33,
		protein: .7,
		carbs: 7.6,
		fat: .2,
		fiber: 2.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-203",
		name: "פלפל אדום (גמבה)",
		category: "ירקות",
		servingSize: "יחידה (150g)",
		calories: 40,
		protein: 1.5,
		carbs: 9,
		fat: .3,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-204",
		name: "פלפל ירוק / צהוב",
		category: "ירקות",
		servingSize: "יחידה (150g)",
		calories: 30,
		protein: 1.2,
		carbs: 7,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-205",
		name: "קישוא טרי / מבושל",
		category: "ירקות",
		servingSize: "יחידה (120g)",
		calories: 20,
		protein: 1.4,
		carbs: 3.8,
		fat: .4,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-206",
		name: "חציל קלוי / אפוי ללא שמן",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 25,
		protein: 1,
		carbs: 5.8,
		fat: .2,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-207",
		name: "כרוב לבן קצוץ",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 25,
		protein: 1.3,
		carbs: 5.8,
		fat: .1,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-208",
		name: "כרוב אדום קצוץ",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 31,
		protein: 1.4,
		carbs: 7.4,
		fat: .2,
		fiber: 2.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-209",
		name: "חסה ערבית / מסולסלת",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 15,
		protein: 1.4,
		carbs: 2.9,
		fat: .2,
		fiber: 1.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-210",
		name: "עלי תרד טריים",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 23,
		protein: 2.9,
		carbs: 3.6,
		fat: .4,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-211",
		name: "ברוקולי מבושל / בקיטור",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 35,
		protein: 2.4,
		carbs: 7,
		fat: .4,
		fiber: 3.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-212",
		name: "כרובית אפויה / מבושלת",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 25,
		protein: 1.9,
		carbs: 5,
		fat: .3,
		fiber: 2.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-213",
		name: "בצל צהוב / סגול",
		category: "ירקות",
		servingSize: "יחידה (100g)",
		calories: 40,
		protein: 1.1,
		carbs: 9.3,
		fat: .1,
		fiber: 1.7,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-214",
		name: "בצל ירוק",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 32,
		protein: 1.8,
		carbs: 7.3,
		fat: .2,
		fiber: 2.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-215",
		name: "שום טרי",
		category: "ירקות",
		servingSize: "שן שום (3g)",
		calories: 4,
		protein: .2,
		carbs: 1,
		fat: 0,
		fiber: .1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-216",
		name: "פטריות שמפיניון טריות",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 22,
		protein: 3.1,
		carbs: 3.3,
		fat: .3,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-217",
		name: "פטריות פורטבלו בגריל",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 28,
		protein: 2.5,
		carbs: 4.5,
		fat: .5,
		fiber: 1.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-218",
		name: "צנונית טרייה",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 16,
		protein: .7,
		carbs: 3.4,
		fat: .1,
		fiber: 1.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-219",
		name: "דלעת אפויה",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 26,
		protein: 1,
		carbs: 6.5,
		fat: .1,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-220",
		name: "דלורית אפויה בתנור",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 45,
		protein: 1,
		carbs: 11.5,
		fat: .1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-221",
		name: "סלק אדום מבושל",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 43,
		protein: 1.6,
		carbs: 9.6,
		fat: .2,
		fiber: 2.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-222",
		name: "עשבי תיבול (פטרוזיליה/כוסברה/שמיר)",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 36,
		protein: 3,
		carbs: 6.3,
		fat: .8,
		fiber: 3.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-223",
		name: "נבטים סיניים",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 30,
		protein: 3,
		carbs: 5.9,
		fat: .2,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-224",
		name: "סלרי (גבעולים)",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 14,
		protein: .7,
		carbs: 3,
		fat: .2,
		fiber: 1.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-225",
		name: "שעועית ירוקה מבושלת (סנפרוסט)",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 31,
		protein: 1.8,
		carbs: 7,
		fat: .2,
		fiber: 3.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-226",
		name: "שעועית צהובה מבושלת",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 31,
		protein: 1.8,
		carbs: 7,
		fat: .2,
		fiber: 3.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-227",
		name: "לקט ירקות לנורמנדי (סנפרוסט)",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 30,
		protein: 2,
		carbs: 5.5,
		fat: .3,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-228",
		name: "לקט ירקות מוקפצים",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 35,
		protein: 1.8,
		carbs: 6.5,
		fat: .3,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-229",
		name: "שקדים טבעיים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 175,
		protein: 6.3,
		carbs: 6,
		fat: 15,
		fiber: 3.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-230",
		name: "שקדים מולבנים / פרוסים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 175,
		protein: 6.3,
		carbs: 6,
		fat: 15,
		fiber: 3.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-231",
		name: "אגוזי מלך קלופים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 195,
		protein: 4.5,
		carbs: 4,
		fat: 19.5,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-232",
		name: "אגוזי קשיו טבעיים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 165,
		protein: 5.5,
		carbs: 9,
		fat: 13,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-233",
		name: "בוטנים קלויים / טבעיים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 170,
		protein: 7.5,
		carbs: 5,
		fat: 14,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-234",
		name: "פיסטוקים קלויים ומומלחים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 168,
		protein: 6,
		carbs: 8,
		fat: 13.5,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-235",
		name: "אגוזי לוז (בונדוק)",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 188,
		protein: 4.2,
		carbs: 5,
		fat: 18,
		fiber: 2.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-236",
		name: "אגוזי פקאן טבעיים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 205,
		protein: 2.7,
		carbs: 4,
		fat: 21,
		fiber: 2.7,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-237",
		name: "אגוזי ברזיל",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 200,
		protein: 4.3,
		carbs: 3.5,
		fat: 20,
		fiber: 2.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-238",
		name: "גרעיני חמנייה קלופים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 175,
		protein: 6.2,
		carbs: 6,
		fat: 15,
		fiber: 2.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-239",
		name: "גרעיני דלעת קלופים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 168,
		protein: 9,
		carbs: 4.5,
		fat: 14,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-240",
		name: "שומשום מלא / לבן",
		category: "אגוזים וגרעינים",
		servingSize: "כף (10g)",
		calories: 57,
		protein: 1.8,
		carbs: 2.3,
		fat: 5,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-241",
		name: "זרעי צ'יה",
		category: "אגוזים וגרעינים",
		servingSize: "כף (12g)",
		calories: 58,
		protein: 2,
		carbs: 5,
		fat: 3.7,
		fiber: 4.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-242",
		name: "זרעי פשתן טחונים",
		category: "אגוזים וגרעינים",
		servingSize: "כף (10g)",
		calories: 53,
		protein: 1.8,
		carbs: 3,
		fat: 4.2,
		fiber: 2.7,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-243",
		name: "חמאת בוטנים טבעית 100%",
		category: "ממרחים",
		servingSize: "כף (16g)",
		calories: 95,
		protein: 4,
		carbs: 3,
		fat: 8,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-244",
		name: "חמאת בוטנים סקיפי עם שבבים",
		category: "ממרחים",
		servingSize: "כף (16g)",
		calories: 98,
		protein: 3.5,
		carbs: 4,
		fat: 8,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-245",
		name: "טחינה גולמית משומשום מלא (הנסיך/אל ארז)",
		category: "ממרחים",
		servingSize: "כף (15g)",
		calories: 98,
		protein: 3.8,
		carbs: 1.8,
		fat: 8.8,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-246",
		name: "טחינה גולמית קלאסית",
		category: "ממרחים",
		servingSize: "כף (15g)",
		calories: 100,
		protein: 3.5,
		carbs: 2,
		fat: 9,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-247",
		name: "טחינה מוכנה למאכל (צבר / אחלה)",
		category: "ממרחים",
		servingSize: "כף (15g)",
		calories: 45,
		protein: 1.2,
		carbs: 1,
		fat: 4.2,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-248",
		name: "חומוס אחלה / צבר קלאסי",
		category: "ממרחים",
		servingSize: "כף (30g)",
		calories: 70,
		protein: 2.1,
		carbs: 4.2,
		fat: 5,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-249",
		name: "חומוס דל שומן 9%",
		category: "ממרחים",
		servingSize: "כף (30g)",
		calories: 48,
		protein: 2.2,
		carbs: 4.5,
		fat: 2.7,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-250",
		name: "ממרח אבוקדו מוכן",
		category: "ממרחים",
		servingSize: "כף (20g)",
		calories: 32,
		protein: .4,
		carbs: 1.6,
		fat: 2.8,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-251",
		name: "שמן זית כתית מעולה",
		category: "שמנים",
		servingSize: "כף (10 מ\"ל)",
		calories: 88,
		protein: 0,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנים)"
	},
	{
		id: "f-israel-252",
		name: "שמן קנולה / חמניות",
		category: "שמנים",
		servingSize: "כף (10 מ\"ל)",
		calories: 88,
		protein: 0,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנים)"
	},
	{
		id: "f-israel-253",
		name: "תרסיס שמן קנולה / זית",
		category: "שמנים",
		servingSize: "ריסוס (1g)",
		calories: 9,
		protein: 0,
		carbs: 0,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנים)"
	},
	{
		id: "f-israel-254",
		name: "מיונז קלאסי (הלמנס / תלמה)",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 100,
		protein: .2,
		carbs: .5,
		fat: 11,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-255",
		name: "מיונז הלמנס לייטאקטיב 5% / 9%",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 25,
		protein: .2,
		carbs: 1.5,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-256",
		name: "קטשופ אסם קלאסי",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 17,
		protein: .2,
		carbs: 4,
		fat: 0,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-257",
		name: "קטשופ אסם ללא תוספת סוכר",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 8,
		protein: .2,
		carbs: 1.8,
		fat: 0,
		fiber: .3,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-258",
		name: "חרדל דיז'ון / צהוב",
		category: "רוטבים",
		servingSize: "כפית (5g)",
		calories: 5,
		protein: .3,
		carbs: .3,
		fat: .3,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-259",
		name: "רוטב סויה דל נתרן (קיקומן)",
		category: "רוטבים",
		servingSize: "כף (15 מ\"ל)",
		calories: 10,
		protein: 1.2,
		carbs: 1,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-260",
		name: "רוטב צ'ילי מתוק",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 32,
		protein: .1,
		carbs: 8,
		fat: 0,
		fiber: .1,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-261",
		name: "רוטב ברבקיו",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 25,
		protein: .2,
		carbs: 6,
		fat: .1,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-262",
		name: "רוטב אלף האיים לייט",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 30,
		protein: .2,
		carbs: 3,
		fat: 2,
		fiber: .1,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-263",
		name: "סילאן טבעי 100% תמרים",
		category: "ממתיקים",
		servingSize: "כף (20g)",
		calories: 60,
		protein: .4,
		carbs: 14.5,
		fat: 0,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממתיקים)"
	},
	{
		id: "f-israel-264",
		name: "דבש טבעי (יד מרדכי)",
		category: "ממתיקים",
		servingSize: "כף (20g)",
		calories: 64,
		protein: .1,
		carbs: 16,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממתיקים)"
	},
	{
		id: "f-israel-265",
		name: "ממרח השחר העולה",
		category: "ממרחים",
		servingSize: "כף (20g)",
		calories: 110,
		protein: .6,
		carbs: 12.5,
		fat: 6.5,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-266",
		name: "ממרח נוטלה",
		category: "ממרחים",
		servingSize: "כף (20g)",
		calories: 108,
		protein: 1.2,
		carbs: 11.5,
		fat: 6.2,
		fiber: .7,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-267",
		name: "ממרח לוטוס",
		category: "ממרחים",
		servingSize: "כף (20g)",
		calories: 115,
		protein: .6,
		carbs: 11.5,
		fat: 7.5,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-268",
		name: "אבקת חלבון מי גבינה WHEY",
		category: "תוספי תזונה",
		servingSize: "כף מדידה (30g)",
		calories: 120,
		protein: 24,
		carbs: 2,
		fat: 1.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (תוספי תזונה)"
	},
	{
		id: "f-israel-269",
		name: "אבקת חלבון איסולייט ISO",
		category: "תוספי תזונה",
		servingSize: "כף מדידה (30g)",
		calories: 110,
		protein: 27,
		carbs: .5,
		fat: .5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (תוספי תזונה)"
	},
	{
		id: "f-israel-270",
		name: "אבקת חלבון טבעונית (סויה/אפונה)",
		category: "תוספי תזונה",
		servingSize: "כף מדידה (30g)",
		calories: 115,
		protein: 23,
		carbs: 2.5,
		fat: 1.5,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (תוספי תזונה)"
	},
	{
		id: "f-israel-271",
		name: "חטיף חלבון Allin קראנצ' 20g",
		category: "חטיפי חלבון",
		servingSize: "חטיף (60g)",
		calories: 210,
		protein: 20,
		carbs: 18,
		fat: 7,
		fiber: 8,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-272",
		name: "חטיף חלבון Barebells 20g",
		category: "חטיפי חלבון",
		servingSize: "חטיף (55g)",
		calories: 200,
		protein: 20,
		carbs: 16,
		fat: 8,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-273",
		name: "חטיף חלבון Ninja 20g",
		category: "חטיפי חלבון",
		servingSize: "חטיף (60g)",
		calories: 215,
		protein: 20,
		carbs: 19,
		fat: 7.5,
		fiber: 6,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-274",
		name: "חטיף חלבון Pro 20g - שטראוס",
		category: "חטיפי חלבון",
		servingSize: "חטיף (60g)",
		calories: 205,
		protein: 20,
		carbs: 17,
		fat: 6.8,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-275",
		name: "חטיף חלבון Quest Bar",
		category: "חטיפי חלבון",
		servingSize: "חטיף (60g)",
		calories: 190,
		protein: 21,
		carbs: 21,
		fat: 7,
		fiber: 14,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-276",
		name: "חטיף אנרגיה Nature Valley",
		category: "חטיפים",
		servingSize: "יחידה (21g)",
		calories: 95,
		protein: 2,
		carbs: 14,
		fat: 3.5,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-277",
		name: "חטיף אנרגיה FITFREE ללא סוכר",
		category: "חטיפים",
		servingSize: "יחידה (25g)",
		calories: 85,
		protein: 1.8,
		carbs: 15,
		fat: 2.2,
		fiber: 3.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-278",
		name: "במבה קלאסית (אסם)",
		category: "חטיפים",
		servingSize: "שקית קטנה (25g)",
		calories: 133,
		protein: 3.5,
		carbs: 10,
		fat: 8.8,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-279",
		name: "במבה פרו 12g חלבון",
		category: "חטיפים",
		servingSize: "שקית (60g)",
		calories: 280,
		protein: 12,
		carbs: 22,
		fat: 16,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-280",
		name: "ביסלי גריל / ברבקיו (אסם)",
		category: "חטיפים",
		servingSize: "שקית קטנה (35g)",
		calories: 170,
		protein: 3.2,
		carbs: 22,
		fat: 7.8,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-281",
		name: "תפוצ'יפס קלאסי (שטראוס)",
		category: "חטיפים",
		servingSize: "שקית קטנה (50g)",
		calories: 265,
		protein: 3,
		carbs: 26,
		fat: 16.5,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-282",
		name: "תפוצ'יפס Crunch",
		category: "חטיפים",
		servingSize: "שקית קטנה (50g)",
		calories: 270,
		protein: 3,
		carbs: 25.5,
		fat: 17,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-283",
		name: "דורטוס חמוץ חריף",
		category: "חטיפים",
		servingSize: "שקית קטנה (55g)",
		calories: 275,
		protein: 3.5,
		carbs: 32,
		fat: 14.5,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-284",
		name: "פופקורן ביתי ללא שמן / באוויר חם",
		category: "חטיפים",
		servingSize: "100 גרם",
		calories: 380,
		protein: 12,
		carbs: 72,
		fat: 4,
		fiber: 14,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-285",
		name: "פופקורן למיקרוגל במלח",
		category: "חטיפים",
		servingSize: "100 גרם",
		calories: 450,
		protein: 8,
		carbs: 58,
		fat: 22,
		fiber: 9,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-286",
		name: "שוקולד מריר 70% מוצקי קקאו",
		category: "מתוקים",
		servingSize: "קוביה (10g)",
		calories: 55,
		protein: .8,
		carbs: 3.5,
		fat: 4,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-287",
		name: "שוקולד מריר 85%",
		category: "מתוקים",
		servingSize: "קוביה (10g)",
		calories: 58,
		protein: 1,
		carbs: 2.2,
		fat: 4.8,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-288",
		name: "שוקולד חלב פרות (עלית)",
		category: "מתוקים",
		servingSize: "קוביה (10g)",
		calories: 53,
		protein: .7,
		carbs: 5.8,
		fat: 3,
		fiber: .3,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-289",
		name: "חטיף פסק זמן",
		category: "מתוקים",
		servingSize: "יחידה (45g)",
		calories: 245,
		protein: 3.2,
		carbs: 26,
		fat: 14,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-290",
		name: "חטיף כיף כף",
		category: "מתוקים",
		servingSize: "יחידה (45g)",
		calories: 235,
		protein: 3,
		carbs: 28,
		fat: 12.5,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-291",
		name: "חטיף אגוזי",
		category: "מתוקים",
		servingSize: "יחידה (45g)",
		calories: 220,
		protein: 2.5,
		carbs: 27,
		fat: 11.5,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-292",
		name: "חטיף טוויסט",
		category: "מתוקים",
		servingSize: "יחידה (28g)",
		calories: 130,
		protein: 1.2,
		carbs: 20,
		fat: 5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-293",
		name: "חטיף טורטית",
		category: "מתוקים",
		servingSize: "יחידה (40g)",
		calories: 210,
		protein: 2,
		carbs: 24,
		fat: 12,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-294",
		name: "עוגיות אוראו",
		category: "מתוקים",
		servingSize: "יחידה 1 (11g)",
		calories: 52,
		protein: .5,
		carbs: 7.8,
		fat: 2.2,
		fiber: .3,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-295",
		name: "עוגיות מזרחיות / עוגיות עבאדי",
		category: "מתוקים",
		servingSize: "100 גרם",
		calories: 460,
		protein: 10,
		carbs: 62,
		fat: 18,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-296",
		name: "גלידת נוקאאוט / מגנום",
		category: "גלידות",
		servingSize: "יחידה (80g)",
		calories: 260,
		protein: 3.2,
		carbs: 24,
		fat: 17,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (גלידות)"
	},
	{
		id: "f-israel-297",
		name: "ארטיק קרח לימון/דובדבן",
		category: "גלידות",
		servingSize: "יחידה (70g)",
		calories: 60,
		protein: 0,
		carbs: 15,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גלידות)"
	},
	{
		id: "f-israel-298",
		name: "שלגון פלדמן לייט (40 קלוריות)",
		category: "גלידות",
		servingSize: "יחידה (50g)",
		calories: 40,
		protein: 1.5,
		carbs: 7,
		fat: .5,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (גלידות)"
	},
	{
		id: "f-israel-299",
		name: "רסק עגבניות 28-30% (טל)",
		category: "שימורים",
		servingSize: "כף (30g)",
		calories: 24,
		protein: 1,
		carbs: 5,
		fat: .1,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-300",
		name: "עגבניות מרוסקות מקולפות (מוטי Mutti)",
		category: "שימורים",
		servingSize: "100 גרם",
		calories: 26,
		protein: 1.2,
		carbs: 4.5,
		fat: .2,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-301",
		name: "זיתים ירוקים מבוקעים (בית השיטה)",
		category: "שימורים",
		servingSize: "10 זיתים (30g)",
		calories: 42,
		protein: .4,
		carbs: .5,
		fat: 4.2,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-302",
		name: "זיתים שחורים מושחזים",
		category: "שימורים",
		servingSize: "10 זיתים (30g)",
		calories: 38,
		protein: .3,
		carbs: 1,
		fat: 3.6,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-303",
		name: "מלפפון חמוץ במלח / בחומץ (יבנה)",
		category: "שימורים",
		servingSize: "יחידה (30g)",
		calories: 5,
		protein: .3,
		carbs: .8,
		fat: .1,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-304",
		name: "טחינה משומשום מלא מוכנה בקופסה",
		category: "שימורים",
		servingSize: "100 גרם",
		calories: 280,
		protein: 8,
		carbs: 8,
		fat: 25,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-305",
		name: "חלב קוקוס לקארי 17% שומן",
		category: "שימורים",
		servingSize: "100 מ\"ל",
		calories: 165,
		protein: 1.5,
		carbs: 2.8,
		fat: 17,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-306",
		name: "קרם קוקוס 20%-22%",
		category: "שימורים",
		servingSize: "100 מ\"ל",
		calories: 215,
		protein: 2,
		carbs: 3.2,
		fat: 22,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-307",
		name: "נודלס להקפצה (מאסטר שף)",
		category: "מזון מוכן",
		servingSize: "100 גרם מבושל",
		calories: 140,
		protein: 4.5,
		carbs: 28,
		fat: 1,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (מזון מוכן)"
	},
	{
		id: "f-israel-308",
		name: "דפי אורז לספרינג רול",
		category: "דגנים ופחמימות",
		servingSize: "דף 1 (10g)",
		calories: 33,
		protein: .6,
		carbs: 7.8,
		fat: .1,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-309",
		name: "שקדי מרק (אסם)",
		category: "תוספות",
		servingSize: "כף (10g)",
		calories: 53,
		protein: 1,
		carbs: 5.2,
		fat: 3.2,
		fiber: .3,
		notes: "מוצר מזון מרשתות השיווק בישראל (תוספות)"
	},
	{
		id: "f-israel-310",
		name: "סלט כרוב אדום במיונז מוכן",
		category: "סלטים מוכנים",
		servingSize: "100 גרם",
		calories: 160,
		protein: 1.2,
		carbs: 8,
		fat: 14,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (סלטים מוכנים)"
	},
	{
		id: "f-israel-311",
		name: "סלט טורקי מוכן (צבר)",
		category: "סלטים מוכנים",
		servingSize: "100 גרם",
		calories: 90,
		protein: 1.5,
		carbs: 10,
		fat: 5,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (סלטים מוכנים)"
	},
	{
		id: "f-israel-312",
		name: "סלט חצילים בטחינה מוכן",
		category: "סלטים מוכנים",
		servingSize: "100 גרם",
		calories: 140,
		protein: 2.5,
		carbs: 6,
		fat: 12,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (סלטים מוכנים)"
	},
	{
		id: "f-israel-313",
		name: "סלט מטבוחה אסלית (אחלה)",
		category: "סלטים מוכנים",
		servingSize: "100 גרם",
		calories: 75,
		protein: 1.4,
		carbs: 8.5,
		fat: 4,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (סלטים מוכנים)"
	},
	{
		id: "f-israel-314",
		name: "קפה שחור / נס קפה ללא חלב וללא סוכר",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 2,
		protein: .2,
		carbs: .3,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-315",
		name: "מיץ תפוזים טבעי סחוט (פריגת)",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 90,
		protein: 1.4,
		carbs: 20,
		fat: .2,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-316",
		name: "משקה קולה קלה / זירו Coca Cola Zero",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-317",
		name: "משקה ספרייט זירו / פאנטה זירו",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-318",
		name: "מיץ ענבים תירוש לקידוש",
		category: "משקאות",
		servingSize: "כוס (100 מ\"ל)",
		calories: 70,
		protein: .3,
		carbs: 17,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-319",
		name: "משקה אלוורה עם חתיכות",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 76,
		protein: 0,
		carbs: 19,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-320",
		name: "בירה שחורה נשר מאלט",
		category: "משקאות",
		servingSize: "בקבוק (330 מ\"ל)",
		calories: 115,
		protein: .8,
		carbs: 28,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-321",
		name: "בירה לבנה 5% אלכוהול (גולדסטאר/מכבי)",
		category: "משקאות",
		servingSize: "פחית (330 מ\"ל)",
		calories: 140,
		protein: 1.2,
		carbs: 11,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-322",
		name: "יין אדום יבש",
		category: "משקאות",
		servingSize: "כוס (150 מ\"ל)",
		calories: 125,
		protein: .1,
		carbs: 3.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-323",
		name: "גבינה לבנה 0% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 60,
		protein: 10,
		carbs: 1.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-324",
		name: "גבינה לבנה 1% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 68,
		protein: 10,
		carbs: 1.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-325",
		name: "גבינה לבנה 3% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 84,
		protein: 10,
		carbs: 1.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-326",
		name: "גבינה לבנה 15% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 180,
		protein: 8.5,
		carbs: 1.8,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-327",
		name: "גבינה לבנה 28% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 284,
		protein: 8.5,
		carbs: 1.8,
		fat: 28,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-328",
		name: "גבינה לבנה 0% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 60,
		protein: 10,
		carbs: 1.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-329",
		name: "גבינה לבנה 1% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 68,
		protein: 10,
		carbs: 1.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-330",
		name: "גבינה לבנה 5% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 100,
		protein: 10,
		carbs: 1.8,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-331",
		name: "גבינה לבנה 9% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 132,
		protein: 10,
		carbs: 1.8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-332",
		name: "גבינה לבנה 15% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 180,
		protein: 8.5,
		carbs: 1.8,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-333",
		name: "גבינה לבנה 28% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 284,
		protein: 8.5,
		carbs: 1.8,
		fat: 28,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-334",
		name: "גבינה לבנה 0% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 60,
		protein: 10,
		carbs: 1.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-335",
		name: "גבינה לבנה 1% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 68,
		protein: 10,
		carbs: 1.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-336",
		name: "גבינה לבנה 3% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 84,
		protein: 10,
		carbs: 1.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-337",
		name: "גבינה לבנה 5% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 100,
		protein: 10,
		carbs: 1.8,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-338",
		name: "גבינה לבנה 9% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 132,
		protein: 10,
		carbs: 1.8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-339",
		name: "גבינה לבנה 15% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 180,
		protein: 8.5,
		carbs: 1.8,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-340",
		name: "גבינה לבנה 28% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 284,
		protein: 8.5,
		carbs: 1.8,
		fat: 28,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-341",
		name: "גבינה לבנה 0% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 60,
		protein: 10,
		carbs: 1.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-342",
		name: "גבינה לבנה 1% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 68,
		protein: 10,
		carbs: 1.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-343",
		name: "גבינה לבנה 3% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 84,
		protein: 10,
		carbs: 1.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-344",
		name: "גבינה לבנה 5% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 100,
		protein: 10,
		carbs: 1.8,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-345",
		name: "גבינה לבנה 9% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 132,
		protein: 10,
		carbs: 1.8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-346",
		name: "גבינה לבנה 15% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 180,
		protein: 8.5,
		carbs: 1.8,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-347",
		name: "גבינה לבנה 28% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 284,
		protein: 8.5,
		carbs: 1.8,
		fat: 28,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-348",
		name: "קוטג' 1% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 75,
		protein: 11.2,
		carbs: 1.5,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-349",
		name: "קוטג' 9% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 131,
		protein: 10,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-350",
		name: "קוטג' 1% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 75,
		protein: 11.2,
		carbs: 1.5,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-351",
		name: "קוטג' 3% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 89,
		protein: 11.2,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-352",
		name: "קוטג' 5% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 103,
		protein: 11.2,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-353",
		name: "קוטג' 1% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 75,
		protein: 11.2,
		carbs: 1.5,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-354",
		name: "קוטג' 3% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 89,
		protein: 11.2,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-355",
		name: "קוטג' 5% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 103,
		protein: 11.2,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-356",
		name: "קוטג' 9% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 131,
		protein: 10,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-357",
		name: "קוטג' 1% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 75,
		protein: 11.2,
		carbs: 1.5,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-358",
		name: "קוטג' 3% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 89,
		protein: 11.2,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-359",
		name: "קוטג' 5% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 103,
		protein: 11.2,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-360",
		name: "קוטג' 9% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 131,
		protein: 10,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-361",
		name: "גבינה בולגרית 5% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 14.5,
		carbs: 1.2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-362",
		name: "גבינה בולגרית 9% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 14.5,
		carbs: 1.2,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-363",
		name: "גבינה בולגרית 16% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 207,
		protein: 14.5,
		carbs: 1.2,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-364",
		name: "גבינה בולגרית 24% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 263,
		protein: 14.5,
		carbs: 1.2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-365",
		name: "גבינה בולגרית 5% - צוריאל",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 14.5,
		carbs: 1.2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-366",
		name: "גבינה בולגרית 9% - צוריאל",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 14.5,
		carbs: 1.2,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-367",
		name: "גבינה בולגרית 16% - צוריאל",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 207,
		protein: 14.5,
		carbs: 1.2,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-368",
		name: "גבינה בולגרית 24% - צוריאל",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 263,
		protein: 14.5,
		carbs: 1.2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-369",
		name: "גבינה בולגרית 5% - גד",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 14.5,
		carbs: 1.2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-370",
		name: "גבינה בולגרית 9% - גד",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 14.5,
		carbs: 1.2,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-371",
		name: "גבינה בולגרית 16% - גד",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 207,
		protein: 14.5,
		carbs: 1.2,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-372",
		name: "גבינה בולגרית 24% - גד",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 263,
		protein: 14.5,
		carbs: 1.2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-373",
		name: "גבינה בולגרית 5% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 14.5,
		carbs: 1.2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-374",
		name: "גבינה בולגרית 9% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 14.5,
		carbs: 1.2,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-375",
		name: "גבינה בולגרית 16% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 207,
		protein: 14.5,
		carbs: 1.2,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-376",
		name: "גבינה בולגרית 24% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 263,
		protein: 14.5,
		carbs: 1.2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-377",
		name: "יוגורט דנונה / ביו 0% - תנובה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 40,
		protein: 4.5,
		carbs: 4.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-378",
		name: "יוגורט דנונה / ביו 1.5% - תנובה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 67,
		protein: 4.5,
		carbs: 4.8,
		fat: 1.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-379",
		name: "יוגורט דנונה / ביו 3% - תנובה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 94,
		protein: 4.5,
		carbs: 4.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-380",
		name: "יוגורט דנונה / ביו 4.5% - תנובה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 121,
		protein: 4.5,
		carbs: 4.8,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-381",
		name: "יוגורט דנונה / ביו 0% - שטראוס",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 40,
		protein: 4.5,
		carbs: 4.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-382",
		name: "יוגורט דנונה / ביו 1.5% - שטראוס",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 67,
		protein: 4.5,
		carbs: 4.8,
		fat: 1.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-383",
		name: "יוגורט דנונה / ביו 3% - שטראוס",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 94,
		protein: 4.5,
		carbs: 4.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-384",
		name: "יוגורט דנונה / ביו 4.5% - שטראוס",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 121,
		protein: 4.5,
		carbs: 4.8,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-385",
		name: "יוגורט דנונה / ביו 0% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 40,
		protein: 4.5,
		carbs: 4.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-386",
		name: "יוגורט דנונה / ביו 1.5% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 67,
		protein: 4.5,
		carbs: 4.8,
		fat: 1.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-387",
		name: "יוגורט דנונה / ביו 3% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 94,
		protein: 4.5,
		carbs: 4.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-388",
		name: "יוגורט דנונה / ביו 4.5% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 121,
		protein: 4.5,
		carbs: 4.8,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-389",
		name: "יוגורט דנונה / ביו 0% - שופרסל",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 40,
		protein: 4.5,
		carbs: 4.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-390",
		name: "יוגורט דנונה / ביו 1.5% - שופרסל",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 67,
		protein: 4.5,
		carbs: 4.8,
		fat: 1.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-391",
		name: "יוגורט דנונה / ביו 3% - שופרסל",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 94,
		protein: 4.5,
		carbs: 4.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-392",
		name: "יוגורט דנונה / ביו 4.5% - שופרסל",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 121,
		protein: 4.5,
		carbs: 4.8,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-393",
		name: "חזה עוף אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-394",
		name: "חזה עוף בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-395",
		name: "חזה עוף מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-396",
		name: "חזה עוף מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 1.5,
		fat: 2.5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-397",
		name: "חזה עוף מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-398",
		name: "פרגית עוף אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-399",
		name: "פרגית עוף בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-400",
		name: "פרגית עוף מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-401",
		name: "פרגית עוף מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 1.5,
		fat: 2.5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-402",
		name: "פרגית עוף מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-403",
		name: "כרעי עוף אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-404",
		name: "כרעי עוף בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-405",
		name: "כרעי עוף מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-406",
		name: "כרעי עוף מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 1.5,
		fat: 2.5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-407",
		name: "כרעי עוף מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-408",
		name: "בשר בקר 5% אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-409",
		name: "בשר בקר 5% בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-410",
		name: "בשר בקר 5% מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-411",
		name: "בשר בקר 5% מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 1.5,
		fat: 9,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-412",
		name: "בשר בקר 5% מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-413",
		name: "בשר בקר 12% אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-414",
		name: "בשר בקר 12% בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-415",
		name: "בשר בקר 12% מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-416",
		name: "בשר בקר 12% מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 1.5,
		fat: 9,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-417",
		name: "בשר בקר 12% מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-418",
		name: "סטייק סינטה אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-419",
		name: "סטייק סינטה בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-420",
		name: "סטייק סינטה מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-421",
		name: "סטייק סינטה מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 1.5,
		fat: 6,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-422",
		name: "סטייק סינטה מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-423",
		name: "פילה סלמון אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-424",
		name: "פילה סלמון בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-425",
		name: "פילה סלמון מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-426",
		name: "פילה סלמון מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 1.5,
		fat: 9,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-427",
		name: "פילה סלמון מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-428",
		name: "פילה אמנון אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-429",
		name: "פילה אמנון בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-430",
		name: "פילה אמנון מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-431",
		name: "פילה אמנון מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 1.5,
		fat: 6,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-432",
		name: "פילה אמנון מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-433",
		name: "חזה הודו אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-434",
		name: "חזה הודו בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-435",
		name: "חזה הודו מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-436",
		name: "חזה הודו מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 1.5,
		fat: 2.5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-437",
		name: "חזה הודו מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-438",
		name: "טופו קלאסי אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-439",
		name: "טופו קלאסי בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-440",
		name: "טופו קלאסי מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-441",
		name: "טופו קלאסי מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 1.5,
		fat: 6,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-442",
		name: "טופו קלאסי מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-443",
		name: "אורז לבן (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-444",
		name: "אורז לבן (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-445",
		name: "אורז לבן (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-446",
		name: "אורז לבן (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-447",
		name: "אורז בסמטי (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-448",
		name: "אורז בסמטי (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-449",
		name: "אורז בסמטי (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-450",
		name: "אורז בסמטי (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-451",
		name: "אורז מלא (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-452",
		name: "אורז מלא (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-453",
		name: "אורז מלא (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-454",
		name: "אורז מלא (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-455",
		name: "פסטה קמח מלא (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-456",
		name: "פסטה קמח מלא (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-457",
		name: "פסטה קמח מלא (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-458",
		name: "פסטה קמח מלא (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-459",
		name: "בורגול (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-460",
		name: "בורגול (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-461",
		name: "בורגול (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-462",
		name: "בורגול (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-463",
		name: "קינואה (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-464",
		name: "קינואה (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-465",
		name: "קינואה (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-466",
		name: "קינואה (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-467",
		name: "כוסמת (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-468",
		name: "כוסמת (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-469",
		name: "כוסמת (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-470",
		name: "כוסמת (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-471",
		name: "תפוח עץ (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-472",
		name: "תפוח עץ (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-473",
		name: "תפוח עץ (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-474",
		name: "אגס (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-475",
		name: "אגס (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-476",
		name: "אגס (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-477",
		name: "שזיף (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-478",
		name: "שזיף (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-479",
		name: "שזיף (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-480",
		name: "אפרסק (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-481",
		name: "אפרסק (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-482",
		name: "אפרסק (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-483",
		name: "תמר (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-484",
		name: "תמר (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-485",
		name: "תמר (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-486",
		name: "תאנה (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-487",
		name: "תאנה (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-488",
		name: "תאנה (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	}
];
var MUSCLE_GROUPS = [
	"חזה",
	"חזה עליון",
	"חזה תחתון",
	"גב",
	"גב רחב",
	"טרפזים",
	"גב תחתון",
	"כתפיים",
	"כתף קדמית",
	"כתף צידית",
	"כתף אחורית",
	"ביצפס (יד קדמית)",
	"טריצפס (יד אחורית)",
	"אמות",
	"בטן",
	"אלכסונים",
	"ישבן",
	"ארבע ראשי",
	"המסטרינג",
	"תאומים",
	"מקרבים",
	"מרחיקים",
	"כופפי הירך",
	"צוואר",
	"גוף מלא",
	"אירובי",
	"אחר"
];
var EQUIPMENT = [
	"מוט",
	"סמית' משין",
	"משקוליות יד",
	"פולי / כבלים",
	"מכונה",
	"מוט W / EZ",
	"קטלבל",
	"משקל גוף",
	"גומיית התנגדות",
	"משקל גוף בתוספת משקל",
	"אחר"
];
var EXERCISE_CATEGORIES = [
	"מורכב",
	"בידוד",
	"עזר",
	"מכונה",
	"אירובי",
	"גמישות / ניעות",
	"אחר"
];
var DEFAULT_MEALS = [
	"ארוחת בוקר",
	"נשנוש בוקר",
	"ארוחת צהריים",
	"נשנוש אחה\"צ",
	"ארוחת ערב",
	"נשנוש לילה"
];
var CARDIO_TYPES = [
	"הליכון (Treadmill)",
	"הליכה",
	"ריצה",
	"אופני כושר",
	"אליפטיקל",
	"מדרגות (StairMaster)",
	"חתירה (Rowing)",
	"שחייה",
	"טניס",
	"אימון אינטרוולים (HIIT)"
];
var KEY = "gymtrack.v1";
var uid = () => Math.random().toString(36).slice(2, 10);
/** Local calendar date as YYYY-MM-DD (used to key nutrition days). */
var todayKey = (d = /* @__PURE__ */ new Date()) => {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
var seed = () => {
	const ex = [...EXPANDED_EXERCISES];
	const day = (id, name, items) => ({
		id,
		name,
		notes: "",
		items: items.map((s, i) => ({
			id: `${id}-i${i}`,
			exerciseId: s.exerciseId,
			sets: s.sets,
			reps: s.reps,
			repType: s.repMin != null ? "range" : "fixed",
			repMin: s.repMin,
			repMax: s.repMax,
			weight: s.weight,
			rest: s.rest,
			notes: "",
			workingSets: Array.from({ length: s.sets }, (_, setIdx) => ({
				id: `${id}-i${i}-set-${setIdx}`,
				setNumber: setIdx + 1,
				weight: s.weight,
				reps: s.repMin ?? s.reps,
				repMax: s.repMax
			}))
		}))
	});
	const workouts = [
		day("w-lower-1", "פלג גוף תחתון 1", [
			{
				exerciseId: "ex-squat",
				sets: 4,
				reps: 6,
				weight: 80,
				rest: 150
			},
			{
				exerciseId: "ex-hipthrust",
				sets: 4,
				reps: 8,
				repMin: 8,
				repMax: 10,
				weight: 60,
				rest: 90
			},
			{
				exerciseId: "ex-rdl",
				sets: 3,
				reps: 10,
				repMin: 8,
				repMax: 10,
				weight: 50,
				rest: 90
			},
			{
				exerciseId: "ex-plank",
				sets: 3,
				reps: 1,
				weight: 0,
				rest: 60
			}
		]),
		day("w-upper-1", "פלג גוף עליון 1", [
			{
				exerciseId: "ex-bench",
				sets: 4,
				reps: 8,
				repMin: 8,
				repMax: 10,
				weight: 60,
				rest: 120
			},
			{
				exerciseId: "ex-row",
				sets: 4,
				reps: 10,
				repMin: 10,
				repMax: 12,
				weight: 45,
				rest: 90
			},
			{
				exerciseId: "ex-ohp",
				sets: 3,
				reps: 8,
				repMin: 8,
				repMax: 10,
				weight: 35,
				rest: 90
			},
			{
				exerciseId: "ex-curl",
				sets: 3,
				reps: 12,
				weight: 12,
				rest: 60
			}
		]),
		day("w-lower-2", "פלג גוף תחתון 2", [
			{
				exerciseId: "ex-squat",
				sets: 3,
				reps: 10,
				weight: 65,
				rest: 120
			},
			{
				exerciseId: "ex-hipthrust",
				sets: 4,
				reps: 12,
				weight: 55,
				rest: 90
			},
			{
				exerciseId: "ex-rdl",
				sets: 3,
				reps: 12,
				weight: 45,
				rest: 90
			}
		]),
		day("w-upper-2", "פלג גוף עליון 2", [
			{
				exerciseId: "ex-row",
				sets: 4,
				reps: 10,
				weight: 50,
				rest: 90
			},
			{
				exerciseId: "ex-bench",
				sets: 3,
				reps: 10,
				repMin: 8,
				repMax: 10,
				weight: 55,
				rest: 90
			},
			{
				exerciseId: "ex-ohp",
				sets: 3,
				reps: 10,
				weight: 30,
				rest: 90
			},
			{
				exerciseId: "ex-curl",
				sets: 3,
				reps: 12,
				repMin: 10,
				repMax: 12,
				weight: 12,
				rest: 60
			}
		])
	];
	return {
		exercises: ex,
		customExercises: [],
		workouts,
		programs: [{
			id: "p-default",
			name: "תכנית אימונים 4 ימים",
			notes: "חלוקת פלג גוף תחתון / פלג גוף עליון",
			dayIds: workouts.map((w) => w.id)
		}],
		history: [],
		foods: [...ISRAELI_FOOD_DATABASE],
		nutritionDays: [],
		nutritionTargets: {
			calories: 2e3,
			protein: 140,
			carbs: 200,
			fat: 65
		},
		mealTemplate: [...DEFAULT_MEALS],
		recipes: [],
		recentFoods: [],
		favoriteFoods: [],
		bodyWeightLogs: [{
			id: "bw-initial",
			date: "2025-01-01",
			weight: 65
		}],
		cardioLogs: [],
		userProfile: {
			weight: 65,
			height: 165,
			age: 26,
			gender: "female",
			workoutsPerWeek: 4
		}
	};
};
var data = seed();
var hydrated = false;
var listeners = /* @__PURE__ */ new Set();
/** Merge exercise database so saved user data retains all standard exercises and user custom exercises */
function mergeSeedExercises(existing, custom = []) {
	const byId = /* @__PURE__ */ new Map();
	for (const seedEx of EXPANDED_EXERCISES) byId.set(seedEx.id, seedEx);
	for (const ex of existing) if (ex.isCustom || !byId.has(ex.id)) byId.set(ex.id, ex);
	for (const cEx of custom) byId.set(cEx.id, {
		...cEx,
		isCustom: true
	});
	return Array.from(byId.values());
}
/** Merge food database so saved data retains all Israeli supermarket items */
function mergeSeedFoods(existing) {
	const byId = new Map(existing.map((f) => [f.id, f]));
	const byName = new Map(existing.map((f) => [f.name.toLocaleLowerCase(), f]));
	for (const seedFood of ISRAELI_FOOD_DATABASE) {
		if (byId.has(seedFood.id)) continue;
		if (byName.has(seedFood.name.toLocaleLowerCase())) continue;
		byId.set(seedFood.id, seedFood);
	}
	return Array.from(byId.values());
}
/** Ensure older saved data still works cleanly. */
function migrate(d) {
	const workouts = d.workouts ?? [];
	let programs = d.programs ?? [];
	if (!programs.length && workouts.length) programs = [{
		id: "p-migrated",
		name: "תכנית אימונים",
		notes: "",
		dayIds: workouts.map((w) => w.id)
	}];
	const customExercises = d.customExercises ?? (d.exercises ?? []).filter((e) => e.isCustom);
	return {
		exercises: mergeSeedExercises(d.exercises ?? [], customExercises),
		customExercises,
		workouts: workouts.length ? workouts : seed().workouts,
		programs: programs.length ? programs : seed().programs,
		history: d.history ?? [],
		foods: mergeSeedFoods(d.foods ?? []),
		nutritionDays: d.nutritionDays ?? [],
		nutritionTargets: d.nutritionTargets ?? seed().nutritionTargets,
		mealTemplate: d.mealTemplate?.length ? d.mealTemplate : [...DEFAULT_MEALS],
		recipes: d.recipes ?? [],
		recentFoods: d.recentFoods ?? [],
		favoriteFoods: d.favoriteFoods ?? [],
		bodyWeightLogs: d.bodyWeightLogs?.length ? d.bodyWeightLogs : [{
			id: "bw-initial",
			date: todayKey(),
			weight: d.userProfile?.weight ?? 65
		}],
		cardioLogs: d.cardioLogs ?? [],
		userProfile: d.userProfile ?? seed().userProfile
	};
}
function load() {
	if (hydrated || typeof window === "undefined") return;
	hydrated = true;
	try {
		const raw = window.localStorage.getItem(KEY);
		if (raw) data = migrate({
			...seed(),
			...JSON.parse(raw)
		});
	} catch {}
}
function persist() {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(KEY, JSON.stringify(data));
	} catch {}
}
function set(next) {
	data = next;
	persist();
	listeners.forEach((l) => l());
}
function subscribe(cb) {
	load();
	listeners.add(cb);
	return () => listeners.delete(cb);
}
var serverSnapshot = seed();
function useGym() {
	return (0, import_react.useSyncExternalStore)(subscribe, () => {
		load();
		return data;
	}, () => serverSnapshot);
}
function repLabel(item) {
	if (item.repType === "range" && item.repMin != null && item.repMax != null) return `${item.repMin}–${item.repMax}`;
	return String(item.reps);
}
function saveExercise(ex) {
	const updatedExercises = data.exercises.some((e) => e.id === ex.id) ? data.exercises.map((e) => e.id === ex.id ? ex : e) : [...data.exercises, ex];
	const customList = ex.isCustom ? data.customExercises?.some((c) => c.id === ex.id) ? (data.customExercises ?? []).map((c) => c.id === ex.id ? ex : c) : [...data.customExercises ?? [], ex] : data.customExercises;
	set({
		...data,
		exercises: updatedExercises,
		customExercises: customList
	});
}
function saveCustomExercise(exInput) {
	const newEx = {
		...exInput,
		id: exInput.id || `custom-${uid()}`,
		isCustom: true
	};
	saveExercise(newEx);
	return newEx;
}
function deleteCustomExercise(id) {
	deleteExercise(id);
}
function deleteExercise(id) {
	set({
		...data,
		exercises: data.exercises.filter((e) => e.id !== id),
		customExercises: (data.customExercises ?? []).filter((e) => e.id !== id),
		workouts: data.workouts.map((w) => ({
			...w,
			items: w.items.filter((i) => i.exerciseId !== id)
		}))
	});
}
function emptyExercise() {
	return {
		id: uid(),
		name: "",
		muscleGroup: "חזה",
		muscleGroups: ["חזה"],
		secondaryMuscles: [],
		category: "מורכב",
		equipment: "מוט",
		description: "",
		instructions: "",
		videoUrl: "",
		images: [],
		notes: "",
		tips: ""
	};
}
function saveWorkout(w) {
	const exists = data.workouts.some((x) => x.id === w.id);
	set({
		...data,
		workouts: exists ? data.workouts.map((x) => x.id === w.id ? w : x) : [...data.workouts, w]
	});
}
function saveWorkoutInProgram(programId, w) {
	const workouts = data.workouts.some((x) => x.id === w.id) ? data.workouts.map((x) => x.id === w.id ? w : x) : [...data.workouts, w];
	const programs = data.programs.map((p) => p.id === programId && !p.dayIds.includes(w.id) ? {
		...p,
		dayIds: [...p.dayIds, w.id]
	} : p);
	set({
		...data,
		workouts,
		programs
	});
}
function deleteWorkout(id) {
	set({
		...data,
		workouts: data.workouts.filter((w) => w.id !== id),
		programs: data.programs.map((p) => ({
			...p,
			dayIds: p.dayIds.filter((d) => d !== id)
		}))
	});
}
function duplicateWorkoutDay(programId, dayId) {
	const day = data.workouts.find((w) => w.id === dayId);
	const program = data.programs.find((p) => p.id === programId);
	if (!day || !program) return;
	const copy = {
		...day,
		id: uid(),
		name: `${day.name} (עותק)`,
		items: day.items.map((i) => ({
			...i,
			id: uid()
		}))
	};
	const index = program.dayIds.indexOf(dayId);
	const dayIds = [...program.dayIds];
	dayIds.splice(index + 1, 0, copy.id);
	set({
		...data,
		workouts: [...data.workouts, copy],
		programs: data.programs.map((p) => p.id === programId ? {
			...p,
			dayIds
		} : p)
	});
}
function reorderProgramDays(programId, dayIds) {
	set({
		...data,
		programs: data.programs.map((p) => p.id === programId ? {
			...p,
			dayIds
		} : p)
	});
}
function emptyWorkout() {
	return {
		id: uid(),
		name: "",
		notes: "",
		items: []
	};
}
function emptyItem(exerciseId) {
	return {
		id: uid(),
		exerciseId,
		sets: 3,
		reps: 10,
		repType: "fixed",
		weight: 20,
		rest: 90,
		notes: "",
		warmups: [],
		workingSets: Array.from({ length: 3 }, (_, i) => ({
			id: uid(),
			setNumber: i + 1,
			weight: 20,
			reps: 10
		}))
	};
}
function emptyWarmup() {
	return {
		id: uid(),
		weight: 20,
		reps: 10
	};
}
function saveProgram(p) {
	const exists = data.programs.some((x) => x.id === p.id);
	set({
		...data,
		programs: exists ? data.programs.map((x) => x.id === p.id ? p : x) : [...data.programs, p]
	});
}
function createProgram(name) {
	const p = {
		id: uid(),
		name: name.trim() || "תכנית חדשה",
		notes: "",
		dayIds: []
	};
	set({
		...data,
		programs: [...data.programs, p]
	});
	return p;
}
function deleteProgram(id) {
	const program = data.programs.find((p) => p.id === id);
	const orphan = new Set(program?.dayIds ?? []);
	set({
		...data,
		programs: data.programs.filter((p) => p.id !== id),
		workouts: data.workouts.filter((w) => !orphan.has(w.id))
	});
}
function duplicateProgram(id) {
	const program = data.programs.find((p) => p.id === id);
	if (!program) return;
	const newDays = [];
	const dayIds = program.dayIds.map((dayId) => {
		const day = data.workouts.find((w) => w.id === dayId);
		if (!day) return dayId;
		const copy = {
			...day,
			id: uid(),
			items: day.items.map((i) => ({
				...i,
				id: uid()
			}))
		};
		newDays.push(copy);
		return copy.id;
	});
	set({
		...data,
		workouts: [...data.workouts, ...newDays],
		programs: [...data.programs, {
			id: uid(),
			name: `${program.name} (עותק)`,
			notes: program.notes,
			dayIds
		}]
	});
}
function saveSession(session) {
	set({
		...data,
		history: [session, ...data.history]
	});
}
function deleteSession(id) {
	set({
		...data,
		history: data.history.filter((s) => s.id !== id)
	});
}
function lastPerformance(history, exerciseId) {
	for (const s of history) {
		const e = s.entries.find((x) => x.exerciseId === exerciseId);
		if (e) {
			const working = e.sets.filter((x) => !x.warmup);
			if (working.length) return {
				date: s.date,
				sets: working
			};
		}
	}
	return null;
}
function personalRecords(history, exerciseId) {
	let heaviest = 0;
	let bestRepsAtHeaviest = 0;
	let bestEst = 0;
	for (const s of history) for (const e of s.entries) {
		if (e.exerciseId !== exerciseId) continue;
		for (const set of e.sets) {
			if (set.warmup || set.reps === 0) continue;
			if (set.weight > heaviest) {
				heaviest = set.weight;
				bestRepsAtHeaviest = set.reps;
			} else if (set.weight === heaviest && set.reps > bestRepsAtHeaviest) bestRepsAtHeaviest = set.reps;
			const est = set.weight * (1 + set.reps / 30);
			if (est > bestEst) bestEst = est;
		}
	}
	if (heaviest === 0 && bestEst === 0) return null;
	return {
		heaviest,
		bestRepsAtHeaviest,
		estimatedMax: Math.round(bestEst)
	};
}
function saveUserProfile(profile) {
	const updatedWeight = profile.weight;
	const logs = [...data.bodyWeightLogs ?? []];
	const today = todayKey();
	const existingIdx = logs.findIndex((l) => l.date === today);
	if (existingIdx >= 0) logs[existingIdx] = {
		...logs[existingIdx],
		weight: updatedWeight
	};
	else logs.unshift({
		id: uid(),
		date: today,
		weight: updatedWeight
	});
	set({
		...data,
		userProfile: profile,
		bodyWeightLogs: logs
	});
}
function saveBodyWeight(weight, dateStr = todayKey()) {
	const logs = [...data.bodyWeightLogs ?? []];
	const idx = logs.findIndex((l) => l.date === dateStr);
	if (idx >= 0) logs[idx] = {
		...logs[idx],
		weight
	};
	else logs.unshift({
		id: uid(),
		date: dateStr,
		weight
	});
	const profile = {
		...data.userProfile ?? { weight: 65 },
		weight
	};
	set({
		...data,
		bodyWeightLogs: logs,
		userProfile: profile
	});
}
/** RMR Calculation using Mifflin-St Jeor formula */
function calculateRmr(profile) {
	const p = profile ?? data.userProfile ?? {
		weight: 65,
		height: 165,
		age: 26,
		gender: "female"
	};
	const w = p.weight || 65;
	const h = p.height || 165;
	const a = p.age || 26;
	const isFemale = p.gender !== "male";
	const baseRmr = 10 * w + 6.25 * h - 5 * a + (isFemale ? -161 : 5);
	const rmr = Math.round(baseRmr);
	const frequency = p.workoutsPerWeek ?? 4;
	let mult = 1.2;
	if (frequency >= 1 && frequency <= 2) mult = 1.375;
	else if (frequency >= 3 && frequency <= 4) mult = 1.55;
	else if (frequency >= 5) mult = 1.725;
	return {
		rmr,
		tdee: Math.round(rmr * mult),
		weight: w
	};
}
function saveCardioLog(log) {
	const entry = {
		id: uid(),
		...log
	};
	set({
		...data,
		cardioLogs: [entry, ...data.cardioLogs ?? []]
	});
}
function calculateCardioCalories(type, durationMin, weightKg = 65, speedKmH = 8, inclinePct = 0) {
	if (durationMin <= 0) return 0;
	let met = 5;
	if (type.includes("הליכון") || type.includes("Treadmill") || type.includes("ריצה")) {
		met = speedKmH >= 10 ? 10 : speedKmH >= 8 ? 8 : 4.5;
		if (inclinePct > 0) met += inclinePct * .4;
	} else if (type.includes("הליכה")) met = 3.8;
	else if (type.includes("אופניים")) met = 6.8;
	else if (type.includes("מדרגות")) met = 8.5;
	else if (type.includes("שחייה")) met = 7;
	else if (type.includes("HIIT")) met = 9;
	const calories = met * weightKg * (durationMin / 60);
	return Math.round(calories);
}
function saveFood(food) {
	const exists = data.foods.some((f) => f.id === food.id);
	set({
		...data,
		foods: exists ? data.foods.map((f) => f.id === food.id ? food : f) : [...data.foods, food]
	});
}
function saveCustomFood(foodInput) {
	const newFood = {
		...foodInput,
		id: foodInput.id || `custom-food-${uid()}`,
		isCustom: true
	};
	saveFood(newFood);
	return newFood;
}
function toggleFavoriteFood(foodId) {
	const favorites = new Set(data.favoriteFoods ?? []);
	if (favorites.has(foodId)) favorites.delete(foodId);
	else favorites.add(foodId);
	set({
		...data,
		favoriteFoods: Array.from(favorites)
	});
}
function deleteFood(id) {
	set({
		...data,
		foods: data.foods.filter((f) => f.id !== id)
	});
}
function emptyFood() {
	return {
		id: uid(),
		name: "",
		servingSize: "100 גרם",
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0
	};
}
function saveNutritionTargets(targets) {
	set({
		...data,
		nutritionTargets: targets
	});
}
function nutritionDay(d, date) {
	const found = d.nutritionDays.find((x) => x.date === date);
	if (found) return found;
	return {
		date,
		meals: d.mealTemplate.map((name, i) => ({
			id: `tmpl-${date}-${i}`,
			name,
			foods: []
		}))
	};
}
function withDay(date, updater) {
	const existing = data.nutritionDays.find((x) => x.date === date);
	const next = updater(existing ?? {
		date,
		meals: data.mealTemplate.map((name) => ({
			id: uid(),
			name,
			foods: []
		}))
	});
	const days = existing ? data.nutritionDays.map((x) => x.date === date ? next : x) : [next, ...data.nutritionDays];
	set({
		...data,
		nutritionDays: days
	});
}
function addMeal(date, name) {
	withDay(date, (day) => ({
		...day,
		meals: [...day.meals, {
			id: uid(),
			name: name.trim() || "ארוחה חדשה",
			foods: []
		}]
	}));
}
function renameMeal(date, mealId, name) {
	withDay(date, (day) => ({
		...day,
		meals: day.meals.map((m) => m.id === mealId ? {
			...m,
			name
		} : m)
	}));
}
function addFoodToMeal(date, mealId, food) {
	withDay(date, (day) => ({
		...day,
		meals: day.meals.map((m) => m.id === mealId ? {
			...m,
			foods: [...m.foods, food]
		} : m)
	}));
	if (food.foodId) {
		const recent = [food.foodId, ...(data.recentFoods ?? []).filter((id) => id !== food.foodId)];
		set({
			...data,
			recentFoods: recent.slice(0, 20)
		});
	}
}
function updateMealFood(date, mealId, food) {
	withDay(date, (day) => ({
		...day,
		meals: day.meals.map((m) => m.id === mealId ? {
			...m,
			foods: m.foods.map((f) => f.id === food.id ? food : f)
		} : m)
	}));
}
function removeMealFood(date, mealId, foodId) {
	withDay(date, (day) => ({
		...day,
		meals: day.meals.map((m) => m.id === mealId ? {
			...m,
			foods: m.foods.filter((f) => f.id !== foodId)
		} : m)
	}));
}
/** Convert a library food into a meal food entry (quantity 1). */
function mealFoodFromLibrary(food) {
	return {
		id: uid(),
		foodId: food.id,
		name: food.name,
		servingSize: food.servingSize,
		quantity: 1,
		calories: food.calories,
		protein: food.protein,
		carbs: food.carbs,
		fat: food.fat,
		fiber: food.fiber,
		notes: food.notes
	};
}
function normalizeSearch(s) {
	return s.toLocaleLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/['"-]/g, "").trim();
}
/**
* Forgiving exercise search supporting Hebrew names, English names, and aliases.
*/
function searchExercises(exercises, query) {
	const normalized = normalizeSearch(query);
	if (!normalized) return exercises;
	const tokens = normalized.split(/\s+/).filter(Boolean);
	return exercises.filter((ex) => {
		const name = normalizeSearch(ex.name);
		const english = normalizeSearch(ex.englishName ?? "");
		const muscle = normalizeSearch(ex.muscleGroup);
		const equipment = normalizeSearch(ex.equipment);
		const category = normalizeSearch(ex.category ?? "");
		const customMuscle = normalizeSearch(ex.customMuscleGroup ?? "");
		const terms = (ex.searchTerms ?? []).map(normalizeSearch);
		return tokens.every((token) => name.includes(token) || english.includes(token) || muscle.includes(token) || equipment.includes(token) || category.includes(token) || customMuscle.includes(token) || terms.some((t) => t.includes(token)));
	});
}
/**
* Forgiving Hebrew food search (e.g., "קוטג" matches "קוטג'", "ביצה" matches "ביצים").
*/
function searchFoods(foods, query) {
	const normalized = normalizeSearch(query);
	if (!normalized) return foods;
	const tokens = normalized.split(/\s+/).filter(Boolean);
	return foods.filter((food) => {
		const name = normalizeSearch(food.name);
		const category = normalizeSearch(food.category ?? "");
		const english = normalizeSearch(food.englishName ?? "");
		const terms = (food.searchTerms ?? []).map(normalizeSearch);
		return tokens.every((token) => name.includes(token) || category.includes(token) || english.includes(token) || terms.some((t) => t.includes(token)));
	});
}
/**
* Finds food replacements with EXACT calorie matching formula.
*/
function findFoodReplacements(foods, current, query = "") {
	const targetCal = (current.calories ?? 0) * (current.quantity ?? 1);
	return searchFoods(foods, query).filter((food) => {
		if (current.foodId && food.id === current.foodId) return false;
		if (!current.foodId && current.name && food.name === current.name) return false;
		return true;
	}).map((food) => {
		const requiredQty = food.calories > 0 ? targetCal / food.calories : 1;
		return {
			food,
			calculatedQuantity: round1(requiredQty),
			calculatedCalories: Math.round(food.calories * requiredQty),
			calculatedProtein: round1(food.protein * requiredQty),
			calculatedCarbs: round1(food.carbs * requiredQty),
			calculatedFat: round1(food.fat * requiredQty),
			score: Math.abs(food.calories - (current.calories ?? 0))
		};
	}).sort((a, b) => a.score - b.score || a.food.name.localeCompare(b.food.name));
}
var round1 = (n) => Math.round(n * 10) / 10;
/** Totals for a list of meal foods, scaled by each food's quantity. */
function foodTotals(foods) {
	return foods.reduce((t, f) => ({
		calories: t.calories + f.calories * f.quantity,
		protein: t.protein + f.protein * f.quantity,
		carbs: t.carbs + f.carbs * f.quantity,
		fat: t.fat + f.fat * f.quantity,
		fiber: t.fiber + (f.fiber ?? 0) * f.quantity
	}), {
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0,
		fiber: 0
	});
}
/** Totals across every meal in a day. */
function dayTotals(day) {
	const t = foodTotals(day.meals.flatMap((m) => m.foods));
	return {
		calories: Math.round(t.calories),
		protein: round1(t.protein),
		carbs: round1(t.carbs),
		fat: round1(t.fat),
		fiber: round1(t.fiber)
	};
}
function AuthModal({ open, onClose }) {
	const gymData = useGym();
	const [user, setUser] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("signin");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [message, setMessage] = (0, import_react.useState)(null);
	const [migrating, setMigrating] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!supabase || !isSupabaseConfigured) return;
		supabase.auth.getUser().then(({ data }) => {
			setUser(data.user ? {
				id: data.user.id,
				email: data.user.email
			} : null);
		});
		const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
			const authUser = session?.user ? {
				id: session.user.id,
				email: session.user.email
			} : null;
			setUser(authUser);
		});
		return () => {
			authListener.subscription.unsubscribe();
		};
	}, []);
	if (!open) return null;
	const handleAuth = async (e) => {
		e.preventDefault();
		if (!supabase || !isSupabaseConfigured) {
			setError("מערכת Supabase אינה מוגדרת. יש להגדיר מפתחות סביבה.");
			return;
		}
		setLoading(true);
		setError(null);
		setMessage(null);
		try {
			if (mode === "signup") {
				const { data, error: err } = await supabase.auth.signUp({
					email,
					password
				});
				if (err) throw err;
				setMessage("הרשמה בוצעה בהצלחה! אם נדרש אימות מייל, בדקי את תיבת הדואר הנכנס.");
				if (data.user) {
					setUser({
						id: data.user.id,
						email: data.user.email
					});
					setMigrating(true);
					await migrateLocalToSupabase(data.user.id, gymData);
					setMigrating(false);
				}
			} else {
				const { data, error: err } = await supabase.auth.signInWithPassword({
					email,
					password
				});
				if (err) throw err;
				setMessage("התחברת בהצלחה!");
				if (data.user) {
					setUser({
						id: data.user.id,
						email: data.user.email
					});
					if (await isMigrationNeeded(data.user.id)) {
						setMigrating(true);
						await migrateLocalToSupabase(data.user.id, gymData);
						setMigrating(false);
					}
				}
			}
		} catch (err) {
			const msg = err instanceof Error ? err.message : "שגיאה בתהליך ההתחברות";
			setError(msg);
		} finally {
			setLoading(false);
		}
	};
	const handleSignOut = async () => {
		if (!supabase) return;
		setLoading(true);
		await supabase.auth.signOut();
		setUser(null);
		setMessage("התנתקת בהצלחה.");
		setLoading(false);
	};
	const handleManualMigrate = async () => {
		if (!user) return;
		setMigrating(true);
		setError(null);
		const res = await migrateLocalToSupabase(user.id, gymData);
		setMigrating(false);
		if (res.success) setMessage("הנתונים השרותיים והמקומיים סונכרנו בהצלחה לענן!");
		else setError(`שגיאה בסנכרון: ${res.error}`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-xs p-0 pb-20 sm:p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: (el) => {
				if (el) el.scrollTop = 0;
			},
			className: "surface-card w-full max-w-md max-h-[85vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5 text-start shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-200",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between pb-3 border-b border-border/40 mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "h-5 w-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-[17px] font-bold text-ink",
						children: user ? "חשבון משתמש וסנכרון ענן" : mode === "signin" ? "התחברות לחשבון" : "הרשמה לחשבון חדש"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "press grid h-8 w-8 place-items-center rounded-full bg-secondary text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
				})]
			}), !isSupabaseConfigured ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-amber-500/10 border border-amber-500/20 p-4 text-[13px] text-amber-900 dark:text-amber-200",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 font-bold mb-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4 shrink-0 text-amber-600" }), "מפתחות Supabase חסרים"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[12px] leading-relaxed",
					children: [
						"האפליקציה פועלת כעת במצב מקומי (localStorage). כדי לחבר את האפליקציה לענן Supabase, יש להגדיר את משתני הסביבה ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "VITE_SUPABASE_URL" }),
						" ו-",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "VITE_SUPABASE_ANON_KEY" }),
						"."
					]
				})]
			}) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-2xl border border-primary/20 bg-primary/5 p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-2xl bg-primary text-primary-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-primary tracking-wider uppercase",
									children: "מחוברת כעת"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold text-ink text-[14px]",
									children: user.email
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border/40 bg-secondary p-4 space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-[13px] font-bold text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-emerald-600" }), "סטטוס אבטחה וסנכרון"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-muted-foreground leading-relaxed",
							children: "הנתונים שלך מוגנים באמצעות Row Level Security (RLS). רק את יכולה לצפות ולעדכן את התכניות והאימונים שלך."
						})]
					}),
					migrating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] font-semibold text-primary animate-pulse text-center",
						children: "מסנכרן נתונים לענן... אנא המתיני"
					}) : null,
					message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl bg-emerald-500/10 p-3 text-[12.5px] font-semibold text-emerald-700",
						children: message
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl bg-destructive/10 p-3 text-[12.5px] font-semibold text-destructive",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleManualMigrate,
							disabled: migrating,
							className: "press flex-1 flex h-11 items-center justify-center gap-2 rounded-2xl bg-primary text-primary-foreground font-semibold text-[13.5px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "h-4 w-4" }), "סנכרן נתונים כעת"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleSignOut,
							disabled: loading,
							className: "press flex h-11 items-center justify-center gap-2 rounded-2xl bg-secondary px-4 font-semibold text-destructive text-[13.5px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), "התנתק"]
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleAuth,
				className: "space-y-3.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex rounded-2xl bg-secondary p-1 text-[13px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMode("signin"),
							className: `press flex-1 py-2 rounded-xl transition-all ${mode === "signin" ? "bg-primary text-primary-foreground shadow-xs" : "text-muted-foreground"}`,
							children: "התחברות"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMode("signup"),
							className: `press flex-1 py-2 rounded-xl transition-all ${mode === "signup" ? "bg-primary text-primary-foreground shadow-xs" : "text-muted-foreground"}`,
							children: "הרשמה"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-[11px] font-semibold tracking-wider text-muted-foreground uppercase mb-1",
						children: "אימייל"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "email",
						required: true,
						value: email,
						onChange: (e) => setEmail(e.target.value),
						placeholder: "your@email.com",
						className: "w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3 text-[14px] outline-none focus:border-primary"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-[11px] font-semibold tracking-wider text-muted-foreground uppercase mb-1",
						children: "סיסמה"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "password",
						required: true,
						minLength: 6,
						value: password,
						onChange: (e) => setPassword(e.target.value),
						placeholder: "••••••••",
						className: "w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3 text-[14px] outline-none focus:border-primary"
					})] }),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl bg-destructive/10 p-3 text-[12.5px] font-semibold text-destructive",
						children: error
					}) : null,
					message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl bg-emerald-500/10 p-3 text-[12.5px] font-semibold text-emerald-700",
						children: message
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						type: "submit",
						disabled: loading,
						children: loading ? "מעבד..." : mode === "signin" ? "התחברי לחשבון" : "צרי חשבון חדש"
					})
				]
			})]
		})
	});
}
var NAV = [
	{
		to: "/",
		label: "בית",
		id: "home",
		icon: House
	},
	{
		to: "/programs",
		label: "תוכניות",
		id: "programs",
		icon: LayoutGrid
	},
	{
		to: "/exercises",
		label: "תרגילים",
		id: "exercises",
		icon: Dumbbell
	},
	{
		to: "/nutrition",
		label: "תזונה",
		id: "nutrition",
		icon: Apple
	},
	{
		to: "/history",
		label: "היסטוריה",
		id: "history",
		icon: History
	}
];
function AppShell({ title, subtitle, kicker, action, children }) {
	const [authOpen, setAuthOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-[100dvh] w-full bg-background text-foreground",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthModal, {
				open: authOpen,
				onClose: () => setAuthOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-border/30 bg-background/85 backdrop-blur-xl",
				style: { paddingTop: "max(0.6rem, env(safe-area-inset-top))" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto w-full max-w-md px-5 pb-3.5 pt-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 text-start",
							children: [
								kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1 text-[11px] font-bold tracking-[0.14em] text-primary uppercase",
									children: kicker
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "truncate font-display text-[26px] font-extrabold leading-[1.1] tracking-tight text-ink",
									children: title
								}),
								subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 truncate text-[13px] leading-snug text-muted-foreground",
									children: subtitle
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 items-center gap-1.5 pt-0.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setAuthOpen(true),
								"aria-label": "חשבון וסנכרון ענן",
								className: "press grid h-11 w-11 place-items-center rounded-2xl bg-secondary text-muted-foreground hover:text-primary transition-colors",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, {
									className: "h-5 w-5",
									strokeWidth: 2
								})
							}), action]
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "page-enter mx-auto w-full max-w-md px-4 pb-8 pt-4 sm:px-5",
				style: { paddingBottom: "calc(6.5rem + env(safe-area-inset-bottom))" },
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "ניווט ראשי",
				className: "pointer-events-none fixed inset-x-0 bottom-0 z-20 px-3.5 sm:px-4",
				style: { paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-auto mx-auto flex max-w-md items-center justify-between rounded-[2rem] border border-white/70 bg-white/85 p-1.5 shadow-[0_12px_36px_oklch(0.22_0.02_145/0.12),0_2px_10px_oklch(0.22_0.02_145/0.05)] backdrop-blur-2xl",
					children: NAV.map(({ to, label, id, icon: Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to,
						activeOptions: { exact: to === "/" },
						"data-testid": `link-nav-${id}`,
						className: "group relative flex min-h-[3.6rem] min-w-[3.4rem] flex-1 flex-col items-center justify-center gap-0.5 rounded-[1.4rem] py-1 text-muted-foreground transition-all duration-200 data-[status=active]:bg-primary/12 data-[status=active]:text-primary hover:text-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "h-[21px] w-[21px] transition-transform duration-200 group-data-[status=active]:scale-110",
								strokeWidth: 2.2
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10.5px] font-bold leading-none",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-0.5 h-1 w-1 rounded-full bg-primary opacity-0 transition-opacity duration-200 group-data-[status=active]:opacity-100" })
						]
					}, to))
				})
			})
		]
	});
}
//#endregion
export { saveWorkout as $, emptyItem as A, renameMeal as B, deleteProgram as C, duplicateWorkoutDay as D, duplicateProgram as E, lastPerformance as F, saveCustomExercise as G, repLabel as H, mealFoodFromLibrary as I, saveFood as J, saveCustomFood as K, nutritionDay as L, emptyWorkout as M, findFoodReplacements as N, emptyExercise as O, foodTotals as P, saveUserProfile as Q, personalRecords as R, deleteFood as S, deleteWorkout as T, saveBodyWeight as U, reorderProgramDays as V, saveCardioLog as W, saveProgram as X, saveNutritionTargets as Y, saveSession as Z, calculateRmr as _, EXERCISE_CATEGORIES as a, uid as at, deleteCustomExercise as b, MUSCLE_GROUPS as c, SecondaryButton as d, saveWorkoutInProgram as et, SectionHeader as f, calculateCardioCalories as g, addMeal as h, EQUIPMENT as i, toggleFavoriteFood as it, emptyWarmup as j, emptyFood as k, Pill as l, addFoodToMeal as m, CARDIO_TYPES as n, searchFoods as nt, EmptyState as o, updateMealFood as ot, StatTile as p, saveExercise as q, Card as r, todayKey as rt, IconButton as s, useGym as st, AppShell as t, searchExercises as tt, PrimaryButton as u, createProgram as v, deleteSession as w, deleteExercise as x, dayTotals as y, removeMealFood as z };
