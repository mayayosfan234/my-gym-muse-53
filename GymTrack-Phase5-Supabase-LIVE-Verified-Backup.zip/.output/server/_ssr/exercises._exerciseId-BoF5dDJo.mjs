import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exercises._exerciseId-BoF5dDJo.js
var $$splitComponentImporter = () => import("./exercises._exerciseId-CzQDtf9c.mjs");
var Route = createFileRoute("/exercises/$exerciseId")({
	head: () => ({ meta: [
		{ title: "פרטי תרגיל — הרוטינה שלי" },
		{
			name: "description",
			content: "פרטי תרגיל: קבוצת שרירים, ציוד, הוראות ביצוע והערות אישיות."
		},
		{
			property: "og:title",
			content: "פרטי תרגיל — הרוטינה שלי"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
