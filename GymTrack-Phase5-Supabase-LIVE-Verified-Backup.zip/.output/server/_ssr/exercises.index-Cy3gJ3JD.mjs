import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { B as ChevronLeft, F as Dumbbell, c as Sparkles, l as SlidersHorizontal, m as Search, o as Trash2, t as X, v as Plus } from "../_libs/lucide-react.mjs";
import { G as saveCustomExercise, a as EXERCISE_CATEGORIES, b as deleteCustomExercise, c as MUSCLE_GROUPS, f as SectionHeader, i as EQUIPMENT, l as Pill, o as EmptyState, st as useGym, t as AppShell, tt as searchExercises, u as PrimaryButton } from "./AppShell-B3CNDLiS.mjs";
import { t as ConfirmSheet } from "./ConfirmSheet-Bs6zdV30.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exercises.index-Cy3gJ3JD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fieldCls = "w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3 text-[14px] outline-none focus:border-primary";
var labelCls = "mb-1.5 block text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase";
function Library() {
	const { exercises } = useGym();
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	const [group, setGroup] = (0, import_react.useState)("הכל");
	const [equipment, setEquipment] = (0, import_react.useState)("הכל");
	const [filtersOpen, setFiltersOpen] = (0, import_react.useState)(false);
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const [deleteConfirmId, setDeleteConfirmId] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [englishName, setEnglishName] = (0, import_react.useState)("");
	const [muscleGroup, setMuscleGroup] = (0, import_react.useState)("חזה");
	const [customMuscleGroup, setCustomMuscleGroup] = (0, import_react.useState)("");
	const [selectedEquipment, setSelectedEquipment] = (0, import_react.useState)("מוט");
	const [category, setCategory] = (0, import_react.useState)("מורכב");
	const [description, setDescription] = (0, import_react.useState)("");
	const list = searchExercises(exercises, q).filter((e) => (group === "הכל" || e.muscleGroup === group || (e.muscleGroups ?? []).includes(group)) && (equipment === "הכל" || e.equipment === equipment));
	const activeFilters = (group !== "הכל" ? 1 : 0) + (equipment !== "הכל" ? 1 : 0);
	const handleCreateCustom = (e) => {
		e.preventDefault();
		if (!name.trim()) return;
		const created = saveCustomExercise({
			name: name.trim(),
			englishName: englishName.trim() || void 0,
			muscleGroup: muscleGroup === "אחר" && customMuscleGroup.trim() ? customMuscleGroup.trim() : muscleGroup,
			customMuscleGroup: muscleGroup === "אחר" ? customMuscleGroup.trim() : void 0,
			muscleGroups: [muscleGroup === "אחר" && customMuscleGroup.trim() ? customMuscleGroup.trim() : muscleGroup],
			equipment: selectedEquipment,
			category,
			description: description.trim(),
			videoUrl: "",
			images: [],
			notes: "",
			isCustom: true,
			searchTerms: [name.trim(), englishName.trim()].filter(Boolean)
		});
		setCreateOpen(false);
		setName("");
		setEnglishName("");
		setMuscleGroup("חזה");
		setCustomMuscleGroup("");
		setSelectedEquipment("מוט");
		setCategory("מורכב");
		setDescription("");
		navigate({
			to: "/exercises/$exerciseId",
			params: { exerciseId: created.id }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: "ספרייה",
		title: "תרגילים",
		subtitle: `${exercises.length} תרגילים בספרייה`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setCreateOpen(true),
			"aria-label": "הוסיפי תרגיל אישי",
			className: "press flex h-11 items-center gap-1.5 rounded-2xl bg-primary px-3.5 text-primary-foreground font-semibold text-[13px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
				className: "h-4 w-4",
				strokeWidth: 2.4
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "הוסיפי תרגיל" })]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "num-pill flex h-12 items-center gap-2 px-3.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 shrink-0 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "חפשי לפי שם תרגיל, ציוד או שריר...",
						className: "w-full min-w-0 bg-transparent text-[14px] outline-none placeholder:text-muted-foreground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setFiltersOpen((v) => !v),
						className: "press relative grid h-9 w-9 place-items-center rounded-xl text-muted-foreground hover:bg-secondary",
						"aria-label": "סינון",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-4 w-4" }), activeFilters > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -top-0.5 -end-0.5 grid h-4 w-4 place-items-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground",
							children: activeFilters
						}) : null]
					})
				]
			}),
			(group !== "הכל" || equipment !== "הכל") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-1.5",
				children: [group !== "הכל" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
					active: true,
					onClick: () => setGroup("הכל"),
					variant: "sage",
					children: [group, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[12px] leading-none",
						children: "×"
					})]
				}) : null, equipment !== "הכל" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
					active: true,
					onClick: () => setEquipment("הכל"),
					variant: "rose",
					children: [equipment, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[12px] leading-none",
						children: "×"
					})]
				}) : null]
			}),
			filtersOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card mt-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						title: "סינון לפי שריר",
						className: "mb-2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "-mx-1 flex gap-2 overflow-x-auto px-1 pb-2 no-scrollbar",
						children: ["הכל", ...MUSCLE_GROUPS].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setGroup(g),
							className: `press shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-semibold transition-colors ${group === g ? "bg-primary text-primary-foreground shadow-sm" : "bg-secondary text-muted-foreground"}`,
							children: g
						}, g))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						title: "סינון לפי ציוד",
						className: "mb-2 mt-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "-mx-1 flex gap-2 overflow-x-auto px-1 pb-2 no-scrollbar",
						children: ["הכל", ...EQUIPMENT].map((eq) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setEquipment(eq),
							className: `press shrink-0 rounded-full px-3 py-1.5 text-[11.5px] font-semibold transition-colors ${equipment === eq ? "bg-primary text-primary-foreground shadow-sm" : "bg-secondary text-muted-foreground"}`,
							children: eq
						}, eq))
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				className: "mt-5",
				title: `${list.length} תרגילים`,
				subtitle: "לחצי על תרגיל לצפייה ופרטים"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2.5",
				children: list.map((e) => {
					const primary = e.muscleGroup === "אחר" && e.customMuscleGroup ? e.customMuscleGroup : e.muscleGroup;
					const secondaryCount = (e.muscleGroups?.length ?? 1) - 1;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-card press flex items-center justify-between gap-3 p-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/exercises/$exerciseId",
							params: { exerciseId: e.id },
							className: "flex min-w-0 flex-1 items-center gap-3.5 text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `grid h-11 w-11 shrink-0 place-items-center rounded-2xl ${e.isCustom ? "bg-rose-soft text-rose" : "bg-sage-soft text-primary"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, {
									className: "h-5 w-5",
									strokeWidth: 1.8
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-display text-[15px] font-semibold text-ink",
										children: e.name
									}), e.isCustom ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-0.5 rounded-full bg-rose-soft px-2 py-0.5 text-[10px] font-bold text-rose",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-2.5 w-2.5" }), "אישי"]
									}) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-0.5 truncate text-[12px] text-muted-foreground",
									children: [
										primary,
										secondaryCount > 0 ? ` (+${secondaryCount})` : "",
										e.category ? ` · ${e.category}` : ""
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "num-pill px-2.5 py-1 text-[11px] font-medium text-muted-foreground",
									children: e.equipment
								}),
								e.isCustom ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: (ev) => {
										ev.preventDefault();
										ev.stopPropagation();
										setDeleteConfirmId(e.id);
									},
									"aria-label": "מחק תרגיל אישי",
									className: "press grid h-8 w-8 place-items-center rounded-xl text-muted-foreground hover:bg-destructive/10 hover:text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/exercises/$exerciseId",
									params: { exerciseId: e.id },
									className: "grid h-8 w-8 place-items-center text-muted-foreground/60",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
								})
							]
						})]
					}, e.id);
				})
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Dumbbell,
				title: "לא נמצאו תרגילים",
				description: q || activeFilters > 0 ? "נסי לשנות את החיפוש או הסינון." : "התחילי לבנות את ספריית התרגילים שלך.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setCreateOpen(true),
					className: "press inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-[13.5px] font-semibold text-primary-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "h-4 w-4",
						strokeWidth: 2.4
					}), "הוסיפי תרגיל חדש"]
				})
			}) : null,
			createOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-xs p-0 pb-20 sm:p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (el) => {
						if (el) el.scrollTop = 0;
					},
					className: "surface-card w-full max-w-md max-h-[85vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5 text-start shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-200",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-3 border-b border-border/40 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5 text-rose" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-[17px] font-bold text-ink",
								children: "הוסיפי תרגיל מותאם אישית"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCreateOpen(false),
							className: "press grid h-8 w-8 place-items-center rounded-full bg-secondary text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleCreateCustom,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "שם התרגיל (בעברית) *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: "למשל: סקוואט כנגד גומייה",
								className: fieldCls
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "שם באנגלית (אופציונלי)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: englishName,
								onChange: (e) => setEnglishName(e.target.value),
								placeholder: "e.g. Banded Squat",
								className: fieldCls
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: labelCls,
									children: "קבוצת שרירים ראשית *"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: muscleGroup,
									onChange: (e) => setMuscleGroup(e.target.value),
									className: fieldCls,
									children: MUSCLE_GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: g,
										children: g
									}, g))
								}),
								muscleGroup === "אחר" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: customMuscleGroup,
									onChange: (e) => setCustomMuscleGroup(e.target.value),
									placeholder: "הקלידי שם שריר...",
									className: `${fieldCls} mt-2`
								}) : null
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "ציוד עיקרי *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: selectedEquipment,
								onChange: (e) => setSelectedEquipment(e.target.value),
								className: fieldCls,
								children: EQUIPMENT.map((eq) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: eq,
									children: eq
								}, eq))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "קטגוריה"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: category,
								onChange: (e) => setCategory(e.target.value),
								className: fieldCls,
								children: EXERCISE_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c,
									children: c
								}, c))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "תיאור קצר (אופציונלי)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 2,
								value: description,
								onChange: (e) => setDescription(e.target.value),
								placeholder: "דגשים עיקריים או הוראות ביצוע...",
								className: fieldCls
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-2 flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
									type: "submit",
									className: "flex-1",
									children: "שמרי תרגיל חדש"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setCreateOpen(false),
									className: "press rounded-2xl bg-secondary px-4 py-3 text-[14px] font-semibold text-muted-foreground",
									children: "ביטול"
								})]
							})
						]
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				open: Boolean(deleteConfirmId),
				title: "מחיקת תרגיל אישי",
				description: "האם את בטוחה שברצונך למחוק תרגיל מותאם אישית זה? הפעולה לא תמחוק היסטוריית אימונים קודמת.",
				confirmText: "מחק תרגיל",
				danger: true,
				onConfirm: () => {
					if (deleteConfirmId) {
						deleteCustomExercise(deleteConfirmId);
						setDeleteConfirmId(null);
					}
				},
				onCancel: () => setDeleteConfirmId(null)
			})
		]
	});
}
//#endregion
export { Library as component };
