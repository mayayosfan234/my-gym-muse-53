import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { s as IconButton } from "./AppShell-B3CNDLiS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ConfirmSheet-Bs6zdV30.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Mobile-native confirmation sheet (replacement for `window.confirm`).
* Renders a bottom-anchored card with a clear title, optional description,
* and a destructive / neutral action pair. Honors iOS safe-area and 44px
* touch targets.
*/
function ConfirmSheet({ open, title, description, confirmLabel = "אישור", cancelLabel = "ביטול", destructive = false, onConfirm, onCancel }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = prev;
		};
	}, [open]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onCancel();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onCancel]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "dialog",
		"aria-modal": "true",
		className: "fade-in fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm",
		onClick: onCancel,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: (el) => {
				if (el) el.scrollTop = 0;
			},
			className: "scale-in w-full max-w-xl overflow-y-auto rounded-t-[2rem] border-t border-border/40 bg-card p-5 text-start shadow-2xl",
			onClick: (e) => e.stopPropagation(),
			style: { paddingBottom: "calc(1.25rem + env(safe-area-inset-bottom))" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-start gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-rose-soft text-rose",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: 1.8,
								strokeLinecap: "round",
								strokeLinejoin: "round",
								className: "h-5 w-5",
								"aria-hidden": "true",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 9v4" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 17h.01" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z" })
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 pt-0.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-[19px] font-semibold leading-tight text-ink",
								children: title
							}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[13.5px] leading-relaxed text-muted-foreground",
								children: description
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							"aria-label": "סגור",
							onClick: onCancel,
							variant: "ghost",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onCancel,
						className: "press inline-flex h-12 w-full items-center justify-center rounded-2xl bg-secondary px-5 text-[14.5px] font-semibold text-secondary-foreground sm:w-auto sm:px-7",
						children: cancelLabel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onConfirm,
						className: `press inline-flex h-12 w-full items-center justify-center rounded-2xl px-5 text-[14.5px] font-semibold text-white shadow-sm sm:w-auto sm:px-7 ${destructive ? "bg-destructive" : "bg-primary text-primary-foreground"}`,
						children: confirmLabel
					})]
				})
			]
		})
	});
}
//#endregion
export { ConfirmSheet as t };
