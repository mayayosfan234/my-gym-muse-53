import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { G as ArrowRight, M as GripVertical, o as Trash2, t as X, v as Plus } from "../_libs/lucide-react.mjs";
import { $ as saveWorkout, A as emptyItem, M as emptyWorkout, T as deleteWorkout, st as useGym, t as AppShell } from "./AppShell-B3CNDLiS.mjs";
import { t as Stepper } from "./Stepper-gj3wsFLX.mjs";
import { t as Route } from "./workouts._workoutId-CqPUmJ1c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workouts._workoutId-DInPyXnU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var field = "w-full rounded-xl border border-border bg-secondary px-4 py-3 text-base outline-none focus:border-primary";
function Builder() {
	const { workoutId } = Route.useParams();
	const navigate = useNavigate();
	const { workouts, exercises } = useGym();
	const isNew = workoutId === "new";
	const existing = workouts.find((w) => w.id === workoutId);
	const [draft, setDraft] = (0, import_react.useState)(existing ?? emptyWorkout());
	const [picker, setPicker] = (0, import_react.useState)(false);
	if (!isNew && !existing) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "אימון לא נמצא",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "אימון זה אינו קיים עוד."
		})
	});
	const nameOf = (id) => exercises.find((e) => e.id === id)?.name ?? "תרגיל שהוסר";
	const patchItem = (id, patch) => setDraft({
		...draft,
		items: draft.items.map((i) => i.id === id ? {
			...i,
			...patch
		} : i)
	});
	const move = (index, dir) => {
		const items = [...draft.items];
		const target = index + dir;
		if (target < 0 || target >= items.length) return;
		const a = items[index];
		items[index] = items[target];
		items[target] = a;
		setDraft({
			...draft,
			items
		});
	};
	const onSave = () => {
		saveWorkout({
			...draft,
			name: draft.name.trim() || "אימון ללא שם"
		});
		navigate({ to: "/programs" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: isNew ? "אימון חדש" : "עריכת אימון",
		subtitle: `${draft.items.length} תרגילים`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/programs",
			"aria-label": "חזרה",
			className: "grid h-11 w-11 place-items-center rounded-xl bg-secondary active:scale-95",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-5 w-5" })
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: field,
				value: draft.name,
				onChange: (e) => setDraft({
					...draft,
					name: e.target.value
				}),
				placeholder: "שם האימון"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				rows: 2,
				className: `${field} mt-3`,
				value: draft.notes,
				onChange: (e) => setDraft({
					...draft,
					notes: e.target.value
				}),
				placeholder: "הערות ודגשים לאימון..."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-3.5 text-start",
				children: draft.items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[auto_1fr_auto] items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "שנה סדר",
									onClick: () => move(index, -1),
									className: "grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-secondary text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold text-foreground",
									children: nameOf(item.exerciseId)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "הסר תרגיל",
									onClick: () => setDraft({
										...draft,
										items: draft.items.filter((i) => i.id !== item.id)
									}),
									className: "grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-secondary text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
									label: "סטים",
									value: item.sets,
									min: 1,
									onChange: (v) => patchItem(item.id, { sets: v })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
									label: "חזרות",
									value: item.reps,
									min: 1,
									onChange: (v) => patchItem(item.id, { reps: v })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
									label: "משקל",
									value: item.weight,
									step: 2.5,
									suffix: "ק״ג",
									onChange: (v) => patchItem(item.id, { weight: v })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
									label: "מנוחה",
									value: item.rest,
									step: 15,
									suffix: "ש׳",
									onChange: (v) => patchItem(item.id, { rest: v })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${field} mt-3`,
							value: item.notes,
							onChange: (e) => patchItem(item.id, { notes: e.target.value }),
							placeholder: "הערה לתרגיל זה..."
						})
					]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setPicker(true),
				className: "mt-4 flex h-14 w-full items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-secondary font-semibold active:scale-[0.98]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-5 w-5" }), " הוסף תרגיל"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onSave,
				className: "mt-3 h-14 w-full rounded-xl bg-primary text-base font-semibold text-primary-foreground active:scale-[0.98]",
				children: "שמור אימון"
			}),
			!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					deleteWorkout(draft.id);
					navigate({ to: "/programs" });
				},
				className: "mt-3 flex h-14 w-full items-center justify-center gap-2 rounded-xl bg-secondary font-semibold text-destructive active:scale-[0.98]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-5 w-5" }), " מחק אימון"]
			}),
			picker && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex flex-col justify-end bg-background/70 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[75vh] overflow-y-auto rounded-t-3xl border-t border-border bg-card p-5 text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "בחר תרגיל"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "סגור",
							onClick: () => setPicker(false),
							className: "grid h-10 w-10 place-items-center rounded-xl bg-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 pb-6",
						children: [exercises.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setDraft({
									...draft,
									items: [...draft.items, emptyItem(e.id)]
								});
								setPicker(false);
							},
							className: "w-full rounded-xl bg-secondary p-4 text-start active:scale-[0.99]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground",
								children: e.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									e.muscleGroup,
									" · ",
									e.equipment
								]
							})]
						}, e.id)), exercises.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "הוסף תרגילים לספרייה קודם לכן."
						})]
					})]
				})
			})
		]
	});
}
//#endregion
export { Builder as component };
