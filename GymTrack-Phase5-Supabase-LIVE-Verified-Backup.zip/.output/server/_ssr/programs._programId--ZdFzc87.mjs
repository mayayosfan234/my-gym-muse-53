import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/programs._programId--ZdFzc87.js
var $$splitComponentImporter = () => import("./programs._programId-D4iAMcj1.mjs");
var Route = createFileRoute("/programs/$programId")({
	head: () => ({ meta: [{ title: "תכנית אימונים — הרוטינה שלי" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
