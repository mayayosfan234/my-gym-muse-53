import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as closestCenter, d as useSensors, f as CSS, i as TouchSensor, r as PointerSensor, t as DndContext, u as useSensor } from "../_libs/@dnd-kit/core+[...].mjs";
import { G as ArrowRight, M as GripVertical, b as Pencil, g as Save, o as Trash2, t as X, v as Plus, y as Play } from "../_libs/lucide-react.mjs";
import { D as duplicateWorkoutDay, T as deleteWorkout, V as reorderProgramDays, X as saveProgram, f as SectionHeader, o as EmptyState, s as IconButton, st as useGym, t as AppShell, u as PrimaryButton } from "./AppShell-B3CNDLiS.mjs";
import { t as ConfirmSheet } from "./ConfirmSheet-Bs6zdV30.mjs";
import { t as Route } from "./programs._programId--ZdFzc87.mjs";
import { i as verticalListSortingStrategy, n as arrayMove, r as useSortable, t as SortableContext } from "../_libs/dnd-kit__sortable.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/programs._programId-D4iAMcj1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProgramDetail() {
	const { programId } = Route.useParams();
	const navigate = useNavigate();
	const { programs, workouts } = useGym();
	const program = programs.find((item) => item.id === programId);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const sensors = useSensors(useSensor(TouchSensor, { activationConstraint: {
		delay: 120,
		tolerance: 8
	} }), useSensor(PointerSensor));
	if (!program) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "תכנית לא נמצאה",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/programs",
			"aria-label": "חזרה לתוכניות",
			className: "press grid h-11 w-11 place-items-center rounded-2xl bg-secondary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-5 w-5" })
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "תכנית זו אינה קיימת עוד."
		})
	});
	const days = program.dayIds.map((id) => workouts.find((workout) => workout.id === id)).filter((day) => Boolean(day));
	const current = draft ?? program;
	const onDragEnd = ({ active, over }) => {
		if (!over || active.id === over.id) return;
		const oldIndex = program.dayIds.indexOf(String(active.id));
		const newIndex = program.dayIds.indexOf(String(over.id));
		if (oldIndex !== -1 && newIndex !== -1) reorderProgramDays(program.id, arrayMove(program.dayIds, oldIndex, newIndex));
	};
	const save = () => {
		if (!current.name.trim()) return;
		saveProgram({
			...current,
			name: current.name.trim()
		});
		setEditing(false);
		setDraft(null);
	};
	const totalExercises = days.reduce((sum, d) => sum + d.items.length, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: "תכנית",
		title: program.name,
		subtitle: `${days.length} ימי אימון · ${totalExercises} תרגילים`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
			onClick: () => setEditing((value) => !value),
			"aria-label": "ערוך תכנית",
			variant: editing ? "primary" : "default",
			children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
				className: "h-4 w-4",
				strokeWidth: 2
			})
		}),
		children: [
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
						children: "שם התכנית"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: current.name,
						onChange: (event) => setDraft({
							...current,
							name: event.target.value
						}),
						className: "mt-2 w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3.5 text-base outline-none focus:border-primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
						children: "הערות"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: current.notes,
						onChange: (event) => setDraft({
							...current,
							notes: event.target.value
						}),
						rows: 3,
						className: "mt-2 w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3.5 text-base outline-none focus:border-primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: save,
							leading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4" }),
							children: "שמור שינויים"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setEditing(false);
								setDraft(null);
							},
							className: "press h-12 rounded-2xl bg-secondary px-5 text-[14.5px] font-semibold text-secondary-foreground",
							children: "ביטול"
						})]
					})
				]
			}) : program.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ink-card-soft p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-start text-[13px] leading-relaxed text-ink-soft",
					children: program.notes
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "ימי אימון",
					subtitle: "גרורי כדי לסדר מחדש. לחצי על אימון כדי לפתוח או לערוך.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => navigate({
							to: "/programs/$programId/$dayId",
							params: {
								programId: program.id,
								dayId: "new"
							}
						}),
						className: "press inline-flex h-9 items-center gap-1.5 rounded-full bg-primary px-3.5 text-[12.5px] font-semibold text-primary-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "h-3.5 w-3.5",
							strokeWidth: 2.4
						}), "הוסיפי יום"]
					})
				}), days.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DndContext, {
					sensors,
					collisionDetection: closestCenter,
					onDragEnd,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableContext, {
						items: program.dayIds,
						strategy: verticalListSortingStrategy,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: days.map((day, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableDayCard, {
								day,
								index,
								programId: program.id,
								onRequestDelete: (id, name) => setPendingDelete({
									id,
									name
								})
							}, day.id))
						})
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "עדיין אין ימי אימון",
					description: "הוסיפי את יום האימון הראשון שלך לתכנית ובני בתוכו תרגילים.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => navigate({
							to: "/programs/$programId/$dayId",
							params: {
								programId: program.id,
								dayId: "new"
							}
						}),
						className: "press inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-[13.5px] font-semibold text-primary-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "h-4 w-4",
							strokeWidth: 2.4
						}), "הוסיפי יום אימון"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				open: pendingDelete !== null,
				title: "למחוק את יום האימון?",
				description: pendingDelete ? `הפעולה תמחק את "${pendingDelete.name}" ואת כל התרגילים שבו. לא ניתן לשחזר.` : void 0,
				confirmLabel: "מחק יום",
				cancelLabel: "חזרה",
				destructive: true,
				onConfirm: () => {
					if (pendingDelete) deleteWorkout(pendingDelete.id);
					setPendingDelete(null);
				},
				onCancel: () => setPendingDelete(null)
			})
		]
	});
}
function SortableDayCard({ day, index, programId, onRequestDelete }) {
	const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: day.id });
	const style = {
		transform: CSS.Transform.toString(transform),
		transition,
		opacity: isDragging ? .6 : 1
	};
	const navigate = useNavigate();
	const goStart = () => navigate({
		to: "/session/$workoutId",
		params: { workoutId: day.id }
	});
	const onDuplicate = () => duplicateWorkoutDay(day.id, programId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		ref: setNodeRef,
		style,
		className: "surface-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "גרור לסידור מחדש",
					className: "press grid h-10 w-7 shrink-0 cursor-grab place-items-center rounded-lg text-muted-foreground/60 active:cursor-grabbing",
					...attributes,
					...listeners,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "h-4 w-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-sage-soft font-display text-[15px] font-semibold text-primary",
					children: String(index + 1).padStart(2, "0")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/programs/$programId/$dayId",
					params: {
						programId,
						dayId: day.id
					},
					className: "min-w-0 flex-1 text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-display text-[16px] font-semibold text-ink",
						children: day.name || "יום ללא שם"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-[12.5px] text-muted-foreground",
						children: [day.items.length, " תרגילים"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: goStart,
					"aria-label": `התחל את ${day.name}`,
					className: "press grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 fill-current" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap items-center justify-between gap-1.5 border-t border-border/50 pt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/programs/$programId/$dayId",
					params: {
						programId,
						dayId: day.id
					},
					className: "press rounded-full px-3 py-1.5 text-[12px] font-semibold text-muted-foreground hover:bg-secondary",
					children: "עריכה"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onDuplicate,
					"aria-label": `שכפל ${day.name}`,
					className: "press rounded-full px-3 py-1.5 text-[12px] font-semibold text-muted-foreground hover:bg-secondary",
					children: "שכפול"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onRequestDelete(day.id, day.name),
				"aria-label": `מחק ${day.name}`,
				className: "press grid h-11 w-11 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-secondary hover:text-destructive",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
			})]
		})]
	});
}
//#endregion
export { ProgramDetail as component };
