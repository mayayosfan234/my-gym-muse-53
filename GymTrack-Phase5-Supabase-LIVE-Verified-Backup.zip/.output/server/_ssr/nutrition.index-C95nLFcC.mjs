import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { B as ChevronLeft, K as ArrowLeft, W as BookOpen, d as Shuffle, n as Utensils, o as Trash2, p as Settings2, q as Apple, t as X, v as Plus, z as ChevronRight } from "../_libs/lucide-react.mjs";
import { B as renameMeal, I as mealFoodFromLibrary, L as nutritionDay, N as findFoodReplacements, P as foodTotals, Y as saveNutritionTargets, d as SecondaryButton, f as SectionHeader, h as addMeal, m as addFoodToMeal, ot as updateMealFood, p as StatTile, r as Card, rt as todayKey, s as IconButton, st as useGym, t as AppShell, u as PrimaryButton, y as dayTotals, z as removeMealFood } from "./AppShell-B3CNDLiS.mjs";
import { t as Stepper } from "./Stepper-gj3wsFLX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nutrition.index-C95nLFcC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function shiftDate(key, delta) {
	const [y, m, d] = key.split("-").map(Number);
	const date = new Date(y, m - 1, d);
	date.setDate(date.getDate() + delta);
	return todayKey(date);
}
function formatDayLabel(key) {
	const today = todayKey();
	if (key === today) return "היום";
	if (key === shiftDate(today, -1)) return "אתמול";
	if (key === shiftDate(today, -2)) return "לפני יומיים";
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, m - 1, d).toLocaleDateString("he-IL", {
		weekday: "short",
		month: "short",
		day: "numeric"
	});
}
function NutritionLog() {
	const gym = useGym();
	const [date, setDate] = (0, import_react.useState)(todayKey());
	const [pickerMealId, setPickerMealId] = (0, import_react.useState)(null);
	const [pickerQuery, setPickerQuery] = (0, import_react.useState)("");
	const [substituteFor, setSubstituteFor] = (0, import_react.useState)(null);
	const [substituteQuery, setSubstituteQuery] = (0, import_react.useState)("");
	const [showTargets, setShowTargets] = (0, import_react.useState)(false);
	const [targetsDraft, setTargetsDraft] = (0, import_react.useState)(gym.nutritionTargets);
	const day = nutritionDay(gym, date);
	const totals = dayTotals(day);
	const { nutritionTargets: targets } = gym;
	const filteredFoods = (0, import_react.useMemo)(() => {
		const q = pickerQuery.trim().toLocaleLowerCase();
		return gym.foods.filter((f) => !q || f.name.toLocaleLowerCase().includes(q) || (f.category ?? "").toLocaleLowerCase().includes(q));
	}, [gym.foods, pickerQuery]);
	const replacements = (0, import_react.useMemo)(() => {
		if (!substituteFor) return [];
		return findFoodReplacements(gym.foods, substituteFor.food, substituteQuery).slice(0, 15);
	}, [
		gym.foods,
		substituteFor,
		substituteQuery
	]);
	const addFromLibrary = (mealId, foodId) => {
		const lib = gym.foods.find((f) => f.id === foodId);
		if (!lib) return;
		addFoodToMeal(date, mealId, mealFoodFromLibrary(lib));
		setPickerMealId(null);
		setPickerQuery("");
	};
	const applyCalorieReplacement = (mealId, current, replacement) => {
		const lib = replacement.food;
		updateMealFood(date, mealId, {
			id: current.id,
			foodId: lib.id,
			name: lib.name,
			servingSize: lib.servingSize,
			quantity: replacement.calculatedQuantity,
			calories: lib.calories,
			protein: lib.protein,
			carbs: lib.carbs,
			fat: lib.fat,
			fiber: lib.fiber,
			notes: current.notes
		});
		setSubstituteFor(null);
		setSubstituteQuery("");
	};
	const calPct = targets.calories && targets.calories > 0 ? Math.min(100, totals.calories / targets.calories * 100) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: "תזונה",
		title: "יומן תזונה",
		subtitle: formatDayLabel(date),
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/nutrition/foods",
				"aria-label": "ספריית מאכלים",
				className: "press grid h-11 w-11 place-items-center rounded-2xl bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-5 w-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
				"aria-label": "הגדר יעדים",
				onClick: () => {
					setTargetsDraft(gym.nutritionTargets);
					setShowTargets(true);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "h-5 w-5" })
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card flex items-center justify-between gap-2 p-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "יום קודם",
						onClick: () => setDate((d) => shiftDate(d, -1)),
						className: "press grid h-10 w-10 place-items-center rounded-2xl bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-[16px] font-semibold text-ink",
							children: formatDayLabel(date)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground tabular-nums",
							children: date
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "יום הבא",
						onClick: () => setDate((d) => shiftDate(d, 1)),
						className: "press grid h-10 w-10 place-items-center rounded-2xl bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rose-card mt-4 overflow-hidden p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-start",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10.5px] font-semibold tracking-[0.16em] text-rose uppercase",
									children: "קלוריות היום"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-[40px] font-semibold leading-none text-ink tabular-nums",
									children: Math.round(totals.calories)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[12.5px] text-muted-foreground",
									children: targets.calories ? `מתוך ${targets.calories} קלוריות` : "ללא יעד יומי"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalRing, { pct: calPct ?? 0 })]
					}),
					calPct != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-1.5 overflow-hidden rounded-full bg-white/60",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary transition-all duration-500",
							style: { width: `${calPct}%` }
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MacroPill, {
								label: "חלבון",
								value: totals.protein,
								target: targets.protein,
								unit: "g"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MacroPill, {
								label: "פחמימות",
								value: totals.carbs,
								target: targets.carbs,
								unit: "g"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MacroPill, {
								label: "שומן",
								value: totals.fat,
								target: targets.fat,
								unit: "g"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "הארוחות שלך",
					subtitle: `${day.meals.length} ארוחות תועדו`,
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => addMeal(date),
						className: "press inline-flex h-9 items-center gap-1.5 rounded-full bg-primary px-3.5 text-[12.5px] font-semibold text-primary-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "h-3.5 w-3.5",
							strokeWidth: 2.4
						}), "הוסיפי ארוחה"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [day.meals.map((meal) => {
						const mealTotals = foodTotals(meal.foods);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "surface-card p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-cream text-ink-soft",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Utensils, {
											className: "h-4 w-4",
											strokeWidth: 1.8
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1 text-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: "w-full bg-transparent font-display text-[16px] font-semibold text-ink outline-none placeholder:text-muted-foreground",
											value: meal.name,
											onChange: (e) => renameMeal(date, meal.id, e.target.value)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-0.5 text-[12px] text-muted-foreground tabular-nums",
											children: [
												Math.round(mealTotals.calories),
												" קלוריות · חלבון",
												" ",
												Math.round(mealTotals.protein),
												"g"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setPickerMealId(meal.id),
										className: "press grid h-9 w-9 place-items-center rounded-2xl bg-primary text-primary-foreground",
										"aria-label": "הוסף מאכל",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
											className: "h-4 w-4",
											strokeWidth: 2.4
										})
									})
								]
							}), meal.foods.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 space-y-2.5",
								children: meal.foods.map((food) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-2xl border border-border/40 bg-secondary/60 p-3 text-start",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-2.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0 flex-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "truncate text-[14px] font-semibold text-ink",
													children: food.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-0.5 text-[11.5px] text-muted-foreground",
													children: [
														food.servingSize,
														" · ",
														Math.round(food.calories * food.quantity),
														" ",
														"קלוריות"
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": "החלף מאכל",
												onClick: () => setSubstituteFor({
													mealId: meal.id,
													food
												}),
												className: "press grid h-8 w-8 place-items-center rounded-xl text-primary hover:bg-white",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "h-3.5 w-3.5" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": "הסר מאכל",
												onClick: () => removeMealFood(date, meal.id, food.id),
												className: "press grid h-8 w-8 place-items-center rounded-xl text-muted-foreground hover:bg-white hover:text-destructive",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" })
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2.5 grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
											label: "כמות",
											value: food.quantity,
											step: .5,
											onChange: (v) => updateMealFood(date, meal.id, {
												id: food.id,
												quantity: v
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-2xl bg-white/60 px-3 py-2.5 text-start",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10.5px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
												children: "סה״כ"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-0.5 font-display text-[15px] font-semibold tabular-nums text-ink",
												children: [Math.round(food.calories * food.quantity), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "ms-0.5 text-[11px] font-normal text-muted-foreground",
													children: "קל"
												})]
											})]
										})]
									})]
								}, food.id))
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-[12.5px] text-muted-foreground text-start",
								children: "אין מאכלים בארוחה זו עדיין."
							})]
						}, meal.id);
					}), day.meals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "text-start",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[13.5px] text-muted-foreground",
							children: "עדיין לא נוספו ארוחות ליום זה. לחצי על \"הוסיפי ארוחה\" כדי להתחיל."
						})
					}) : null]
				})]
			}),
			pickerMealId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-40 flex flex-col justify-end bg-foreground/30 backdrop-blur-sm",
				onClick: () => setPickerMealId(null),
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (el) => {
						if (el) el.scrollTop = 0;
					},
					className: "scale-in max-h-[88dvh] overflow-y-auto rounded-t-[2rem] border-t border-border/40 bg-card p-5 text-start shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold tracking-[0.14em] text-primary uppercase",
								children: "הוסיפי מאכל"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-[20px] font-semibold text-ink",
								children: "ספריית מאכלים"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								"aria-label": "סגור",
								onClick: () => setPickerMealId(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "num-pill mb-3 flex h-12 items-center gap-2 px-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Apple, { className: "h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: pickerQuery,
								onChange: (e) => setPickerQuery(e.target.value),
								placeholder: "חפשי מוצר בסופרמרקט הישראלי...",
								className: "w-full bg-transparent text-[14px] outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [filteredFoods.slice(0, 30).map((food) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => addFromLibrary(pickerMealId, food.id),
								className: "press flex w-full items-center justify-between gap-3 rounded-2xl border border-border/30 bg-secondary px-3.5 py-3 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-[14px] font-semibold text-ink",
										children: food.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11.5px] text-muted-foreground",
										children: [
											food.servingSize,
											" · ",
											food.calories,
											" קלוריות · חלבון ",
											food.protein,
											"g · פחמימות",
											" ",
											food.carbs,
											"g"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4 shrink-0 text-muted-foreground/60" })]
							}, food.id)), filteredFoods.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "py-6 text-center text-[13px] text-muted-foreground",
								children: "לא נמצאו מוצרים תואמים."
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/nutrition/foods/$foodId",
							params: { foodId: "new" },
							className: "press mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-primary text-[14.5px] font-semibold text-primary-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "צרי מאכל חדש בספרייה"]
						})
					]
				})
			}) : null,
			substituteFor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-40 flex flex-col justify-end bg-foreground/30 backdrop-blur-sm",
				onClick: () => setSubstituteFor(null),
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "scale-in max-h-[88dvh] overflow-y-auto rounded-t-[2rem] border-t border-border/40 bg-card p-5 text-start shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold tracking-[0.14em] text-primary uppercase",
									children: "החלפה לפי קלוריות"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 font-display text-[20px] font-semibold text-ink",
									children: substituteFor.food.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-[12.5px] text-muted-foreground",
									children: "בחרי תחליף בעל ערך קלורי דומה"
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								"aria-label": "סגור",
								onClick: () => setSubstituteFor(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num-pill mb-3 flex h-12 items-center gap-2 px-3.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: substituteQuery,
								onChange: (e) => setSubstituteQuery(e.target.value),
								placeholder: "סינון מועמדים להחלפה...",
								className: "w-full bg-transparent text-[14px] outline-none"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: replacements.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => applyCalorieReplacement(substituteFor.mealId, substituteFor.food, item),
								className: "press flex w-full items-center justify-between gap-3 rounded-2xl border border-border/30 bg-secondary px-3.5 py-3 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-[14px] font-semibold text-ink",
										children: item.food.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11.5px] text-muted-foreground",
										children: [
											item.food.calories,
											" קלוריות · חלבון ",
											item.food.protein,
											"g · Δ",
											Math.abs(item.food.calories - substituteFor.food.calories),
											" קלוריות"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "num-pill shrink-0 px-2.5 py-1 text-[11px] font-medium text-ink-soft",
									children: [Math.round(item.calculatedQuantity * 10) / 10, "×"]
								})]
							}, item.food.id))
						})
					]
				})
			}) : null,
			showTargets ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-40 flex items-end justify-center bg-foreground/40 backdrop-blur-sm",
				onClick: () => setShowTargets(false),
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (el) => {
						if (el) el.scrollTop = 0;
					},
					className: "scale-in max-h-[88dvh] w-full max-w-xl overflow-y-auto rounded-t-[2rem] border-t border-border/40 bg-card p-5 text-start shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold tracking-[0.14em] text-primary uppercase",
							children: "יעדים יומיים"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-display text-[20px] font-semibold text-ink",
							children: "הגדירי יעדים תזונתיים"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetField, {
									label: "קלוריות",
									value: targetsDraft.calories,
									onChange: (v) => setTargetsDraft({
										...targetsDraft,
										calories: v
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetField, {
									label: "חלבון (g)",
									value: targetsDraft.protein,
									onChange: (v) => setTargetsDraft({
										...targetsDraft,
										protein: v
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetField, {
									label: "פחמימות (g)",
									value: targetsDraft.carbs,
									onChange: (v) => setTargetsDraft({
										...targetsDraft,
										carbs: v
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetField, {
									label: "שומן (g)",
									value: targetsDraft.fat,
									onChange: (v) => setTargetsDraft({
										...targetsDraft,
										fat: v
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								onClick: () => {
									saveNutritionTargets(targetsDraft);
									setShowTargets(false);
								},
								children: "שמור יעדים"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
								onClick: () => setShowTargets(false),
								children: "ביטול"
							})]
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
					label: "",
					value: ""
				})
			})
		]
	});
}
function MacroPill({ label, value, target, unit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-white/60 px-3 py-2.5 text-start",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10.5px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-0.5 font-display text-[15px] font-semibold tabular-nums text-ink",
				children: [Math.round(value), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ms-0.5 text-[10.5px] font-normal text-muted-foreground",
					children: unit
				})]
			}),
			target ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[10.5px] text-muted-foreground",
				children: [
					"יעד ",
					target,
					unit
				]
			}) : null
		]
	});
}
function CalRing({ pct }) {
	const dash = 132;
	const visualPct = Math.min(100, Math.max(0, pct || 0));
	const isSurplus = pct > 100;
	const offset = dash - dash * visualPct / 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative grid h-24 w-24 place-items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "96",
			height: "96",
			viewBox: "0 0 96 96",
			className: "-rotate-90",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "48",
				cy: "48",
				r: "42",
				fill: "none",
				stroke: "oklch(0.94 0.03 350)",
				strokeWidth: "8"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "48",
				cy: "48",
				r: "42",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "8",
				strokeLinecap: "round",
				strokeDasharray: dash,
				strokeDashoffset: offset,
				className: `transition-all duration-500 ${isSurplus ? "text-rose" : "text-primary"}`
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-display text-[14px] font-bold tabular-nums text-ink",
				children: [Math.round(pct), "%"]
			}), isSurplus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[9.5px] font-bold text-rose uppercase",
				children: "חריגה"
			}) : null]
		})]
	});
}
function TargetField({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			inputMode: "numeric",
			value: value ?? "",
			onChange: (e) => {
				const raw = e.target.value.replace(/\D/g, "");
				onChange(raw === "" ? void 0 : Number(raw));
			},
			placeholder: "—",
			className: "mt-1.5 w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3 text-[15px] outline-none focus:border-primary"
		})]
	});
}
//#endregion
export { NutritionLog as component };
