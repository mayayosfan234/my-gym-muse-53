import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { G as ArrowRight, c as Sparkles, j as Heart, m as Search, q as Apple, t as X, v as Plus } from "../_libs/lucide-react.mjs";
import { K as saveCustomFood, f as SectionHeader, it as toggleFavoriteFood, l as Pill, nt as searchFoods, o as EmptyState, st as useGym, t as AppShell, u as PrimaryButton } from "./AppShell-DdWWxz8T.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nutrition.foods.index-C2SA1OGn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FOOD_CATEGORIES = [
	"הכל",
	"מועדפים",
	"חלב ומוצרי חלב",
	"ביצים",
	"בשר",
	"עוף",
	"דגים",
	"פחמימות",
	"לחמים",
	"ירקות",
	"פירות",
	"קטניות",
	"אגוזים וזרעים",
	"חטיפים",
	"ממרחים",
	"משקאות",
	"מוצרים עשירים בחלבון"
];
var fieldCls = "w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3 text-[14px] outline-none focus:border-primary";
var labelCls = "mb-1.5 block text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase";
function FoodLibrary() {
	const { foods, favoriteFoods } = useGym();
	const navigate = useNavigate();
	const [query, setQuery] = (0, import_react.useState)("");
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("הכל");
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [englishName, setEnglishName] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("פחמימות");
	const [servingSize, setServingSize] = (0, import_react.useState)("100 גרם");
	const [calories, setCalories] = (0, import_react.useState)(100);
	const [protein, setProtein] = (0, import_react.useState)(0);
	const [carbs, setCarbs] = (0, import_react.useState)(0);
	const [fat, setFat] = (0, import_react.useState)(0);
	const [fiber, setFiber] = (0, import_react.useState)(0);
	const favSet = (0, import_react.useMemo)(() => new Set(favoriteFoods ?? []), [favoriteFoods]);
	const searched = searchFoods(foods, query);
	const filtered = (0, import_react.useMemo)(() => {
		return searched.filter((f) => {
			if (selectedCategory === "הכל") return true;
			if (selectedCategory === "מועדפים") return favSet.has(f.id) || Boolean(f.favorite);
			return (f.category ?? "").includes(selectedCategory);
		}).sort((a, b) => a.name.localeCompare(b.name, "he"));
	}, [
		searched,
		selectedCategory,
		favSet
	]);
	const handleCreateCustom = (e) => {
		e.preventDefault();
		if (!name.trim()) return;
		const newFood = saveCustomFood({
			name: name.trim(),
			englishName: englishName.trim() || void 0,
			category,
			servingSize: servingSize.trim() || "100 גרם",
			calories: Number(calories) || 0,
			protein: Number(protein) || 0,
			carbs: Number(carbs) || 0,
			fat: Number(fat) || 0,
			fiber: Number(fiber) || 0,
			searchTerms: [name.trim(), englishName.trim()].filter(Boolean)
		});
		setCreateOpen(false);
		setName("");
		setEnglishName("");
		setCalories(100);
		setProtein(0);
		setCarbs(0);
		setFat(0);
		setFiber(0);
		navigate({
			to: "/nutrition/foods/$foodId",
			params: { foodId: newFood.id }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: "תזונה",
		title: "ספריית מאכלים",
		subtitle: `${foods.length} מוצרים זמינים בספרייה`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/nutrition",
				"aria-label": "חזרה ליומן",
				className: "press grid h-11 w-11 place-items-center rounded-2xl bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-5 w-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setCreateOpen(true),
				"aria-label": "הוסיפי מזון אישי",
				className: "press flex h-11 items-center gap-1.5 rounded-2xl bg-primary px-3.5 text-primary-foreground font-semibold text-[13px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "h-4 w-4",
					strokeWidth: 2.4
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "הוסיפי מזון" })]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "num-pill flex h-12 items-center gap-2 px-3.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 shrink-0 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "חפשי קוטג', טונה, ביצה L, גבינה 9%...",
					className: "w-full min-w-0 bg-transparent text-[14px] outline-none placeholder:text-muted-foreground"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 no-scrollbar",
				dir: "rtl",
				children: FOOD_CATEGORIES.map((cat) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSelectedCategory(cat),
						className: `press shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-semibold transition-colors ${selectedCategory === cat ? "bg-primary text-primary-foreground shadow-sm" : "bg-secondary text-muted-foreground hover:bg-secondary/80"}`,
						children: cat === "מועדפים" ? "❤️ מועדפים" : cat
					}, cat);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				className: "mt-4",
				title: `${filtered.length} תוצאות`,
				subtitle: "לחצי על מאכל לצפייה ועריכת ערכים"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: filtered.slice(0, 80).map((food) => {
					const isFav = favSet.has(food.id) || Boolean(food.favorite);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-card press flex items-center justify-between gap-3 p-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/nutrition/foods/$foodId",
							params: { foodId: food.id },
							className: "flex min-w-0 flex-1 items-center gap-3.5 text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `grid h-11 w-11 shrink-0 place-items-center rounded-2xl ${food.isCustom ? "bg-rose-soft text-rose" : "bg-sage-soft text-primary"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Apple, {
									className: "h-4 w-4",
									strokeWidth: 1.8
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-display text-[14.5px] font-semibold text-ink",
										children: food.name
									}), food.isCustom ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-0.5 rounded-full bg-rose-soft px-2 py-0.5 text-[10px] font-bold text-rose",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-2.5 w-2.5" }), "אישי"]
									}) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-0.5 truncate text-[11.5px] text-muted-foreground",
									children: [
										food.servingSize,
										" · ",
										food.calories,
										" קלוריות · חלבון ",
										food.protein,
										"g · פחמימות",
										" ",
										food.carbs,
										"g"
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: (e) => {
								e.preventDefault();
								e.stopPropagation();
								toggleFavoriteFood(food.id);
							},
							className: `press grid h-9 w-9 shrink-0 place-items-center rounded-xl transition-colors ${isFav ? "bg-rose-soft text-rose" : "text-muted-foreground/60 hover:bg-secondary hover:text-muted-foreground"}`,
							"aria-label": isFav ? "הסרי ממועדפים" : "הוסיפי למועדפים",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: `h-4 w-4 ${isFav ? "fill-current" : ""}` })
						})]
					}, food.id);
				})
			}),
			filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Apple,
				title: "לא נמצאו מאכלים",
				description: "נסי לחפש שם אחר או ליצור מאכל מותאם אישית.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setCreateOpen(true),
					className: "press inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-[13.5px] font-semibold text-primary-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "h-4 w-4",
						strokeWidth: 2.4
					}), "הוסיפי מאכל חדש"]
				})
			}) : null,
			createOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-xs p-0 pb-20 sm:p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (el) => {
						if (el) el.scrollTop = 0;
					},
					className: "surface-card w-full max-w-md max-h-[85vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5 text-start shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-200",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-3 border-b border-border/40 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5 text-rose" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-[17px] font-bold text-ink",
								children: "הוסיפי מאכל מותאם אישית"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCreateOpen(false),
							className: "press grid h-8 w-8 place-items-center rounded-full bg-secondary text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleCreateCustom,
						className: "space-y-3.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "שם המוצר (בעברית) *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: "למשל: יוגורט חלבון ביתי",
								className: fieldCls
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "שם באנגלית (אופציונלי)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: englishName,
								onChange: (e) => setEnglishName(e.target.value),
								placeholder: "e.g. Homemade Protein Yogurt",
								className: fieldCls
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "קטגוריה *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: category,
								onChange: (e) => setCategory(e.target.value),
								className: fieldCls,
								children: FOOD_CATEGORIES.filter((c) => c !== "הכל" && c !== "מועדפים").map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c,
									children: c
								}, c))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "גודל מנת ייחוס (למשל: 100 גרם, יחידה 1)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: servingSize,
								onChange: (e) => setServingSize(e.target.value),
								placeholder: "100 גרם",
								className: fieldCls
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: labelCls,
										children: "קלוריות *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										step: "0.1",
										value: calories,
										onChange: (e) => setCalories(Number(e.target.value)),
										className: fieldCls
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: labelCls,
										children: "חלבון (גרם)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										step: "0.1",
										value: protein,
										onChange: (e) => setProtein(Number(e.target.value)),
										className: fieldCls
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: labelCls,
										children: "פחמימות (גרם)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										step: "0.1",
										value: carbs,
										onChange: (e) => setCarbs(Number(e.target.value)),
										className: fieldCls
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: labelCls,
										children: "שומן (גרם)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										step: "0.1",
										value: fat,
										onChange: (e) => setFat(Number(e.target.value)),
										className: fieldCls
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: labelCls,
								children: "סיבים תזונתיים (גרם)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								step: "0.1",
								value: fiber,
								onChange: (e) => setFiber(Number(e.target.value)),
								className: fieldCls
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-2 flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
									type: "submit",
									className: "flex-1",
									children: "שמרי מאכל חדש"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setCreateOpen(false),
									className: "press rounded-2xl bg-secondary px-4 py-3 text-[14px] font-semibold text-muted-foreground",
									children: "ביטול"
								})]
							})
						]
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {})
			})
		]
	});
}
//#endregion
export { FoodLibrary as component };
