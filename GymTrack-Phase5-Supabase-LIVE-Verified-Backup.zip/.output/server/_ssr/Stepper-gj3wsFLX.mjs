import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Plus, x as Minus } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Stepper-gj3wsFLX.js
var import_jsx_runtime = require_jsx_runtime();
function Stepper({ label, value, step = 1, min = 0, max, suffix, onChange }) {
	const clamp = (v) => {
		let n = Math.max(min, Math.round(v * 100) / 100);
		if (max != null) n = Math.min(max, n);
		return n;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1.5",
			dir: "ltr",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `הורד ${label}`,
					onClick: () => onChange(clamp(value - step)),
					className: "grid h-11 w-10 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground transition-transform active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-4 w-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "num-pill flex h-11 min-w-0 flex-1 items-center justify-center px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "decimal",
						value: Number.isFinite(value) ? value : 0,
						onChange: (e) => {
							const raw = e.target.value.replace(",", ".");
							if (raw === "" || raw === "-") {
								onChange(min);
								return;
							}
							const n = Number(raw);
							if (!Number.isNaN(n)) onChange(clamp(n));
						},
						className: "w-full min-w-0 bg-transparent text-center text-base font-semibold outline-none"
					}), suffix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pe-1.5 text-xs font-medium text-muted-foreground",
						children: suffix
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `הגדל ${label}`,
					onClick: () => onChange(clamp(value + step)),
					className: "grid h-11 w-10 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground transition-transform active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" })
				})
			]
		})]
	});
}
//#endregion
export { Stepper as t };
