import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as closestCenter, d as useSensors, f as CSS, i as TouchSensor, r as PointerSensor, t as DndContext, u as useSensor } from "../_libs/@dnd-kit/core+[...].mjs";
import { C as Link2, F as Dumbbell, G as ArrowRight, M as GripVertical, P as Flame, V as ChevronDown, g as Save, l as SlidersHorizontal, m as Search, o as Trash2, t as X, v as Plus, w as Link2Off } from "../_libs/lucide-react.mjs";
import { A as emptyItem, O as emptyExercise, T as deleteWorkout, at as uid, c as MUSCLE_GROUPS, et as saveWorkoutInProgram, f as SectionHeader, i as EQUIPMENT, j as emptyWarmup, o as EmptyState, q as saveExercise, s as IconButton, st as useGym, t as AppShell, tt as searchExercises, u as PrimaryButton } from "./AppShell-DdWWxz8T.mjs";
import { t as ConfirmSheet } from "./ConfirmSheet-C41QxcQv.mjs";
import { t as Stepper } from "./Stepper-gj3wsFLX.mjs";
import { i as verticalListSortingStrategy, n as arrayMove, r as useSortable, t as SortableContext } from "../_libs/dnd-kit__sortable.mjs";
import { t as Route } from "./programs._programId._dayId-lOKfNsdX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/programs._programId._dayId-BCWaBETL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fieldBase = "w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3.5 text-base outline-none focus:border-primary";
function ChipButton({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: `press shrink-0 rounded-full px-3.5 py-1.5 text-[12.5px] font-semibold transition-colors ${active ? "bg-primary text-primary-foreground shadow-sm" : "bg-secondary text-foreground hover:bg-secondary/70"}`,
		children
	});
}
function computeSupersetLabels(items) {
	const labels = {};
	let group = -1;
	let i = 0;
	while (i < items.length) {
		const sid = items[i]?.supersetId;
		if (sid) {
			let j = i;
			const run = [];
			while (j < items.length && items[j]?.supersetId === sid) {
				run.push(items[j]);
				j += 1;
			}
			if (run.length >= 2) {
				group += 1;
				const letter = String.fromCharCode(65 + group % 26);
				run.forEach((it, k) => {
					labels[it.id] = `${letter}${k + 1}`;
				});
			}
			i = j;
		} else i += 1;
	}
	return labels;
}
function DayBuilder() {
	const { programId, dayId } = Route.useParams();
	const navigate = useNavigate();
	const { programs, workouts, exercises } = useGym();
	const program = programs.find((item) => item.id === programId);
	const existing = workouts.find((workout) => workout.id === dayId);
	const isNew = dayId === "new" || !dayId;
	const [draft, setDraft] = (0, import_react.useState)(() => existing ?? makeBlankWorkout());
	const [picker, setPicker] = (0, import_react.useState)(false);
	const [pickerQuery, setPickerQuery] = (0, import_react.useState)("");
	const [pickerGroup, setPickerGroup] = (0, import_react.useState)("הכל");
	const [pickerEquipment, setPickerEquipment] = (0, import_react.useState)("הכל");
	const [creatingExercise, setCreatingExercise] = (0, import_react.useState)(false);
	const [newExerciseName, setNewExerciseName] = (0, import_react.useState)("");
	const [pendingDeleteDay, setPendingDeleteDay] = (0, import_react.useState)(false);
	const sensors = useSensors(useSensor(TouchSensor, { activationConstraint: {
		delay: 120,
		tolerance: 8
	} }), useSensor(PointerSensor));
	if (!program && !isNew) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "יום אימון לא נמצא",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "יום אימון זה אינו קיים עוד."
		})
	});
	if (!program) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "תכנית לא נמצאה",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "תכנית זו אינה קיימת עוד."
		})
	});
	const labels = computeSupersetLabels(draft.items);
	const patchItem = (id, patch) => setDraft((current) => ({
		...current,
		items: current.items.map((item) => item.id === id ? {
			...item,
			...patch
		} : item)
	}));
	const toggleSupersetWithPrev = (index) => {
		setDraft((current) => {
			if (index <= 0) return current;
			const items = [...current.items];
			const item = items[index];
			const prev = items[index - 1];
			if (item.supersetId && item.supersetId === prev.supersetId) items[index] = {
				...item,
				supersetId: void 0
			};
			else {
				const groupId = prev.supersetId ?? uid();
				items[index - 1] = {
					...prev,
					supersetId: groupId
				};
				items[index] = {
					...item,
					supersetId: groupId
				};
			}
			return {
				...current,
				items
			};
		});
	};
	const onDragEnd = ({ active, over }) => {
		if (!over || active.id === over.id) return;
		setDraft((current) => {
			const oldIndex = current.items.findIndex((item) => item.id === active.id);
			const newIndex = current.items.findIndex((item) => item.id === over.id);
			return oldIndex === -1 || newIndex === -1 ? current : {
				...current,
				items: arrayMove(current.items, oldIndex, newIndex)
			};
		});
	};
	const moveExercise = (index, direction) => {
		setDraft((current) => {
			const targetIndex = index + direction;
			if (targetIndex < 0 || targetIndex >= current.items.length) return current;
			return {
				...current,
				items: arrayMove(current.items, index, targetIndex)
			};
		});
	};
	const save = () => {
		if (!draft.name.trim()) return;
		saveWorkoutInProgram(program.id, {
			...draft,
			name: draft.name.trim()
		});
		navigate({
			to: "/programs/$programId",
			params: { programId: program.id }
		});
	};
	const pickerExercises = searchExercises(exercises, pickerQuery).filter((exercise) => (pickerGroup === "הכל" || exercise.muscleGroup === pickerGroup || (exercise.muscleGroups ?? []).includes(pickerGroup)) && (pickerEquipment === "הכל" || exercise.equipment === pickerEquipment));
	const addExercise = (exerciseId) => {
		setDraft((current) => ({
			...current,
			items: [...current.items, emptyItem(exerciseId)]
		}));
		setPicker(false);
		setPickerQuery("");
	};
	const createAndAddExercise = () => {
		const name = newExerciseName.trim();
		if (!name) return;
		const exercise = emptyExercise();
		exercise.name = name;
		saveExercise(exercise);
		addExercise(exercise.id);
		setNewExerciseName("");
		setCreatingExercise(false);
	};
	const totalSets = draft.items.reduce((sum, item) => sum + item.sets, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: isNew ? "יום חדש" : program.name,
		title: isNew ? "יום אימון חדש" : draft.name || "יום ללא שם",
		subtitle: `${draft.items.length} תרגילים · ${totalSets} סטים`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
			"aria-label": "חזרה לתכנית",
			onClick: () => navigate({
				to: "/programs/$programId",
				params: { programId }
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-5 w-5" })
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
						children: "שם יום האימון"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						"data-testid": "input-day-name",
						value: draft.name,
						onChange: (event) => setDraft({
							...draft,
							name: event.target.value
						}),
						className: "mt-2 w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3.5 font-display text-[17px] font-semibold text-ink outline-none placeholder:text-muted-foreground/70 focus:border-primary",
						placeholder: "למשל: פלג גוף עליון 1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3.5 text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
						children: "הערות ודגשים"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 2,
						value: draft.notes,
						onChange: (event) => setDraft({
							...draft,
							notes: event.target.value
						}),
						className: "mt-2 w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3.5 text-[14px] outline-none focus:border-primary",
						placeholder: "דגשים ליום האימון..."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				className: "mt-6",
				title: "תרגילים",
				subtitle: "גרורי לשינוי סדר, לחצי על כל תרגיל לעריכה"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DndContext, {
				sensors,
				collisionDetection: closestCenter,
				onDragEnd,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableContext, {
					items: draft.items.map((item) => item.id),
					strategy: verticalListSortingStrategy,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: draft.items.map((item, index) => {
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableItem, {
								item,
								exercise: exercises.find((exercise) => exercise.id === item.exerciseId),
								supersetLabel: labels[item.id],
								canSuperset: index > 0,
								supersetActive: Boolean(item.supersetId && item.supersetId === draft.items[index - 1]?.supersetId),
								onToggleSuperset: () => toggleSupersetWithPrev(index),
								onMoveUp: index > 0 ? () => moveExercise(index, -1) : void 0,
								onMoveDown: index < draft.items.length - 1 ? () => moveExercise(index, 1) : void 0,
								onPatch: patchItem,
								onRemove: () => setDraft({
									...draft,
									items: draft.items.filter((entry) => entry.id !== item.id)
								})
							}, item.id);
						})
					})
				})
			}),
			draft.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Dumbbell,
				title: "הוסיפי תרגילים ליום האימון",
				description: "בחרי תרגילים מספריית התרגילים או צרי תרגיל חדש. ניתן לבנות סופר-סטים, דרופ-סטים וסטי חימום.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setPicker(true),
					className: "press inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-[13.5px] font-semibold text-primary-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "h-4 w-4",
						strokeWidth: 2.4
					}), "הוסיפי תרגיל ראשון"]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"data-testid": "button-add-exercise-to-day",
				onClick: () => setPicker(true),
				className: "press mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-primary/40 bg-primary/5 text-[14px] font-semibold text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "h-4 w-4",
					strokeWidth: 2.4
				}), "הוסיפי תרגיל"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					"data-testid": "button-save-day",
					onClick: save,
					leading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {
						className: "h-4 w-4",
						strokeWidth: 2.2
					}),
					children: "שמור יום אימון"
				}), !isNew ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setPendingDeleteDay(true),
					className: "press flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-secondary text-[14.5px] font-semibold text-destructive",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " מחק יום אימון"]
				}) : null]
			}),
			picker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-40 flex flex-col justify-end bg-foreground/30 backdrop-blur-sm",
				onClick: () => setPicker(false),
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "scale-in max-h-[85dvh] overflow-y-auto rounded-t-[2rem] border-t border-border/40 bg-card p-5 text-start shadow-2xl",
					onClick: (event) => event.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3.5 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold tracking-[0.14em] text-primary uppercase",
								children: "ספריית תרגילים"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-[20px] font-semibold text-ink",
								children: "בחרי תרגיל להוספה"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								onClick: () => setPicker(false),
								"aria-label": "סגור",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "num-pill flex h-12 items-center gap-2 px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: pickerQuery,
								onChange: (event) => setPickerQuery(event.target.value),
								placeholder: "חפש לפי שם, ציוד או שריר...",
								className: "w-full bg-transparent text-[14px] outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1",
								dir: "rtl",
								"aria-label": "סינון לפי קבוצת שרירים",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipButton, {
									active: pickerGroup === "הכל",
									onClick: () => setPickerGroup("הכל"),
									children: "הכל"
								}), MUSCLE_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipButton, {
									active: pickerGroup === group,
									onClick: () => setPickerGroup(group),
									children: group
								}, group))]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1",
								dir: "rtl",
								"aria-label": "סינון לפי ציוד",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipButton, {
									active: pickerEquipment === "הכל",
									onClick: () => setPickerEquipment("הכל"),
									children: "הכל"
								}), EQUIPMENT.map((equipment) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipButton, {
									active: pickerEquipment === equipment,
									onClick: () => setPickerEquipment(equipment),
									children: equipment
								}, equipment))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3.5 space-y-2",
							children: [pickerExercises.map((exercise) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => addExercise(exercise.id),
								className: "press flex w-full items-center justify-between gap-3 rounded-2xl border border-border/40 bg-secondary px-3.5 py-3 text-start",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/70 text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, {
											className: "h-4 w-4",
											strokeWidth: 1.8
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-[14px] font-semibold text-ink",
											children: exercise.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11.5px] text-muted-foreground",
											children: exercise.muscleGroup
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "num-pill shrink-0 px-2.5 py-1 text-[11px] font-medium text-muted-foreground",
										children: exercise.equipment
									})
								]
							}, exercise.id)), pickerExercises.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-2xl bg-secondary p-4 text-[13px] text-muted-foreground",
								children: "לא נמצאו תרגילים מתאימים לחיפוש."
							}) : null]
						}),
						creatingExercise ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-2xl border border-primary/20 bg-primary/5 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-semibold tracking-[0.14em] text-primary uppercase",
								htmlFor: "new-picker-exercise",
								children: "תרגיל חדש"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "new-picker-exercise",
									autoFocus: true,
									value: newExerciseName,
									onChange: (event) => setNewExerciseName(event.target.value),
									placeholder: "שם התרגיל",
									className: "min-w-0 flex-1 rounded-2xl border border-border bg-card px-3 py-3 text-[14px] outline-none focus:border-primary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: createAndAddExercise,
									className: "press shrink-0 rounded-2xl bg-primary px-4 text-[14px] font-semibold text-primary-foreground",
									children: "הוסף"
								})]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCreatingExercise(true),
							className: "press mt-4 w-full rounded-2xl border border-dashed border-primary/40 bg-primary/5 px-4 py-3 text-[13.5px] font-semibold text-primary",
							children: "+ צור תרגיל חדש בספרייה"
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				open: pendingDeleteDay,
				title: "למחוק את יום האימון?",
				description: `הפעולה תמחק את "${draft.name}" ואת כל התרגילים שבו. לא ניתן לשחזר.`,
				confirmLabel: "מחק יום",
				cancelLabel: "חזרה",
				destructive: true,
				onConfirm: () => {
					deleteWorkout(draft.id);
					setPendingDeleteDay(false);
					navigate({
						to: "/programs/$programId",
						params: { programId }
					});
				},
				onCancel: () => setPendingDeleteDay(false)
			})
		]
	});
}
function makeBlankWorkout() {
	return {
		id: uid(),
		name: "",
		notes: "",
		items: []
	};
}
function SortableItem({ item, exercise, supersetLabel, canSuperset, supersetActive, onToggleSuperset, onMoveUp, onMoveDown, onPatch, onRemove }) {
	const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: item.id });
	const [advanced, setAdvanced] = (0, import_react.useState)(false);
	const name = exercise?.name ?? "תרגיל שהוסר";
	const isRange = item.repType === "range";
	const warmups = item.warmups ?? [];
	const workingSets = item.workingSets ?? Array.from({ length: item.sets }, (_, index) => ({
		id: `${item.id}-set-${index}`,
		setNumber: index + 1,
		weight: item.weight,
		reps: item.reps
	}));
	const setRepType = (type) => {
		if (type === "range") onPatch(item.id, {
			repType: "range",
			repMin: item.repMin ?? item.reps,
			repMax: item.repMax ?? item.reps + 2
		});
		else onPatch(item.id, { repType: "fixed" });
	};
	const patchWarmup = (wid, patch) => onPatch(item.id, { warmups: warmups.map((w) => w.id === wid ? {
		...w,
		...patch
	} : w) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		ref: setNodeRef,
		style: {
			transform: CSS.Transform.toString(transform),
			transition
		},
		className: `surface-card p-4 text-start ${isDragging ? "relative z-10 opacity-75 shadow-lg" : ""} ${supersetLabel ? "border-s-4 border-s-primary/70 rounded-s-none" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center justify-center gap-0.5 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onMoveUp,
							disabled: !onMoveUp,
							"aria-label": `הזז למעלה את ${name}`,
							className: "press grid h-6 w-6 place-items-center rounded-md bg-secondary text-[10px] font-bold text-ink disabled:opacity-30",
							children: "▲"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onMoveDown,
							disabled: !onMoveDown,
							"aria-label": `הזז למטה את ${name}`,
							className: "press grid h-6 w-6 place-items-center rounded-md bg-secondary text-[10px] font-bold text-ink disabled:opacity-30",
							children: "▼"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						...attributes,
						...listeners,
						"aria-label": `שנה סדר ${name}`,
						className: "press grid h-10 w-7 shrink-0 touch-none place-items-center rounded-xl text-muted-foreground/60 hover:bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [supersetLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 rounded-lg bg-primary px-2 py-0.5 text-[11px] font-bold text-primary-foreground",
								children: supersetLabel
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "min-w-0 truncate font-display text-[15px] font-semibold text-ink",
								children: name
							})]
						}), exercise ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-[12px] text-muted-foreground",
							children: [exercise.equipment, exercise.muscleGroup ? ` · ${exercise.muscleGroup}` : ""]
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onRemove,
						"aria-label": `הסר ${name}`,
						className: "press grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-secondary text-muted-foreground hover:text-destructive",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})
				]
			}),
			canSuperset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onToggleSuperset,
				className: `press mt-3 flex w-full items-center justify-center gap-1.5 rounded-2xl py-2.5 text-[12.5px] font-semibold transition-colors ${supersetActive ? "bg-primary/15 text-primary" : "bg-secondary text-muted-foreground hover:bg-secondary/80"}`,
				children: [supersetActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2Off, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-3.5 w-3.5" }), supersetActive ? "בטל סופר-סט עם הקודם" : "חבר בסופר-סט לקודם"]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
					label: "סטים",
					value: item.sets,
					min: 1,
					onChange: (value) => onPatch(item.id, { sets: value })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
					label: "מנוחה",
					value: item.rest,
					step: 15,
					suffix: "שניות",
					onChange: (value) => onPatch(item.id, { rest: value })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
						children: "סוג חזרות"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex rounded-2xl bg-secondary p-0.5 text-[11px] font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setRepType("fixed"),
							className: `press rounded-xl px-3 py-1.5 ${!isRange ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
							children: "קבוע"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setRepType("range"),
							className: `press rounded-xl px-3 py-1.5 ${isRange ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`,
							children: "טווח"
						})]
					})]
				}), isRange ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "מינימום",
						value: item.repMin ?? item.reps,
						min: 0,
						onChange: (value) => onPatch(item.id, { repMin: value })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "מקסימום",
						value: item.repMax ?? item.reps,
						min: 0,
						onChange: (value) => onPatch(item.id, { repMax: value })
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
					label: "חזרות מטרה",
					value: item.reps,
					min: 0,
					onChange: (value) => onPatch(item.id, { reps: value })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-2xl border border-border/40 bg-secondary/50 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-primary/15 text-[10px] font-bold text-primary",
						children: item.sets
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
						children: "משקל וחזרות לכל סט"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2.5",
					children: workingSets.slice(0, item.sets).map((set, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-white/70 px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[1.5rem_1fr_1fr] items-end gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-7 w-7 place-items-center rounded-lg bg-primary/10 text-[11px] font-bold text-primary",
									children: index + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
									label: "משקל",
									value: set.weight,
									step: 2.5,
									suffix: "ק״ג",
									onChange: (weight) => onPatch(item.id, { workingSets: workingSets.map((current, i) => i === index ? {
										...current,
										weight
									} : current) })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
									label: "חזרות",
									value: set.reps,
									min: 0,
									onChange: (reps) => onPatch(item.id, { workingSets: workingSets.map((current, i) => i === index ? {
										...current,
										reps
									} : current) })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-1.5 flex cursor-pointer items-center gap-2 px-1 text-[11.5px] font-medium text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: Boolean(set.dropSet),
								onChange: (event) => onPatch(item.id, { workingSets: workingSets.map((current, i) => i === index ? {
									...current,
									dropSet: event.target.checked
								} : current) }),
								className: "h-4 w-4 rounded border-border text-primary"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: set.dropSet ? "font-semibold text-primary" : "",
								children: "Drop Set"
							})]
						})]
					}, set.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: `${fieldBase} mt-3 text-[14px]`,
				value: item.notes,
				onChange: (event) => onPatch(item.id, { notes: event.target.value }),
				placeholder: "הערה לתרגיל (למשל: דגש על ירידה איטית)"
			}),
			warmups.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
							className: "h-3.5 w-3.5 text-primary",
							strokeWidth: 2.2
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold tracking-[0.14em] text-primary uppercase",
							children: "סטי חימום"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: warmups.map((w, wi) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-primary/15 text-[11px] font-bold text-primary",
									children: wi + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid flex-1 grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										label: "ק״ג",
										value: w.weight,
										step: 2.5,
										onChange: (value) => patchWarmup(w.id, { weight: value })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										label: "חזרות (>9)",
										value: w.reps,
										min: 0,
										onChange: (value) => patchWarmup(w.id, { reps: value })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "הסר סט חימום",
									onClick: () => onPatch(item.id, { warmups: warmups.filter((x) => x.id !== w.id) }),
									className: "press grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
								})
							]
						}, w.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onPatch(item.id, { warmups: [...warmups, emptyWarmup()] }),
						className: "press mt-2 w-full rounded-xl bg-white py-2 text-[12.5px] font-semibold text-primary",
						children: "+ הוסף סט חימום"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onPatch(item.id, { warmups: [emptyWarmup()] }),
				className: "press mt-3 flex w-full items-center justify-center gap-1.5 rounded-2xl bg-secondary py-2.5 text-[12.5px] font-semibold text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "h-3.5 w-3.5" }), "הוסף סטי חימום"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setAdvanced((v) => !v),
				className: "press mt-3 flex w-full items-center justify-between rounded-2xl px-1 py-2 text-[12.5px] font-semibold text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-3.5 w-3.5" }), "מתקדם · טמפו · RIR · RPE"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-4 w-4 transition-transform ${advanced ? "rotate-180" : ""}` })]
			}),
			advanced ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mb-1 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground",
						children: "טמפו"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: item.tempo ?? "",
						onChange: (event) => onPatch(item.id, { tempo: event.target.value }),
						placeholder: "3-1-1-0",
						className: "w-full rounded-xl border border-border/60 bg-secondary px-2 py-2 text-center text-[13px] outline-none focus:border-primary"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mb-1 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground",
						children: "RIR"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "numeric",
						value: item.rir ?? "",
						onChange: (event) => onPatch(item.id, { rir: event.target.value === "" ? null : Number(event.target.value.replace(/\D/g, "")) }),
						placeholder: "—",
						className: "w-full rounded-xl border border-border/60 bg-secondary px-2 py-2 text-center text-[13px] outline-none focus:border-primary"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mb-1 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground",
						children: "RPE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "decimal",
						value: item.rpe ?? "",
						onChange: (event) => onPatch(item.id, { rpe: event.target.value === "" ? null : Number(event.target.value.replace(/[^\d.]/g, "")) }),
						placeholder: "—",
						className: "w-full rounded-xl border border-border/60 bg-secondary px-2 py-2 text-center text-[13px] outline-none focus:border-primary"
					})] })
				]
			}) : null
		]
	});
}
//#endregion
export { DayBuilder as component };
