import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workouts._workoutId-CqPUmJ1c.js
var $$splitComponentImporter = () => import("./workouts._workoutId-DInPyXnU.mjs");
var Route = createFileRoute("/workouts/$workoutId")({
	head: () => ({ meta: [{ title: "עורך אימון — הרוטינה שלי" }, {
		property: "og:title",
		content: "עורך אימון — הרוטינה שלי"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
