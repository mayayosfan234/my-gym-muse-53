import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { B as ChevronLeft, D as Info, H as Check, I as Copy, _ as RefreshCw, m as Search, s as Timer, t as X, u as SkipForward, v as Plus, y as Play } from "../_libs/lucide-react.mjs";
import { F as lastPerformance, H as repLabel, Z as saveSession, at as uid, s as IconButton, st as useGym, t as AppShell, tt as searchExercises, u as PrimaryButton } from "./AppShell-B3CNDLiS.mjs";
import { t as ConfirmSheet } from "./ConfirmSheet-Bs6zdV30.mjs";
import { t as Stepper } from "./Stepper-gj3wsFLX.mjs";
import { t as Route } from "./session._workoutId-CPYgpkCB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session._workoutId-U3wkqgvN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function supersetLabels(items) {
	const labels = {};
	let group = -1;
	let i = 0;
	while (i < items.length) {
		const sid = items[i]?.supersetId;
		if (sid) {
			let j = i;
			const run = [];
			while (j < items.length && items[j]?.supersetId === sid) {
				run.push(j);
				j += 1;
			}
			if (run.length >= 2) {
				group += 1;
				const letter = String.fromCharCode(65 + group % 26);
				run.forEach((idx, k) => {
					labels[idx] = `${letter}${k + 1}`;
				});
			}
			i = j;
		} else i += 1;
	}
	return labels;
}
var ACTIVE_SESSION_KEY = (id) => `gymtrack.active_session.${id}`;
function Session() {
	const { workoutId } = Route.useParams();
	const navigate = useNavigate();
	const { workouts, exercises, history, programs } = useGym();
	const workout = workouts.find((w) => w.id === workoutId);
	const currentProgram = programs.find((program) => program.dayIds.includes(workoutId));
	const [cardExercise, setCardExercise] = (0, import_react.useState)(null);
	const [replacingIndex, setReplacingIndex] = (0, import_react.useState)(null);
	const [replaceSearch, setReplaceSearch] = (0, import_react.useState)("");
	const initial = (0, import_react.useMemo)(() => {
		if (!workout) return [];
		try {
			const saved = localStorage.getItem(ACTIVE_SESSION_KEY(workoutId));
			if (saved) {
				const parsed = JSON.parse(saved);
				if (Array.isArray(parsed) && parsed.length === workout.items.length) return parsed;
			}
		} catch {}
		return workout.items.map((item) => {
			const ex = exercises.find((e) => e.id === item.exerciseId);
			const last = lastPerformance(history, item.exerciseId);
			const isRange = item.repType === "range";
			const targetReps = isRange ? item.repMin ?? item.reps : item.reps;
			const targetRepMax = isRange ? item.repMax : void 0;
			const warmups = (item.warmups ?? []).map((w) => ({
				reps: w.reps,
				weight: w.weight,
				done: false,
				warmup: true
			}));
			const working = Array.from({ length: item.sets }, (_, i) => ({
				reps: last?.sets[i]?.reps ?? item.workingSets?.[i]?.reps ?? targetReps,
				weight: last?.sets[i]?.weight ?? item.workingSets?.[i]?.weight ?? item.weight,
				done: false,
				targetReps,
				targetRepMax,
				warmup: false,
				dropSet: item.workingSets?.[i]?.dropSet
			}));
			return {
				exerciseId: item.exerciseId,
				exerciseName: ex?.name ?? "תרגיל שהוסר",
				equipment: ex?.equipment,
				notes: item.notes,
				targetSets: item.sets,
				targetReps,
				targetRepMax,
				repType: item.repType,
				sets: [...warmups, ...working]
			};
		});
	}, [workoutId]);
	const [entries, setEntries] = (0, import_react.useState)(initial);
	const [startedAt] = (0, import_react.useState)(() => Date.now());
	const [rest, setRest] = (0, import_react.useState)(0);
	const [customRest, setCustomRest] = (0, import_react.useState)("");
	const [pendingExit, setPendingExit] = (0, import_react.useState)(false);
	const timerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setEntries(initial);
	}, [initial]);
	(0, import_react.useEffect)(() => {
		if (!workoutId || entries.length === 0) return;
		try {
			localStorage.setItem(ACTIVE_SESSION_KEY(workoutId), JSON.stringify(entries));
		} catch {}
	}, [entries, workoutId]);
	const previousRestRef = (0, import_react.useRef)(rest);
	(0, import_react.useEffect)(() => {
		if (rest <= 0) {
			if (previousRestRef.current > 0) {
				if (typeof navigator !== "undefined" && "vibrate" in navigator) try {
					navigator.vibrate([
						100,
						50,
						100
					]);
				} catch {}
			}
			previousRestRef.current = 0;
			return;
		}
		previousRestRef.current = rest;
		timerRef.current = setInterval(() => setRest((r) => Math.max(0, r - 1)), 1e3);
		return () => {
			if (timerRef.current) clearInterval(timerRef.current);
		};
	}, [rest]);
	if (!workout) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "אימון לא נמצא",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "אימון זה אינו קיים עוד בספרייה."
		})
	});
	const labels = supersetLabels(workout.items);
	const patchSet = (ei, si, patch) => setEntries((prev) => prev.map((e, i) => i === ei ? {
		...e,
		sets: e.sets.map((s, j) => j === si ? {
			...s,
			...patch
		} : s)
	} : e));
	const toggleSetDone = (ei, si) => {
		const currentSet = entries[ei]?.sets[si];
		if (!currentSet) return;
		const isNowDone = !currentSet.done;
		patchSet(ei, si, { done: isNowDone });
		if (isNowDone && !currentSet.warmup) {
			const restSec = workout.items[ei]?.rest ?? 60;
			setRest(restSec);
		}
	};
	const copySetValues = (ei, si) => {
		if (si <= 0) return;
		const prevSet = entries[ei]?.sets[si - 1];
		if (prevSet) patchSet(ei, si, {
			weight: prevSet.weight,
			reps: prevSet.reps
		});
	};
	const replaceExercise = (ei, newEx) => {
		setEntries((prev) => prev.map((e, i) => i === ei ? {
			...e,
			exerciseId: newEx.id,
			exerciseName: newEx.name,
			equipment: newEx.equipment
		} : e));
		setReplacingIndex(null);
		setReplaceSearch("");
	};
	const clearSavedSession = () => {
		try {
			localStorage.removeItem(ACTIVE_SESSION_KEY(workout.id));
		} catch {}
	};
	const totalSets = entries.reduce((a, e) => a + e.sets.filter((s) => !s.warmup).length, 0);
	const doneSets = entries.reduce((a, e) => a + e.sets.filter((s) => s.done && !s.warmup).length, 0);
	const finish = () => {
		saveSession({
			id: uid(),
			workoutId: workout.id,
			workoutName: workout.name,
			programName: currentProgram?.name,
			date: (/* @__PURE__ */ new Date()).toISOString(),
			durationSec: Math.round((Date.now() - startedAt) / 1e3),
			entries: entries.map((e) => ({
				...e,
				sets: e.sets.filter((s) => s.done)
			}))
		});
		clearSavedSession();
		navigate({ to: "/history" });
	};
	const progress = totalSets ? doneSets / totalSets * 100 : 0;
	const filteredExercisesForReplace = searchExercises(exercises, replaceSearch);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: currentProgram?.name ?? "אימון",
		title: workout.name,
		subtitle: `${doneSets} מתוך ${totalSets} סטים · בהצלחה!`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
			"aria-label": "יציאה מהאימון",
			onClick: () => setPendingExit(true),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card flex items-center gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3.5 w-3.5 fill-current" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
							children: "התקדמות אימון"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11.5px] font-semibold tabular-nums text-ink",
							children: [Math.round(progress), "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary transition-all duration-500",
							style: { width: `${progress}%` }
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-4",
				children: entries.map((entry, ei) => {
					const item = workout.items[ei];
					const last = lastPerformance(history, entry.exerciseId);
					const targetLabel = item ? repLabel(item) : String(entry.targetReps ?? "");
					const supersetLabel = labels[ei];
					const fullExercise = exercises.find((e) => e.id === entry.exerciseId);
					const workingCount = entry.sets.filter((s) => !s.warmup).length;
					const doneCount = entry.sets.filter((s) => s.done && !s.warmup).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `surface-card p-4 ${supersetLabel ? "border-s-4 border-s-primary rounded-s-none" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => fullExercise && setCardExercise(fullExercise),
										className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-sage-soft text-primary press",
										"aria-label": `פתח פרטי ${entry.exerciseName}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
											className: "h-4 w-4",
											strokeWidth: 2
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1 text-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [supersetLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "shrink-0 rounded-lg bg-primary px-2 py-0.5 text-[11px] font-bold text-primary-foreground",
												children: supersetLabel
											}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => fullExercise && setCardExercise(fullExercise),
												className: "min-w-0 truncate text-start font-display text-[15.5px] font-semibold text-ink hover:text-primary",
												children: entry.exerciseName
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-0.5 text-[12px] text-muted-foreground",
											children: [
												entry.equipment ? `${entry.equipment} · ` : "",
												entry.targetSets ?? workingCount,
												"× ",
												targetLabel,
												" חזרות"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setReplacingIndex(ei),
											className: "press grid h-9 w-9 place-items-center rounded-full bg-secondary text-muted-foreground hover:text-primary",
											title: "החליפי תרגיל",
											"aria-label": "החליפי תרגיל",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-3.5 w-3.5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setRest(item?.rest ?? 60),
											className: "press flex shrink-0 items-center gap-1 rounded-full bg-secondary px-3 py-2 text-[12px] font-semibold text-ink",
											"aria-label": "התחל מנוחה",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "h-3.5 w-3.5 text-primary" }),
												item?.rest ?? 60,
												"ש׳"
											]
										})]
									})
								]
							}),
							entry.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 rounded-2xl bg-secondary/70 px-3 py-2 text-[12.5px] text-muted-foreground text-start",
								children: entry.notes
							}) : null,
							last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-center gap-1.5 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10.5px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
									children: "אימון קודם"
								}), last.sets.slice(0, 5).map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "num-pill px-2 py-0.5 text-[11.5px] tabular-nums text-ink-soft",
									dir: "ltr",
									children: [
										s.weight,
										"kg × ",
										s.reps
									]
								}, i))]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 space-y-2",
								children: entry.sets.map((s, si) => {
									const workingIndex = entry.sets.slice(0, si + 1).filter((x) => !x.warmup).length;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `rounded-2xl border p-3 transition-all ${s.done ? "border-primary bg-primary/10 shadow-sm" : s.warmup ? "border-dashed border-border bg-secondary/40" : "border-border/60 bg-secondary/60"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `grid h-7 w-7 place-items-center rounded-lg text-[11px] font-bold ${s.warmup ? "bg-secondary text-muted-foreground" : s.done ? "bg-primary text-primary-foreground" : "bg-primary/15 text-primary"}`,
														children: s.warmup ? "W" : workingIndex
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "min-w-0 flex-1 text-start flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "truncate text-[12.5px] font-semibold text-ink",
															children: [s.warmup ? "סט חימום" : s.dropSet ? "Drop Set" : `סט ${workingIndex}`, s.targetRepMax ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "ms-1 text-[11px] font-normal text-muted-foreground",
																children: [
																	"· יעד ",
																	s.targetReps,
																	"-",
																	s.targetRepMax
																]
															}) : s.targetReps ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "ms-1 text-[11px] font-normal text-muted-foreground",
																children: ["· יעד ", s.targetReps]
															}) : null]
														}), !s.warmup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => patchSet(ei, si, { dropSet: !s.dropSet }),
															className: `press rounded-lg px-2 py-0.5 text-[10.5px] font-bold transition-colors ${s.dropSet ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-ink"}`,
															children: s.dropSet ? "✓ דרופ סט" : "+ דרופ"
														}) : null]
													}),
													si > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => copySetValues(ei, si),
														className: "press flex items-center gap-1 rounded-xl bg-secondary px-2 py-1 text-[11px] font-medium text-muted-foreground hover:text-ink",
														title: "העתק משקל וחזרות מסט קודם",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3 w-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "hidden sm:inline",
															children: "העתקי"
														})]
													}) : null,
													!s.warmup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => toggleSetDone(ei, si),
														className: `press grid h-11 w-11 place-items-center rounded-2xl text-[13px] font-bold transition-colors ${s.done ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:bg-secondary/80"}`,
														"aria-label": s.done ? "בטל סיום סט" : "סמן סט כבוצע",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
															className: "h-5 w-5",
															strokeWidth: 2.6
														})
													}) : null
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 grid grid-cols-2 gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
													label: "משקל",
													value: s.weight,
													step: 2.5,
													suffix: "ק״ג",
													onChange: (v) => patchSet(ei, si, { weight: v })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
													label: "חזרות בפועל",
													value: s.reps,
													min: 0,
													onChange: (v) => patchSet(ei, si, { reps: v })
												})]
											}),
											s.dropSet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 border-t border-border/40 pt-2.5 space-y-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[11px] font-bold text-primary uppercase",
														children: "מדרגות דרופ (Drop Stages)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => {
															const drops = s.drops ?? [];
															const lastStage = drops[drops.length - 1] ?? {
																weight: s.weight,
																reps: s.reps
															};
															const newDrop = {
																weight: Math.max(0, Math.round(lastStage.weight * .75 * 2) / 2),
																reps: lastStage.reps
															};
															patchSet(ei, si, { drops: [...drops, newDrop] });
														},
														className: "press flex items-center gap-1 rounded-xl bg-primary/10 px-2.5 py-1 text-[11px] font-bold text-primary",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }), "הוסיפי מדרגה"]
													})]
												}), (s.drops ?? []).map((stage, dropIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "rounded-xl border border-primary/20 bg-background/80 p-2 text-start",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between mb-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-[11px] font-bold text-ink",
															children: ["דרופ #", dropIdx + 1]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => {
																const nextDrops = (s.drops ?? []).filter((_, idx) => idx !== dropIdx);
																patchSet(ei, si, { drops: nextDrops });
															},
															className: "text-[11px] font-semibold text-destructive hover:underline",
															children: "הסר"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "grid grid-cols-2 gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
															label: "משקל דרופ",
															value: stage.weight,
															step: 2.5,
															suffix: "ק״ג",
															onChange: (v) => {
																const nextDrops = [...s.drops ?? []];
																if (nextDrops[dropIdx]) {
																	nextDrops[dropIdx] = {
																		...nextDrops[dropIdx],
																		weight: v
																	};
																	patchSet(ei, si, { drops: nextDrops });
																}
															}
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
															label: "חזרות דרופ",
															value: stage.reps,
															min: 0,
															onChange: (v) => {
																const nextDrops = [...s.drops ?? []];
																if (nextDrops[dropIdx]) {
																	nextDrops[dropIdx] = {
																		...nextDrops[dropIdx],
																		reps: v
																	};
																	patchSet(ei, si, { drops: nextDrops });
																}
															}
														})]
													})]
												}, dropIdx))]
											}) : null
										]
									}, si);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setEntries((prev) => prev.map((e, i) => i === ei ? {
										...e,
										sets: [...e.sets, {
											reps: e.sets[e.sets.length - 1]?.reps ?? 10,
											weight: e.sets[e.sets.length - 1]?.weight ?? 20,
											done: false,
											targetReps: e.targetReps,
											targetRepMax: e.targetRepMax,
											warmup: false
										}]
									} : e)),
									className: "press flex h-11 items-center justify-center gap-1.5 rounded-2xl bg-secondary text-[12.5px] font-semibold text-ink",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
										className: "h-4 w-4",
										strokeWidth: 2.2
									}), "הוסיפי סט"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setEntries((prev) => prev.map((e, i) => i === ei ? {
										...e,
										sets: [...e.sets, {
											reps: e.sets[e.sets.length - 1]?.reps ?? 10,
											weight: Math.max(0, Math.round((e.sets[e.sets.length - 1]?.weight ?? 20) * .8 * 2) / 2),
											done: false,
											targetReps: e.targetReps,
											targetRepMax: e.targetRepMax,
											warmup: false,
											dropSet: true
										}]
									} : e)),
									className: "press flex h-11 items-center justify-center gap-1.5 rounded-2xl bg-primary/12 text-[12.5px] font-semibold text-primary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
										className: "h-4 w-4",
										strokeWidth: 2.2
									}), "הוסיפי דרופ סט"]
								})]
							}),
							doneCount > 0 && doneCount < workingCount ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-[11px] font-medium text-muted-foreground text-start",
								children: [
									doneCount,
									"/",
									workingCount,
									" הושלמו"
								]
							}) : doneCount === workingCount && workingCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[11px] font-semibold text-primary text-start",
								children: "✓ כל הסטים הושלמו"
							}) : null
						]
					}, `${entry.exerciseId}-${ei}`);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: finish,
					leading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "h-4 w-4",
						strokeWidth: 2.4
					}),
					children: "סיימי ושמרי אימון"
				})
			}),
			rest > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scale-in fixed inset-x-0 z-40 mx-auto max-w-xl px-4",
				style: { bottom: "calc(5.5rem + env(safe-area-inset-bottom))" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ink-card flex items-center gap-2 p-3.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white/15",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "h-4 w-4 text-primary-foreground" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0 text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-semibold tracking-[0.14em] text-primary-foreground/80 uppercase",
								children: "זמן מנוחה"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-[20px] font-semibold tabular-nums text-primary-foreground",
								children: [
									Math.floor(rest / 60),
									":",
									String(rest % 60).padStart(2, "0")
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setRest((r) => Math.max(0, r - 15)),
									className: "press rounded-xl bg-white/15 px-2.5 py-1.5 text-[12px] font-bold text-primary-foreground hover:bg-white/25",
									title: "-15 שניות",
									children: "-15ש׳"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setRest((r) => r + 15),
									className: "press rounded-xl bg-white/15 px-2.5 py-1.5 text-[12px] font-bold text-primary-foreground hover:bg-white/25",
									title: "+15 שניות",
									children: "+15ש׳"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setRest(0),
									className: "press flex items-center gap-1 rounded-xl bg-white/20 px-3 py-1.5 text-[12px] font-bold text-primary-foreground hover:bg-white/30",
									title: "דלגי",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "h-3.5 w-3.5 fill-current" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "דילוג" })]
								})
							]
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center gap-2 rounded-2xl bg-secondary px-3 py-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "h-4 w-4 text-primary" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "numeric",
						value: customRest,
						onChange: (e) => setCustomRest(e.target.value.replace(/\D/g, "")),
						placeholder: "מנוחה מותאמת (שניות)...",
						className: "min-w-0 flex-1 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							const seconds = Number(customRest);
							if (seconds > 0) setRest(seconds);
						},
						className: "press rounded-full bg-primary px-3 py-1.5 text-[12px] font-semibold text-primary-foreground",
						children: "התחילי"
					})
				]
			}),
			cardExercise ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm",
				onClick: () => setCardExercise(null),
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (el) => {
						if (el) el.scrollTop = 0;
					},
					className: "scale-in max-h-[88dvh] w-full max-w-xl overflow-y-auto rounded-t-[2rem] border-t border-border/40 bg-card p-5 text-start shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-sage-soft text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
										className: "h-5 w-5",
										strokeWidth: 1.8
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-[20px] font-semibold leading-tight text-ink",
										children: cardExercise.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-0.5 text-[12.5px] text-muted-foreground",
										children: [cardExercise.equipment, cardExercise.muscleGroup ? ` · ${cardExercise.muscleGroup}` : ""]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									"aria-label": "סגור",
									onClick: () => setCardExercise(null),
									variant: "ghost",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
								})
							]
						}),
						cardExercise.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-2xl bg-secondary p-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
								children: "תיאור"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 whitespace-pre-wrap text-[13px] leading-relaxed text-ink",
								children: cardExercise.description
							})]
						}) : null,
						cardExercise.instructions ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 rounded-2xl bg-secondary p-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
								children: "הוראות ביצוע"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 whitespace-pre-wrap text-[13px] leading-relaxed text-ink",
								children: cardExercise.instructions
							})]
						}) : null,
						cardExercise.videoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: cardExercise.videoUrl,
							target: "_blank",
							rel: "noreferrer",
							className: "press mt-3 flex items-center justify-center gap-2 rounded-2xl bg-secondary p-3.5 text-[13px] font-semibold text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" }), "צפי בסרטון טכניקה"]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/exercises/$exerciseId",
							params: { exerciseId: cardExercise.id },
							onClick: () => setCardExercise(null),
							className: "press mt-4 flex h-12 w-full items-center justify-center rounded-2xl bg-primary text-[14px] font-semibold text-primary-foreground",
							children: "פתח עמוד תרגיל מלא"
						})
					]
				})
			}) : null,
			replacingIndex !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm",
				onClick: () => setReplacingIndex(null),
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (el) => {
						if (el) el.scrollTop = 0;
					},
					className: "scale-in max-h-[85dvh] w-full max-w-xl overflow-y-auto rounded-t-[2rem] border-t border-border/40 bg-card p-5 text-start shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-[18px] font-bold text-ink",
								children: ["החליפי תרגיל במקום: ", entries[replacingIndex]?.exerciseName]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								"aria-label": "סגור",
								onClick: () => setReplacingIndex(null),
								variant: "ghost",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-2 rounded-2xl bg-secondary px-3.5 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 text-muted-foreground shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: replaceSearch,
								onChange: (e) => setReplaceSearch(e.target.value),
								placeholder: "חפשי תרגיל חלופי...",
								className: "min-w-0 flex-1 bg-transparent text-[13.5px] outline-none placeholder:text-muted-foreground"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 space-y-2 pb-6",
							children: filteredExercisesForReplace.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => replaceExercise(replacingIndex, ex),
								className: "press flex w-full items-center justify-between rounded-2xl bg-secondary p-3.5 text-start hover:bg-secondary/80",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold text-ink text-[14px]",
									children: ex.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[12px] text-muted-foreground",
									children: [
										ex.muscleGroup,
										" ",
										ex.equipment ? `· ${ex.equipment}` : ""
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-xl bg-primary/10 px-2.5 py-1 text-[12px] font-semibold text-primary",
									children: "בחרי"
								})]
							}, ex.id))
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				open: pendingExit,
				title: "לצאת מהאימון?",
				description: "הסטים שתיעדת עד כה יישמרו רק אם לא תנקי את הנתונים, אך לא יישמרו בהיסטוריית האימונים הסופית.",
				confirmLabel: "צאי בלי לשמור",
				cancelLabel: "המשיכי באימון",
				destructive: true,
				onConfirm: () => {
					clearSavedSession();
					setPendingExit(false);
					navigate({ to: "/programs" });
				},
				onCancel: () => setPendingExit(false)
			})
		]
	});
}
//#endregion
export { Session as component };
