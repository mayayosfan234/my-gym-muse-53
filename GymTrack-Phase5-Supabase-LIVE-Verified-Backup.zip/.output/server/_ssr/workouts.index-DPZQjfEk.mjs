import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as AppShell } from "./AppShell-B3CNDLiS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workouts.index-DPZQjfEk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Workouts() {
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		navigate({
			to: "/programs",
			replace: true
		});
	}, [navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "תוכניות אימון",
		subtitle: "מעביר אותך למתחם התוכניות...",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "surface-card animate-pulse p-5 text-sm text-muted-foreground text-start",
			children: "טוען תוכניות אימון…"
		})
	});
}
//#endregion
export { Workouts as component };
