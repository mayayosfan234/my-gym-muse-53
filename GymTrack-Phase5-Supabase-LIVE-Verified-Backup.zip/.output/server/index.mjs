globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-08-21T02:58:59.963Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/manifest.json": {
		"type": "application/json",
		"etag": "\"1a3-Mjgn8clsjOleFrTtV+Ya/uOZhWw\"",
		"mtime": "2026-08-21T02:58:59.963Z",
		"size": 419,
		"path": "../public/manifest.json"
	},
	"/assets/ConfirmSheet-7PRBQJSq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a84-glmY/GkCzPuS/iGJAQINNTgUV6E\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 2692,
		"path": "../public/assets/ConfirmSheet-7PRBQJSq.js"
	},
	"/assets/Stepper-8P_lumwJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"675-T5HFvw8mnRCosBceDT4kh1eGz5s\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 1653,
		"path": "../public/assets/Stepper-8P_lumwJ.js"
	},
	"/assets/arrow-left-DBY1RoA7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e-9ggNudyj0TfWv0jXbZkcqYevJt0\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 158,
		"path": "../public/assets/arrow-left-DBY1RoA7.js"
	},
	"/assets/arrow-right-CYVhHAb1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e-zRgj20A/SY1dYANlqutjCltgDik\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 158,
		"path": "../public/assets/arrow-right-CYVhHAb1.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-21T02:58:59.963Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/check-Bi2RhKHQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75-6lTil8DYRA5mC4ziulo/6tkcijo\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 117,
		"path": "../public/assets/check-Bi2RhKHQ.js"
	},
	"/assets/chevron-left-D2GhjD3O.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b-7OGmobKjUynIeXPyBix6TlL4wT4\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 123,
		"path": "../public/assets/chevron-left-D2GhjD3O.js"
	},
	"/assets/AppShell-DMZk8qlw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"68a54-uU+ZpHnM+140BKObkGrKJCMW5JE\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 428628,
		"path": "../public/assets/AppShell-DMZk8qlw.js"
	},
	"/assets/exercises._exerciseId-BXn9WZ8e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38b3-NDbl+rn2zzBzXi1enOb8/pjhFzQ\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 14515,
		"path": "../public/assets/exercises._exerciseId-BXn9WZ8e.js"
	},
	"/assets/copy-Dc66pDK3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e5-IMel5SwXLJSNM2qzzARTMNygcOw\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 229,
		"path": "../public/assets/copy-Dc66pDK3.js"
	},
	"/assets/exercises._exerciseId-DLuE4YvT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36f-+w+3xfwxfuDuM4GmgU+gRFeBt2g\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 879,
		"path": "../public/assets/exercises._exerciseId-DLuE4YvT.js"
	},
	"/assets/exercises.index-BNMDC_HM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2891-1kpjXU+msb/EYF7W8o3KGi59VjE\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 10385,
		"path": "../public/assets/exercises.index-BNMDC_HM.js"
	},
	"/assets/flame-2Xm1cGJI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c0-mVTygUni3L5ImqOuEQq+E/HCC94\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 192,
		"path": "../public/assets/flame-2Xm1cGJI.js"
	},
	"/assets/grip-vertical-DTfzu41i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16c-+JdD++cy1crwDE4qyBPAg0AjyqE\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 364,
		"path": "../public/assets/grip-vertical-DTfzu41i.js"
	},
	"/assets/history-BVSx9m79.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"205f-wpy5KMTfrSTZ/h2yNNJLPJBnlYU\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 8287,
		"path": "../public/assets/history-BVSx9m79.js"
	},
	"/assets/index-_xQD0Vlq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b5b6-DTFOSunX0zRsyrFZaJbviALBcuw\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 308662,
		"path": "../public/assets/index-_xQD0Vlq.js"
	},
	"/assets/index-pE5nYxUh.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16c32-WRfK8L1g4mnBSVzFhM7gf2iUEmI\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 93234,
		"path": "../public/assets/index-pE5nYxUh.css"
	},
	"/assets/link-Cdkys2yX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8964-RATQr8BpwWHjCaPfosAlFScPdCI\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 35172,
		"path": "../public/assets/link-Cdkys2yX.js"
	},
	"/assets/nutrition.foods._foodId-Dot7Bx3L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"373-cAZleXAZn9Bp/tr9BebMyjCn5NU\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 883,
		"path": "../public/assets/nutrition.foods._foodId-Dot7Bx3L.js"
	},
	"/assets/nutrition.foods._foodId-RMsBc1Mv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19e6-8EITRX4ET8vlBmhZxYCpP8diuF8\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 6630,
		"path": "../public/assets/nutrition.foods._foodId-RMsBc1Mv.js"
	},
	"/assets/nutrition.foods.index-J7qR6Nv_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24c0-e7UqIuOxZ6UyVrNKeQBBJzmugzY\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 9408,
		"path": "../public/assets/nutrition.foods.index-J7qR6Nv_.js"
	},
	"/assets/nutrition.index-BA32r4H9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4075-t7Ira3hiIlAqNh3sL9T4PC5Bdk0\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 16501,
		"path": "../public/assets/nutrition.index-BA32r4H9.js"
	},
	"/assets/pencil-CTglH7KY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d-ZQapRTKGyKIQjsorLDoU7Q+DyRk\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 269,
		"path": "../public/assets/pencil-CTglH7KY.js"
	},
	"/assets/play-P_VZEYN7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b7-SO3MtdKME/e086hb12JKr+eFLJ8\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 183,
		"path": "../public/assets/play-P_VZEYN7.js"
	},
	"/assets/plus-Dnm8b8EY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"92-dZN1K5tpEqaBQOPWgEA4aftZwdo\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 146,
		"path": "../public/assets/plus-Dnm8b8EY.js"
	},
	"/assets/preload-helper-B32On_yT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1800-0pcNYN0eaM10LIKGJeva5Dm+qp4\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 6144,
		"path": "../public/assets/preload-helper-B32On_yT.js"
	},
	"/assets/programs._programId-DJ9IzqQd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d2f-Hq1FjgIVWb3pBYO/i2k8RUqYF54\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 7471,
		"path": "../public/assets/programs._programId-DJ9IzqQd.js"
	},
	"/assets/programs._programId-DcjdED_j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"322-PbhlNmqrjFnRuSc0J5o7Y+QN3B0\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 802,
		"path": "../public/assets/programs._programId-DcjdED_j.js"
	},
	"/assets/programs._programId._dayId-BJzMGckj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"384-pa0/CFDgvzWO3InpSRZl+/ZJAoo\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 900,
		"path": "../public/assets/programs._programId._dayId-BJzMGckj.js"
	},
	"/assets/programs.index--q18E-Dl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a45-3EHP/DEEMOPpCETW+f8fXoewcY0\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 6725,
		"path": "../public/assets/programs.index--q18E-Dl.js"
	},
	"/assets/programs._programId._dayId-xe_TW6tQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"53ed-ZpAeLqmJ0mLSig0yzOOpWBOEijo\"",
		"mtime": "2026-08-21T02:58:58.059Z",
		"size": 21485,
		"path": "../public/assets/programs._programId._dayId-xe_TW6tQ.js"
	},
	"/assets/routes-DF2pI73e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3d57-2ywNx5d2FSGuNr9lI43OO4ppkfY\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 15703,
		"path": "../public/assets/routes-DF2pI73e.js"
	},
	"/assets/save-D0Fs2SGk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-jxQLK/qlN9sQfA6hLr9cjKGewZw\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 320,
		"path": "../public/assets/save-D0Fs2SGk.js"
	},
	"/assets/search-q5c_ZZBZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a7-g1tXy4/kkJ1N9UN8n/Y6JLWTgR0\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 167,
		"path": "../public/assets/search-q5c_ZZBZ.js"
	},
	"/assets/session._workoutId-DNDSsEaI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"513c-WfAMy7kiFUeUlcVqSQ58VkI/Zjc\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 20796,
		"path": "../public/assets/session._workoutId-DNDSsEaI.js"
	},
	"/assets/session._workoutId-WoNztM4n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b0-DhDYUroegTnaNAiLFFCrMFwoZis\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 944,
		"path": "../public/assets/session._workoutId-WoNztM4n.js"
	},
	"/assets/sliders-horizontal-Cn5T5dmG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a1-4sHMf+aIQUJ8/6NSaGLoifoxNgw\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 417,
		"path": "../public/assets/sliders-horizontal-Cn5T5dmG.js"
	},
	"/assets/sortable.esm-BG7F_2py.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a654-uEtn2fqyMYxa/iTh5SYvtyS28K8\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 42580,
		"path": "../public/assets/sortable.esm-BG7F_2py.js"
	},
	"/assets/sparkles-BdihtG1m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e7-ob2+RRE8aCT/FMg8YtT2FxoA7Ns\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 487,
		"path": "../public/assets/sparkles-BdihtG1m.js"
	},
	"/assets/trash-2-DIUpAkCD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"141-YibXNqlbhDz94XJdyV6ZdH57m0A\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 321,
		"path": "../public/assets/trash-2-DIUpAkCD.js"
	},
	"/assets/useNavigate-DjOvJjbk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8-b3Fd1EEN8fzeaoUr9dpoZQACF9o\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 184,
		"path": "../public/assets/useNavigate-DjOvJjbk.js"
	},
	"/assets/utensils-B0GrCEJP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe-EJyfc+8r8iwiXPcj/GtH4mjdIGA\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 254,
		"path": "../public/assets/utensils-B0GrCEJP.js"
	},
	"/assets/workouts._workoutId-CsHZTS_Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e8-j9+hWKIcSi826NeKxioio0kMK6c\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 744,
		"path": "../public/assets/workouts._workoutId-CsHZTS_Q.js"
	},
	"/assets/workouts._workoutId-SaGidrWo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1498-Y/c1IhtQ5+CcI8ugsV12MsamH6M\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 5272,
		"path": "../public/assets/workouts._workoutId-SaGidrWo.js"
	},
	"/assets/workouts.index-t2Ly3WFj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21f-FmxVGIQ5vzTcSgIbz1W1je+CjsE\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 543,
		"path": "../public/assets/workouts.index-t2Ly3WFj.js"
	},
	"/assets/shuffle-DtA2UPKj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"178-9a9ZKNhc8RyXJh+sLY11JuafJr4\"",
		"mtime": "2026-08-21T02:58:58.063Z",
		"size": 376,
		"path": "../public/assets/shuffle-DtA2UPKj.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_jPnBRt = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_jPnBRt
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
