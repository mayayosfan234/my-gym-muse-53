globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-08-21T01:03:44.023Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/manifest.json": {
		"type": "application/json",
		"etag": "\"1a3-Mjgn8clsjOleFrTtV+Ya/uOZhWw\"",
		"mtime": "2026-08-21T01:03:44.023Z",
		"size": 419,
		"path": "../public/manifest.json"
	},
	"/assets/ConfirmSheet-sWYQh5IN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a84-cGWzOJRGMv5af7dlHRoN/qt973I\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 2692,
		"path": "../public/assets/ConfirmSheet-sWYQh5IN.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-21T01:03:44.027Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/AppShell-DsziWjwk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"687d4-xltFw0oLMVEzX3xd83qUsCsm5Cg\"",
		"mtime": "2026-08-21T01:03:40.899Z",
		"size": 427988,
		"path": "../public/assets/AppShell-DsziWjwk.js"
	},
	"/assets/Stepper-D3rQMtba.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"675-1x1VUUHivCA+4WnzLwZRFTRlzVQ\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 1653,
		"path": "../public/assets/Stepper-D3rQMtba.js"
	},
	"/assets/arrow-left-B4qxUBbJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e-ZfPSeMA4XZscNA+hDY6UaSKz/IY\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 158,
		"path": "../public/assets/arrow-left-B4qxUBbJ.js"
	},
	"/assets/arrow-right-BNlCAyKW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e-zKjuN/6E8SINtOQ02QtZbeK0a2A\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 158,
		"path": "../public/assets/arrow-right-BNlCAyKW.js"
	},
	"/assets/check-Bcbgoh1o.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75-WbrRF/RvcMTVjzh72D8WoawUcLA\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 117,
		"path": "../public/assets/check-Bcbgoh1o.js"
	},
	"/assets/chevron-left-D57uaFsV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b-yRbGafVL6DPdiwcI95bgQEngPGE\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 123,
		"path": "../public/assets/chevron-left-D57uaFsV.js"
	},
	"/assets/copy-BVI9MqCC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e5-kj9Kd3C9IbxbHWjBa9boiCeht8E\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 229,
		"path": "../public/assets/copy-BVI9MqCC.js"
	},
	"/assets/exercises._exerciseId-BzJLLvjx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38b3-tdSKmbXSDjTnmk5udAJyqaroxo8\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 14515,
		"path": "../public/assets/exercises._exerciseId-BzJLLvjx.js"
	},
	"/assets/exercises._exerciseId-CDEoZjwe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36f-yssrgsDSCtILd6JJKovswhqz8/Q\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 879,
		"path": "../public/assets/exercises._exerciseId-CDEoZjwe.js"
	},
	"/assets/exercises.index-hGt8Sgv2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2891-XKSegsVCTlVq4KzLOZE8sSLs9Ms\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 10385,
		"path": "../public/assets/exercises.index-hGt8Sgv2.js"
	},
	"/assets/flame-ig_Wg3NO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c0-fxIsnoIMUmA35R6N2wOb6QTY/P8\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 192,
		"path": "../public/assets/flame-ig_Wg3NO.js"
	},
	"/assets/grip-vertical-Cyh9yhDm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16c-PA+INeWgm2KWgkiPP/qJq/zckOY\"",
		"mtime": "2026-08-21T01:03:40.903Z",
		"size": 364,
		"path": "../public/assets/grip-vertical-Cyh9yhDm.js"
	},
	"/assets/index-DIiCVtrC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b5b6-XcSyDw7cI9ENT6RymkaZQo6wF8I\"",
		"mtime": "2026-08-21T01:03:40.899Z",
		"size": 308662,
		"path": "../public/assets/index-DIiCVtrC.js"
	},
	"/assets/index-pE5nYxUh.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16c32-WRfK8L1g4mnBSVzFhM7gf2iUEmI\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 93234,
		"path": "../public/assets/index-pE5nYxUh.css"
	},
	"/assets/history-CnKT5iPa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"205f-OINOuhZ4Ye9qDpTYgLPKutHZIC4\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 8287,
		"path": "../public/assets/history-CnKT5iPa.js"
	},
	"/assets/link-Cdkys2yX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8964-RATQr8BpwWHjCaPfosAlFScPdCI\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 35172,
		"path": "../public/assets/link-Cdkys2yX.js"
	},
	"/assets/nutrition.foods.index-7nVa_GNe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24c0-Dar/aRNDjaZ0l8oA976PdEod4VQ\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 9408,
		"path": "../public/assets/nutrition.foods.index-7nVa_GNe.js"
	},
	"/assets/nutrition.foods._foodId-CgnEOjAv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"373-zFqfRsLJB+dPvdp8ic99kGBIOLQ\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 883,
		"path": "../public/assets/nutrition.foods._foodId-CgnEOjAv.js"
	},
	"/assets/nutrition.foods._foodId-B3JAU1Hg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19e6-lwyTRQZcjEz9uVKx+aUzNEhy4OM\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 6630,
		"path": "../public/assets/nutrition.foods._foodId-B3JAU1Hg.js"
	},
	"/assets/pencil-R74SE_DC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d-VzCz8zY201cHgLunXlKR2HpotTo\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 269,
		"path": "../public/assets/pencil-R74SE_DC.js"
	},
	"/assets/nutrition.index-BHJTt0Uz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4075-qWx5U8h234hh8kaDmQExu3Xl1C0\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 16501,
		"path": "../public/assets/nutrition.index-BHJTt0Uz.js"
	},
	"/assets/play-CkI4xdhZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b7-sw0GHxhAdtwckSWSASoi62OZ+lw\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 183,
		"path": "../public/assets/play-CkI4xdhZ.js"
	},
	"/assets/plus-B_5NnKQk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"92-CnldYdhMd87xZcUmBKZrlhcXKtA\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 146,
		"path": "../public/assets/plus-B_5NnKQk.js"
	},
	"/assets/preload-helper-B32On_yT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1800-0pcNYN0eaM10LIKGJeva5Dm+qp4\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 6144,
		"path": "../public/assets/preload-helper-B32On_yT.js"
	},
	"/assets/programs._programId._dayId-CtlQ43_L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"53ed-UxpARpxRxujAb7J0zrxT+NX4U70\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 21485,
		"path": "../public/assets/programs._programId._dayId-CtlQ43_L.js"
	},
	"/assets/programs._programId._dayId-DZNugnjq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"384-G2hKggpiyCxrjzHnzPKoidGvrD0\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 900,
		"path": "../public/assets/programs._programId._dayId-DZNugnjq.js"
	},
	"/assets/programs.index-CWrig9Y5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a45-lpEQfppCD2nxeHv1V0GTM1WKWDs\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 6725,
		"path": "../public/assets/programs.index-CWrig9Y5.js"
	},
	"/assets/routes-D4ew-0p-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3d57-c+h+X3xJuUXdsxD9iW9uXgefwqk\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 15703,
		"path": "../public/assets/routes-D4ew-0p-.js"
	},
	"/assets/save-BGud6Ny2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-mO3BAFg/TYy9Uw5K1FLwqRiaGWs\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 320,
		"path": "../public/assets/save-BGud6Ny2.js"
	},
	"/assets/search-C_WKJVpb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a7-WNGsUM46P9yJ4Zt9Uhb7gCRFTfg\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 167,
		"path": "../public/assets/search-C_WKJVpb.js"
	},
	"/assets/session._workoutId-Bddim-CO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"513c-411aQl3qg8dp9JGhdbQU9XhA1Z0\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 20796,
		"path": "../public/assets/session._workoutId-Bddim-CO.js"
	},
	"/assets/session._workoutId-DO5eOUD8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b0-XqOGx56eCoZTzaLyPAcoBtBZvF0\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 944,
		"path": "../public/assets/session._workoutId-DO5eOUD8.js"
	},
	"/assets/shuffle-B2dkvhRH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"178-iJqgOGLa8Cwh7Iu+vHuN3OTRhN4\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 376,
		"path": "../public/assets/shuffle-B2dkvhRH.js"
	},
	"/assets/sliders-horizontal-zbhxbYFz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a1-iqAZEzgeWTeiIOm3v/Fovg2Dzl0\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 417,
		"path": "../public/assets/sliders-horizontal-zbhxbYFz.js"
	},
	"/assets/sortable.esm-BG7F_2py.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a654-uEtn2fqyMYxa/iTh5SYvtyS28K8\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 42580,
		"path": "../public/assets/sortable.esm-BG7F_2py.js"
	},
	"/assets/sparkles-DkDmGFqa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e7-IgLcQ4lxPTwMyegy6/T67JdGkDI\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 487,
		"path": "../public/assets/sparkles-DkDmGFqa.js"
	},
	"/assets/trash-2-DMxrb6Aq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"141-s7wzTtae8QYC6TD/tJHbY68pbWw\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 321,
		"path": "../public/assets/trash-2-DMxrb6Aq.js"
	},
	"/assets/useNavigate-DjOvJjbk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8-b3Fd1EEN8fzeaoUr9dpoZQACF9o\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 184,
		"path": "../public/assets/useNavigate-DjOvJjbk.js"
	},
	"/assets/utensils-bMp5QLCM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe-12fShWtJr1ONO4ZBp30ANIdOdIY\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 254,
		"path": "../public/assets/utensils-bMp5QLCM.js"
	},
	"/assets/workouts._workoutId-CmT4DuNo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e8-hxCO55K9uVbxYVq7GCNhzZl1khk\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 744,
		"path": "../public/assets/workouts._workoutId-CmT4DuNo.js"
	},
	"/assets/workouts._workoutId-DvvW8ask.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1498-l6wtkq2cVSALSgNL7e7BdUj12sg\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 5272,
		"path": "../public/assets/workouts._workoutId-DvvW8ask.js"
	},
	"/assets/workouts.index-WXRVcTif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21f-bm1+9YmzeIADP4jNw+lL5qn4qgA\"",
		"mtime": "2026-08-21T01:03:40.911Z",
		"size": 543,
		"path": "../public/assets/workouts.index-WXRVcTif.js"
	},
	"/assets/programs._programId-sT16_JYc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"322-6nWUI9/HsKtJc5awYRDbc+U44XE\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 802,
		"path": "../public/assets/programs._programId-sT16_JYc.js"
	},
	"/assets/programs._programId-qcVYosZ-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d2f-83SxVCLYvjkPjghp+NmFdhoRZ28\"",
		"mtime": "2026-08-21T01:03:40.907Z",
		"size": 7471,
		"path": "../public/assets/programs._programId-qcVYosZ-.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_jPnBRt = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_jPnBRt
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
