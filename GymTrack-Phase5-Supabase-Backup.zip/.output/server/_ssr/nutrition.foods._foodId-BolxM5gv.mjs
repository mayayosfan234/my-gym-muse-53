import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { G as ArrowRight, H as Check, d as Shuffle, o as Trash2, q as Apple } from "../_libs/lucide-react.mjs";
import { J as saveFood, N as findFoodReplacements, S as deleteFood, d as SecondaryButton, k as emptyFood, s as IconButton, st as useGym, t as AppShell, u as PrimaryButton } from "./AppShell-KupW-dVq.mjs";
import { t as Route } from "./nutrition.foods._foodId-DN9-e5bK.mjs";
import { t as Stepper } from "./Stepper-gj3wsFLX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nutrition.foods._foodId-BolxM5gv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var field = "w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3.5 text-[14px] outline-none focus:border-primary";
var labelCls = "mb-1.5 block text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase";
function FoodDetail() {
	const { foodId } = Route.useParams();
	const search = Route.useSearch();
	const navigate = useNavigate();
	const { foods } = useGym();
	const isNew = foodId === "new";
	const existing = foods.find((f) => f.id === foodId);
	const isLogEdit = Boolean(search.mealDate && search.mealId && search.logFoodId && !isNew);
	const [draft, setDraft] = (0, import_react.useState)(existing ?? emptyFood());
	const [swapQuery, setSwapQuery] = (0, import_react.useState)("");
	const [showSwaps, setShowSwaps] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (existing) setDraft(existing);
		else if (isNew) setDraft(emptyFood());
	}, [existing, isNew]);
	const replacements = (0, import_react.useMemo)(() => {
		if (!existing) return [];
		return findFoodReplacements(foods, existing, swapQuery).slice(0, 10);
	}, [
		foods,
		existing,
		swapQuery
	]);
	if (!isNew && !existing && foodId !== "custom") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "מאכל לא נמצא",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "מאכל זה אינו קיים עוד בספרייה."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/nutrition/foods",
			className: "mt-4 inline-block text-primary font-semibold text-start",
			children: "חזרה לספריית המאכלים"
		})]
	});
	if (foodId === "custom" && isLogEdit) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "מאכל יומן",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "מאכל זה מופיע ביומן ולא מקושר ישירות לספרייה."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/nutrition",
			className: "mt-4 inline-block text-primary font-semibold text-start",
			children: "חזרה ליומן התזונה"
		})]
	});
	const set = (patch) => setDraft({
		...draft,
		...patch
	});
	const onSave = () => {
		if (!draft.name.trim()) return;
		saveFood({
			...draft,
			name: draft.name.trim()
		});
		if (isNew) navigate({
			to: "/nutrition/foods/$foodId",
			params: { foodId: draft.id },
			replace: true
		});
		else navigate({ to: "/nutrition/foods" });
	};
	const onDelete = () => {
		if (!existing) return;
		deleteFood(existing.id);
		navigate({ to: "/nutrition/foods" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: isNew ? "מאכל חדש" : "ספריית מאכלים",
		title: isNew ? "מאכל חדש" : draft.name || "מאכל",
		subtitle: !isNew ? draft.servingSize : void 0,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/nutrition/foods",
				"aria-label": "חזרה",
				className: "press grid h-11 w-11 place-items-center rounded-2xl bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-5 w-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
				variant: "primary",
				"aria-label": "שמור",
				onClick: onSave,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
					className: "h-5 w-5",
					strokeWidth: 2.4
				})
			})]
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rose-card flex items-center gap-4 p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/70 text-rose",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Apple, {
					className: "h-6 w-6",
					strokeWidth: 1.8
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 text-start",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10.5px] font-semibold tracking-[0.16em] text-rose uppercase",
						children: "קלוריות למנה"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-[34px] font-semibold leading-none text-ink tabular-nums",
						children: Math.round(draft.calories)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[12.5px] text-muted-foreground",
						children: draft.servingSize || "מנה 1"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-3 text-start",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "שם המאכל"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: draft.name,
						onChange: (e) => set({ name: e.target.value }),
						placeholder: "שם המאכל..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "גודל מנת ייחוס"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: draft.servingSize,
						onChange: (e) => set({ servingSize: e.target.value }),
						placeholder: "100 גרם, יחידה 1, פרוסה 1..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card grid grid-cols-2 gap-3 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "קלוריות",
							value: draft.calories,
							min: 0,
							onChange: (calories) => set({ calories })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "חלבון",
							value: draft.protein,
							step: .5,
							min: 0,
							suffix: "g",
							onChange: (protein) => set({ protein })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "פחמימות",
							value: draft.carbs,
							step: .5,
							min: 0,
							suffix: "g",
							onChange: (carbs) => set({ carbs })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "שומן",
							value: draft.fat,
							step: .5,
							min: 0,
							suffix: "g",
							onChange: (fat) => set({ fat })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
								label: "סיבים תזונתיים",
								value: draft.fiber ?? 0,
								step: .5,
								min: 0,
								suffix: "g",
								onChange: (fiber) => set({ fiber })
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "הערות ומידע נוסף"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 2,
						className: field,
						value: draft.notes ?? "",
						onChange: (e) => set({ notes: e.target.value }),
						placeholder: "מידע על המותג או הערות..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: onSave,
						leading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }),
						children: "שמור מאכל בספרייה"
					}), !isNew && existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
						onClick: () => setShowSwaps((v) => !v),
						leading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "h-4 w-4" }),
						children: showSwaps ? "הסתרי הצעות להחלפה" : "הציגי מאכלים דומים"
					}) : null]
				}),
				showSwaps && existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
							children: "מאכלים דומים להחלפה"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num-pill mt-2 flex h-11 items-center gap-2 px-3.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: swapQuery,
								onChange: (e) => setSwapQuery(e.target.value),
								placeholder: "סינון מועמדים להחלפה...",
								className: "w-full bg-transparent text-[13px] outline-none"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 space-y-2",
							children: replacements.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/nutrition/foods/$foodId",
								params: { foodId: item.food.id },
								className: "press flex w-full items-center justify-between gap-3 rounded-2xl bg-secondary px-3.5 py-3 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-[14px] font-semibold text-ink",
										children: item.food.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11.5px] text-muted-foreground",
										children: [
											item.food.calories,
											" קלוריות · חלבון ",
											item.food.protein,
											"g · Δ",
											Math.abs(item.food.calories - existing.calories),
											" קלוריות"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 shrink-0 text-muted-foreground/60" })]
							}, item.food.id))
						})
					]
				}) : null,
				!isNew && existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onDelete,
					className: "press flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-secondary text-[14.5px] font-semibold text-destructive",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " מחק מאכל מהספרייה"]
				}) : null
			]
		})]
	});
}
//#endregion
export { FoodDetail as component };
