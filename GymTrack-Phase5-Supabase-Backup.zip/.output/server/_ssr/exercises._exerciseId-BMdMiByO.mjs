import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { F as Dumbbell, G as ArrowRight, H as Check, O as ImagePlus, b as Pencil, g as Save, i as Trophy, o as Trash2, t as X } from "../_libs/lucide-react.mjs";
import { F as lastPerformance, O as emptyExercise, R as personalRecords, a as EXERCISE_CATEGORIES, c as MUSCLE_GROUPS, i as EQUIPMENT, q as saveExercise, st as useGym, t as AppShell, u as PrimaryButton, x as deleteExercise } from "./AppShell-KupW-dVq.mjs";
import { t as Route } from "./exercises._exerciseId-CZ3-TuHE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exercises._exerciseId-BMdMiByO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var field = "w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3.5 text-[14px] outline-none focus:border-primary";
var labelCls = "mb-1.5 block text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase";
function ExerciseDetail() {
	const { exerciseId } = Route.useParams();
	const navigate = useNavigate();
	const { exercises, history } = useGym();
	const isNew = exerciseId === "new";
	const existing = exercises.find((e) => e.id === exerciseId);
	const [editing, setEditing] = (0, import_react.useState)(isNew);
	const [draft, setDraft] = (0, import_react.useState)(existing ?? emptyExercise());
	const [customMuscle, setCustomMuscle] = (0, import_react.useState)(() => existing?.customMuscleGroup || (existing && !MUSCLE_GROUPS.includes(existing.muscleGroup) ? existing.muscleGroup : "") || "");
	if (!isNew && !existing) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "תרגיל לא נמצא",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "תרגיל זה אינו קיים עוד בספרייה."
		})
	});
	const ex = existing ?? draft;
	const last = lastPerformance(history, ex.id);
	const pr = personalRecords(history, ex.id);
	const toggleMuscleGroup = (m) => {
		setDraft((d) => {
			const current = d.muscleGroups ?? [d.muscleGroup];
			const updated = current.includes(m) ? current.filter((x) => x !== m) : [...current, m];
			return {
				...d,
				muscleGroup: updated[0] ?? m,
				muscleGroups: updated
			};
		});
	};
	const toggleSecondary = (m) => setDraft((d) => {
		const current = d.secondaryMuscles ?? [];
		return {
			...d,
			secondaryMuscles: current.includes(m) ? current.filter((x) => x !== m) : [...current, m]
		};
	});
	const set = (patch) => setDraft({
		...draft,
		...patch
	});
	const onSave = () => {
		const isOther = draft.muscleGroup === "אחר" || (draft.muscleGroups ?? []).includes("אחר");
		const customValue = isOther ? customMuscle.trim() : void 0;
		const finalMuscleGroup = isOther && customValue ? customValue : draft.muscleGroup;
		if (!draft.name.trim() || !finalMuscleGroup) return;
		saveExercise({
			...draft,
			muscleGroup: finalMuscleGroup,
			customMuscleGroup: customValue
		});
		if (isNew) navigate({
			to: "/exercises/$exerciseId",
			params: { exerciseId: draft.id }
		});
		else setEditing(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		kicker: isNew ? "תרגיל חדש" : editing ? "עריכה" : "ספריית תרגילים",
		title: isNew ? "תרגיל חדש" : editing ? ex.name || "עריכת תרגיל" : ex.name,
		subtitle: !editing && !isNew ? `${ex.customMuscleGroup || ex.muscleGroup} · ${ex.equipment}` : void 0,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/exercises",
				"aria-label": "חזרה",
				className: "press grid h-11 w-11 place-items-center rounded-2xl bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-5 w-5" })
			}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onSave,
				"aria-label": "שמור",
				className: "press grid h-11 w-11 place-items-center rounded-2xl bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
					className: "h-5 w-5",
					strokeWidth: 2.4
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					setDraft(ex);
					setEditing(true);
				},
				"aria-label": "ערוך",
				className: "press grid h-11 w-11 place-items-center rounded-2xl bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
					className: "h-4 w-4",
					strokeWidth: 2.2
				})
			})]
		}),
		children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 text-start",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "שם התרגיל"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: draft.name,
						onChange: (e) => set({ name: e.target.value }),
						placeholder: "למשל: לחיצת חזה בשיפוע חיובי"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card space-y-4 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: labelCls,
							children: "קבוצת שרירים ראשית"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-1.5",
							children: [...MUSCLE_GROUPS, "אחר"].map((g) => {
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => set({ muscleGroup: g }),
									className: `press rounded-full px-3 py-1.5 text-[12.5px] font-semibold transition-colors ${(g === "אחר" ? !MUSCLE_GROUPS.includes(draft.muscleGroup) || draft.muscleGroup === "אחר" : draft.muscleGroup === g) ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`,
									children: g
								}, g);
							})
						}),
						draft.muscleGroup === "אחר" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${field} mt-2`,
							value: customMuscle,
							onChange: (e) => setCustomMuscle(e.target.value),
							placeholder: "הקלד קבוצת שרירים"
						}) : null
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "ציוד"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-1.5",
						children: EQUIPMENT.map((g) => {
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => set({ equipment: g }),
								className: `press rounded-full px-3 py-1.5 text-[12.5px] font-semibold transition-colors ${draft.equipment === g ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`,
								children: g
							}, g);
						})
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "קטגוריה"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => set({ category: "" }),
							className: `press rounded-full px-3 py-1.5 text-[12.5px] font-semibold transition-colors ${!draft.category ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`,
							children: "— ללא —"
						}, "none"), EXERCISE_CATEGORIES.map((c) => {
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => set({ category: c }),
								className: `press rounded-full px-3 py-1.5 text-[12.5px] font-semibold transition-colors ${draft.category === c ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`,
								children: c
							}, c);
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: labelCls,
							children: "קבוצות שרירים עובדות"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11.5px] text-muted-foreground",
							children: "בחרי את כל קבוצות השרירים שהתרגיל מעסיק."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-1.5",
							children: MUSCLE_GROUPS.map((m) => {
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => toggleMuscleGroup(m),
									className: `press rounded-full px-3 py-1.5 text-[12px] font-semibold transition-colors ${(draft.muscleGroups ?? [draft.muscleGroup]).includes(m) ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`,
									children: m
								}, m);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "שרירים משניים (עוזרים)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-1.5",
						children: MUSCLE_GROUPS.map((m) => {
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggleSecondary(m),
								className: `press rounded-full px-3 py-1.5 text-[12px] font-semibold transition-colors ${(draft.secondaryMuscles ?? []).includes(m) ? "bg-rose text-primary-foreground" : "bg-secondary text-muted-foreground"}`,
								children: m
							}, m);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "תיאור התרגיל"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 3,
						className: field,
						value: draft.description,
						onChange: (e) => set({ description: e.target.value }),
						placeholder: "תיאור קצר על התרגיל..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "הוראות ביצוע"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 3,
						className: field,
						value: draft.instructions ?? "",
						onChange: (e) => set({ instructions: e.target.value }),
						placeholder: "1. אחוז במוט ברוחב כתפיים..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "דגשי טכניקה וטיפים"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 2,
						className: field,
						value: draft.tips ?? "",
						onChange: (e) => set({ tips: e.target.value }),
						placeholder: "למשל: לשמור על מרפקים בזווית 45 מעלות"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "קישור לסרטון הדגמה"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: draft.videoUrl,
						onChange: (e) => set({ videoUrl: e.target.value }),
						placeholder: "https://youtube.com/..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagesEditor, {
					images: draft.images,
					onChange: (images) => set({ images })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: labelCls,
						children: "הערות אישיות"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 3,
						className: field,
						value: draft.notes,
						onChange: (e) => set({ notes: e.target.value }),
						placeholder: "הערות אישיות לגבי התרגיל..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: onSave,
						leading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4" }),
						children: "שמור תרגיל"
					}), !isNew ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							deleteExercise(ex.id);
							navigate({ to: "/exercises" });
						},
						className: "press flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-secondary text-[14.5px] font-semibold text-destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " מחק תרגיל"]
					}) : null]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 text-start",
			children: [
				ex.images.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "-mx-5 flex gap-3 overflow-x-auto px-5 pb-1 no-scrollbar",
					children: ex.images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: `${ex.name} ${i + 1}`,
						loading: "lazy",
						className: "h-44 w-64 shrink-0 rounded-2xl border border-border/40 object-cover"
					}, i))
				}) : null,
				ex.videoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: ex.videoUrl,
					target: "_blank",
					rel: "noreferrer",
					className: "press surface-card flex items-center justify-between gap-3 p-4 text-[14px] font-semibold text-primary",
					children: ["צפי בסרטון הדגמה לתרגיל", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: labelCls,
							children: "מאפיינים"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "num-pill px-3 py-1.5 text-[12px] font-semibold text-ink",
									children: ex.equipment
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "num-pill px-3 py-1.5 text-[12px] font-semibold text-ink",
									children: ex.customMuscleGroup || ex.muscleGroup
								}),
								ex.category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "num-pill px-3 py-1.5 text-[12px] font-semibold text-ink",
									children: ex.category
								}) : null
							]
						}),
						(ex.secondaryMuscles ?? []).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: labelCls,
								children: "שרירים משניים עובדים"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-1.5",
								children: ex.secondaryMuscles.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-secondary px-3 py-1 text-[12px] font-medium text-muted-foreground",
									children: m
								}, m))
							})]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "תיאור התרגיל",
					children: ex.description || "אין תיאור לתרגיל זה."
				}),
				ex.instructions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "הוראות ביצוע",
					children: ex.instructions
				}) : null,
				ex.tips ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "דגשים וטיפים",
					children: ex.tips
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "הערות אישיות",
					children: ex.notes || "אין הערות אישיות."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-4 w-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1.5 block text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase m-0",
							children: "שיאים אישיים"
						})]
					}), pr ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "num-pill p-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-[20px] font-bold tabular-nums text-ink",
									children: pr.heaviest
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-[10.5px] leading-tight text-muted-foreground",
									children: "משקל שיא (ק״ג)"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "num-pill p-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-[20px] font-bold tabular-nums text-ink",
									children: pr.bestRepsAtHeaviest
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-[10.5px] leading-tight text-muted-foreground",
									children: "חזרות בשיא"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "num-pill p-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-[20px] font-bold tabular-nums text-ink",
									children: pr.estimatedMax
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-[10.5px] leading-tight text-muted-foreground",
									children: "1RM משוער"
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12.5px] text-muted-foreground",
						children: "עדיין לא נרשמו שיאים לתרגיל זה."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, { className: "h-4 w-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1.5 block text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase m-0",
							children: "ביצוע אחרון"
						})]
					}), last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-[12px] text-muted-foreground",
						children: new Date(last.date).toLocaleDateString("he-IL")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						dir: "ltr",
						children: last.sets.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "num-pill px-3 py-1.5 text-[12px] font-semibold tabular-nums text-ink",
							children: [
								s.weight,
								"kg × ",
								s.reps
							]
						}, i))
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12.5px] text-muted-foreground",
						children: "תרגיל זה טרם בוצע באימון פעיל."
					})]
				})
			]
		})
	});
}
function Panel({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card p-4 text-start",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: labelCls,
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1.5 whitespace-pre-wrap text-[13.5px] leading-relaxed text-ink",
			children
		})]
	});
}
function ImagesEditor({ images, onChange }) {
	const [url, setUrl] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card p-4 text-start",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: labelCls,
				children: "תמונות תרגיל"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: field,
					value: url,
					onChange: (e) => setUrl(e.target.value),
					placeholder: "קישור לתמונה (URL)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "הוסף תמונה",
					onClick: () => {
						if (!url.trim()) return;
						onChange([...images, url.trim()]);
						setUrl("");
					},
					className: "press grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-5 w-5" })
				})]
			}),
			images.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: `תמונת תרגיל ${i + 1}`,
						className: "h-20 w-20 rounded-xl border border-border/40 object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "הסר תמונה",
						onClick: () => onChange(images.filter((_, j) => j !== i)),
						className: "press absolute -end-2 -top-2 grid h-7 w-7 place-items-center rounded-full bg-destructive text-destructive-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
					})]
				}, i))
			}) : null
		]
	});
}
//#endregion
export { ExerciseDetail as component };
