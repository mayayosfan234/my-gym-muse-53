import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { B as ChevronLeft, F as Dumbbell, N as Footprints, P as Flame, a as TrendingUp, n as Utensils, v as Plus, y as Play } from "../_libs/lucide-react.mjs";
import { Q as saveUserProfile, U as saveBodyWeight, W as saveCardioLog, _ as calculateRmr, f as SectionHeader, g as calculateCardioCalories, n as CARDIO_TYPES, p as StatTile, r as Card, rt as todayKey, st as useGym, t as AppShell, u as PrimaryButton, y as dayTotals } from "./AppShell-KupW-dVq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BVNAXxdH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatHebrewDate(date) {
	return date.toLocaleDateString("he-IL", {
		weekday: "long",
		day: "numeric",
		month: "long"
	});
}
function Dashboard() {
	const navigate = useNavigate();
	const { workouts, exercises, history, programs, nutritionDays, userProfile, cardioLogs } = useGym();
	const now = /* @__PURE__ */ new Date();
	const startOfWeek = new Date(now);
	const dow = (now.getDay() + 6) % 7;
	startOfWeek.setDate(now.getDate() - dow);
	startOfWeek.setHours(0, 0, 0, 0);
	const thisWeek = history.filter((s) => new Date(s.date) >= startOfWeek);
	const volume = thisWeek.reduce((sum, s) => sum + s.entries.reduce((v, e) => v + e.sets.filter((x) => x.done).reduce((a, b) => a + b.reps * b.weight, 0), 0), 0);
	const totalDurationMin = Math.round(thisWeek.reduce((sum, s) => sum + (s.durationSec || 0), 0) / 60);
	const todayDateStr = todayKey();
	const nutritionToday = nutritionDays.find((d) => d.date === todayDateStr);
	const totalsToday = nutritionToday ? dayTotals(nutritionToday) : {
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0,
		fiber: 0
	};
	const targetCals = 2e3;
	const remainingCals = Math.max(0, targetCals - totalsToday.calories);
	const [activeSession, setActiveSession] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		try {
			for (const w of workouts) if (localStorage.getItem(`gymtrack.active_session.${w.id}`)) {
				setActiveSession({
					id: w.id,
					name: w.name
				});
				break;
			}
		} catch {}
	}, [workouts]);
	const rmrData = calculateRmr(userProfile);
	const [weightInput, setWeightInput] = (0, import_react.useState)(String(userProfile?.weight ?? 65));
	const [workoutsWeekInput, setWorkoutsWeekInput] = (0, import_react.useState)(String(userProfile?.workoutsPerWeek ?? 4));
	const [showBodyModal, setShowBodyModal] = (0, import_react.useState)(false);
	const [showCardioModal, setShowCardioModal] = (0, import_react.useState)(false);
	const [cardioType, setCardioType] = (0, import_react.useState)(CARDIO_TYPES[0]);
	const [cardioDuration, setCardioDuration] = (0, import_react.useState)("20");
	const [cardioSpeed, setCardioSpeed] = (0, import_react.useState)("8.0");
	const [cardioIncline, setCardioIncline] = (0, import_react.useState)("2.0");
	const nextWorkout = workouts[0];
	const nextProgram = nextWorkout ? programs.find((p) => p.dayIds.includes(nextWorkout.id)) : void 0;
	const handleProfileSave = () => {
		const valW = parseFloat(weightInput);
		const valFreq = parseInt(workoutsWeekInput, 10) || 4;
		const w = !isNaN(valW) && valW > 0 ? valW : userProfile?.weight ?? 65;
		saveBodyWeight(w);
		saveUserProfile({
			...userProfile ?? {
				weight: 65,
				height: 165,
				age: 26,
				gender: "female"
			},
			weight: w,
			workoutsPerWeek: valFreq
		});
		setShowBodyModal(false);
	};
	const handleLogCardio = () => {
		const dur = parseInt(cardioDuration, 10) || 0;
		const spd = parseFloat(cardioSpeed) || 0;
		const inc = parseFloat(cardioIncline) || 0;
		const cals = calculateCardioCalories(cardioType, dur, rmrData.weight, spd, inc);
		saveCardioLog({
			date: todayDateStr,
			type: cardioType,
			durationMin: dur,
			speed: spd,
			incline: inc,
			calories: cals
		});
		setShowCardioModal(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: formatHebrewDate(now),
		subtitle: "אימונים ותזונה",
		children: [
			activeSession ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rose-card mb-4 flex items-center justify-between p-4 border-2 border-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-primary text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-5 w-5 fill-current" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 text-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-bold tracking-wider text-primary uppercase",
							children: "🏋️ אימון פעיל בביצוע"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-display text-[16px] font-bold text-ink",
							children: activeSession.name
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => navigate({
						to: "/session/$workoutId",
						params: { workoutId: activeSession.id }
					}),
					className: "press shrink-0 rounded-2xl bg-primary px-4 py-2 text-[13px] font-bold text-primary-foreground shadow-md",
					children: "המשיכי אימון"
				})]
			}) : null,
			nextWorkout ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ink-card p-5 text-start",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-white/20 px-3 py-1 text-[11px] font-bold text-primary-foreground uppercase",
							children: "האימון הבא"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[12px] text-primary-foreground/80 font-medium",
							children: [
								"~",
								nextWorkout.items.length * 12 + 15,
								" דקות"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-[22px] font-bold leading-tight text-primary-foreground",
						children: nextWorkout.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-[13px] text-primary-foreground/80",
						children: [
							nextProgram?.name ?? "תכנית אימונים",
							" · ",
							nextWorkout.items.length,
							" תרגילים"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => navigate({
								to: "/session/$workoutId",
								params: { workoutId: nextWorkout.id }
							}),
							className: "press inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-2xl bg-white px-4 text-[14px] font-bold text-ink shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 fill-current text-primary" }), "התחל אימון עכשיו"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/programs/$programId/$dayId",
							params: {
								programId: nextProgram?.id ?? "p-default",
								dayId: nextWorkout.id
							},
							className: "press grid h-11 w-11 place-items-center rounded-2xl bg-white/15 text-primary-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "text-start",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-[16px] font-bold text-ink",
						children: "אין תכניות אימון עדיין"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[13px] text-muted-foreground",
						children: "צרי תכנית אימונים ראשונה כדי להתחיל להתאמן בחדר כושר."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/programs",
						className: "press mt-3 inline-flex h-10 items-center justify-center gap-2 rounded-2xl bg-primary px-4 text-[13px] font-bold text-primary-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " צרי תכנית"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "פעילות השבוע",
					subtitle: `${thisWeek.length} אימונים בוצעו השבוע`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "אימונים",
							value: String(thisWeek.length),
							icon: Flame,
							tone: "rose"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "נפח ק״ג",
							value: volume >= 1e3 ? `${(volume / 1e3).toFixed(1)}k` : String(Math.round(volume)),
							icon: TrendingUp,
							tone: "sage"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "זמן אימון",
							value: `${totalDurationMin}m`,
							icon: Dumbbell,
							tone: "cream"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "תזונה להיום",
					subtitle: `נותרו עוד ${remainingCals} קלוריות`,
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/nutrition",
						className: "press rounded-full bg-secondary px-3 py-1.5 text-[12px] font-bold text-primary",
						children: "פתחי יומן"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rose-card p-4 text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-bold tracking-wider text-primary uppercase",
							children: "קלוריות שנצרכו"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 font-display text-[28px] font-bold tabular-nums text-ink",
							children: [
								Math.round(totalsToday.calories),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[14px] font-normal text-muted-foreground",
									children: ["/ ", targetCals]
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-12 w-12 place-items-center rounded-2xl bg-white/80 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Utensils, { className: "h-5 w-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-white/80 p-2.5 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-muted-foreground uppercase",
									children: "חלבון"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-[15px] font-bold tabular-nums text-ink",
									children: [Math.round(totalsToday.protein), "g"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-white/80 p-2.5 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-muted-foreground uppercase",
									children: "פחמימות"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-[15px] font-bold tabular-nums text-ink",
									children: [Math.round(totalsToday.carbs), "g"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-white/80 p-2.5 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-muted-foreground uppercase",
									children: "שומן"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-[15px] font-bold tabular-nums text-ink",
									children: [Math.round(totalsToday.fat), "g"]
								})]
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "נתוני גוף וחילוף חומרים",
					subtitle: "חישוב RMR והוצאה קלורית יומית",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowBodyModal(true),
						className: "press rounded-full bg-secondary px-3 py-1.5 text-[12px] font-bold text-primary",
						children: "עדכני נתונים"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-4 text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "num-pill p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10.5px] font-bold text-muted-foreground uppercase",
									children: "משקל גוף"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-display text-[20px] font-bold tabular-nums text-ink",
									children: [
										rmrData.weight,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[12px] font-normal",
											children: "ק״ג"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "num-pill p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10.5px] font-bold text-muted-foreground uppercase",
									children: "RMR (מנוחה)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-display text-[20px] font-bold tabular-nums text-ink",
									children: [
										rmrData.rmr,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[12px] font-normal",
											children: "קל׳"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "num-pill p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10.5px] font-bold text-muted-foreground uppercase",
									children: "יומי (TDEE)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-display text-[20px] font-bold tabular-nums text-primary",
									children: [
										rmrData.tdee,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[12px] font-normal",
											children: "קל׳"
										})
									]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2.5 text-[11.5px] text-muted-foreground",
						children: [
							"* RMR מציג את השריפה הקלורית של הגוף במנוחה מוחלטת. הוצאה יומית (TDEE) מחושבת לפי ",
							userProfile?.workoutsPerWeek ?? 4,
							" אימונים בשבוע."
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "אימון אירובי (אירובי / הליכון)",
					subtitle: "תיעוד הליכה, ריצה או מכשירים",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setShowCardioModal(true),
						className: "press inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1.5 text-[12px] font-bold text-primary-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3.5 w-3.5" }), " אירובי חדש"]
					})
				}), cardioLogs && cardioLogs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: cardioLogs.slice(0, 2).map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-card flex items-center justify-between p-3.5 text-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-xl bg-secondary text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footprints, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-[14.5px] font-bold text-ink",
								children: log.type
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[12px] text-muted-foreground",
								children: [
									log.durationMin,
									" דק׳ ",
									log.speed ? `· ${log.speed} קמ״ש` : "",
									log.incline ? ` · שיפוע ${log.incline}%` : ""
								]
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "num-pill px-2.5 py-1 text-[12px] font-bold text-primary",
							children: [
								"~",
								log.calories,
								" קלוריות"
							]
						})]
					}, log.id))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "text-start",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] text-muted-foreground",
						children: "עדיין לא תועד אימון אירובי היום. לחצי על \"אירובי חדש\" להוספת הליכון או ריצה."
					})
				})]
			}),
			showBodyModal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm p-4 pb-24",
				onClick: () => setShowBodyModal(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (el) => {
						if (el) el.scrollTop = 0;
					},
					className: "scale-in w-full max-w-lg rounded-3xl border border-border bg-card p-5 text-start shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-bold tracking-wider text-primary uppercase",
							children: "עדכון נתוני גוף ופעילות"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-[20px] font-bold text-ink",
							children: "עדכני משקל ומספר אימונים"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[12px] font-bold text-muted-foreground",
								children: "משקל (בק״ג)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								step: "0.1",
								value: weightInput,
								onChange: (e) => setWeightInput(e.target.value),
								className: "mt-1 w-full rounded-2xl border border-border bg-secondary px-4 py-3 text-[17px] font-bold text-ink outline-none focus:border-primary"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[12px] font-bold text-muted-foreground",
								children: "אימונים בשבוע"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: "0",
								max: "14",
								value: workoutsWeekInput,
								onChange: (e) => setWorkoutsWeekInput(e.target.value),
								className: "mt-1 w-full rounded-2xl border border-border bg-secondary px-4 py-3 text-[17px] font-bold text-ink outline-none focus:border-primary"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 flex gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								onClick: handleProfileSave,
								children: "שמרי נתונים"
							})
						})
					]
				})
			}) : null,
			showCardioModal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm p-4 pb-24",
				onClick: () => setShowCardioModal(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (el) => {
						if (el) el.scrollTop = 0;
					},
					className: "scale-in max-h-[80dvh] w-full max-w-lg overflow-y-auto rounded-3xl border border-border bg-card p-5 text-start shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-bold tracking-wider text-primary uppercase",
							children: "תיעוד אירובי"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-[20px] font-bold text-ink",
							children: "הוסיפי פעילות אירובית"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[12px] font-bold text-muted-foreground",
									children: "סוג הפעילות"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: cardioType,
									onChange: (e) => setCardioType(e.target.value),
									className: "mt-1 w-full rounded-2xl border border-border bg-secondary px-3.5 py-3 text-[14.5px] font-bold text-ink outline-none",
									children: CARDIO_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: t,
										children: t
									}, t))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[12px] font-bold text-muted-foreground",
										children: "זמן (בדקות)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										value: cardioDuration,
										onChange: (e) => setCardioDuration(e.target.value),
										className: "mt-1 w-full rounded-2xl border border-border bg-secondary px-3.5 py-2.5 text-[15px] font-bold text-ink outline-none"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[12px] font-bold text-muted-foreground",
										children: "מהירות (קמ״ש)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										step: "0.5",
										value: cardioSpeed,
										onChange: (e) => setCardioSpeed(e.target.value),
										className: "mt-1 w-full rounded-2xl border border-border bg-secondary px-3.5 py-2.5 text-[15px] font-bold text-ink outline-none"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[12px] font-bold text-muted-foreground",
									children: "שיפוע הליכון (%)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									step: "0.5",
									value: cardioIncline,
									onChange: (e) => setCardioIncline(e.target.value),
									className: "mt-1 w-full rounded-2xl border border-border bg-secondary px-3.5 py-2.5 text-[15px] font-bold text-ink outline-none"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl bg-secondary p-3 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] font-bold text-muted-foreground",
										children: "הערכת שריפה קלורית"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-0.5 font-display text-[22px] font-bold tabular-nums text-primary",
										children: [
											"~",
											calculateCardioCalories(cardioType, parseInt(cardioDuration, 10) || 0, rmrData.weight, parseFloat(cardioSpeed) || 0, parseFloat(cardioIncline) || 0),
											" ",
											"קלוריות"
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 flex gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								onClick: handleLogCardio,
								children: "שמרי אימון אירובי"
							})
						})
					]
				})
			}) : null
		]
	});
}
//#endregion
export { Dashboard as component };
