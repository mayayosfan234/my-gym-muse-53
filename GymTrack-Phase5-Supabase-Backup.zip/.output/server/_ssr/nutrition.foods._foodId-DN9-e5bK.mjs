import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nutrition.foods._foodId-DN9-e5bK.js
var $$splitComponentImporter = () => import("./nutrition.foods._foodId-BolxM5gv.mjs");
var Route = createFileRoute("/nutrition/foods/$foodId")({
	head: () => ({ meta: [{ title: "פרטי מאכל — הרוטינה שלי" }] }),
	validateSearch: (search) => ({
		mealDate: typeof search.mealDate === "string" ? search.mealDate : void 0,
		mealId: typeof search.mealId === "string" ? search.mealId : void 0,
		logFoodId: typeof search.logFoodId === "string" ? search.logFoodId : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
