import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as History, E as Layers, F as Dumbbell, J as Activity, h as Scale, o as Trash2 } from "../_libs/lucide-react.mjs";
import { o as EmptyState, p as StatTile, st as useGym, t as AppShell, w as deleteSession } from "./AppShell-KupW-dVq.mjs";
import { t as ConfirmSheet } from "./ConfirmSheet-BxxjdNfI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/history-C_hYtRrQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatRelativeDate(dateIso) {
	const date = new Date(dateIso);
	const diffTime = Math.abs((/* @__PURE__ */ new Date()).getTime() - date.getTime());
	const diffDays = Math.floor(diffTime / (1e3 * 60 * 60 * 24));
	if (diffDays === 0) return "היום";
	if (diffDays === 1) return "אתמול";
	if (diffDays === 2) return "לפני יומיים";
	if (diffDays <= 6) return `לפני ${diffDays} ימים`;
	if (diffDays <= 30) return "החודש";
	return date.toLocaleDateString("he-IL");
}
function HistoryPage() {
	const { history, cardioLogs, bodyWeightLogs } = useGym();
	const [activeTab, setActiveTab] = (0, import_react.useState)("workouts");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const totalSets = history.reduce((v, s) => v + s.entries.reduce((acc, e) => acc + e.sets.filter((x) => !x.warmup).length, 0), 0);
	const totalVolume = history.reduce((v, s) => v + s.entries.reduce((acc, e) => acc + e.sets.filter((x) => !x.warmup).reduce((a, b) => a + b.reps * b.weight, 0), 0), 0);
	const totalCardioMinutes = (cardioLogs ?? []).reduce((acc, c) => acc + c.durationMin, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: "היסטוריה",
		title: "תיעוד ופעילות",
		subtitle: `${history.length} אימונים תועדו`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "סטים",
						value: String(totalSets),
						icon: Layers,
						tone: "sage"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "נפח ק״ג",
						value: totalVolume >= 1e3 ? `${(totalVolume / 1e3).toFixed(1)}k` : String(Math.round(totalVolume)),
						icon: Dumbbell,
						tone: "rose"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "אירובי",
						value: `${totalCardioMinutes}m`,
						icon: Activity,
						tone: "cream"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex gap-1 rounded-2xl bg-secondary p-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setActiveTab("workouts"),
						className: `press flex-1 rounded-xl py-2.5 text-[13px] font-bold transition-colors ${activeTab === "workouts" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-ink"}`,
						children: [
							"אימוני כוח (",
							history.length,
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setActiveTab("cardio"),
						className: `press flex-1 rounded-xl py-2.5 text-[13px] font-bold transition-colors ${activeTab === "cardio" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-ink"}`,
						children: [
							"אירובי (",
							(cardioLogs ?? []).length,
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setActiveTab("weight"),
						className: `press flex-1 rounded-xl py-2.5 text-[13px] font-bold transition-colors ${activeTab === "weight" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-ink"}`,
						children: [
							"משקל גוף (",
							(bodyWeightLogs ?? []).length,
							")"
						]
					})
				]
			}),
			activeTab === "workouts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 space-y-3",
				children: [history.map((s) => {
					const volume = s.entries.reduce((v, e) => v + e.sets.filter((set) => !set.warmup).reduce((a, b) => a + b.reps * b.weight, 0), 0);
					const workingSets = s.entries.reduce((acc, e) => acc + e.sets.filter((x) => !x.warmup).length, 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "surface-card p-4 text-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-sage-soft text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, {
										className: "h-5 w-5",
										strokeWidth: 1.8
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate font-display text-[15.5px] font-semibold text-ink",
											children: s.workoutName
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-0.5 text-[12px] text-muted-foreground",
											children: [
												s.programName ? `${s.programName} · ` : "",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-semibold text-primary",
													children: formatRelativeDate(s.date)
												}),
												" ",
												"· ",
												new Date(s.date).toLocaleDateString("he-IL")
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex flex-wrap gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "num-pill px-2.5 py-1 text-[11px] font-medium text-ink",
													children: [workingSets, " סטים"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "num-pill px-2.5 py-1 text-[11px] font-medium text-ink",
													children: [Math.round(s.durationSec / 60), " דקות"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "num-pill px-2.5 py-1 text-[11px] font-semibold text-primary",
													children: [Math.round(volume), " ק״ג"]
												})
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "מחק אימון מההיסטוריה",
									onClick: () => setPendingDelete({
										id: s.id,
										name: s.workoutName
									}),
									className: "press grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-muted-foreground hover:bg-secondary hover:text-destructive",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 space-y-3 border-t border-border/40 pt-3",
							children: s.entries.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[13.5px] font-semibold text-ink",
								children: e.exerciseName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1.5 flex flex-wrap gap-1.5",
								dir: "ltr",
								children: e.sets.map((set, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `num-pill px-2.5 py-1 text-[11.5px] font-semibold tabular-nums ${set.dropSet ? "bg-primary/15 text-primary border-primary/30" : "text-ink"}`,
									children: [
										set.weight,
										"kg × ",
										set.reps,
										set.drops && set.drops.length > 0 ? set.drops.map((d) => ` → ${d.weight}kg × ${d.reps}`).join("") : set.dropSet ? " (Drop)" : ""
									]
								}, j))
							})] }, i))
						})]
					}, s.id);
				}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: History,
					title: "עדיין לא נרשמו אימונים",
					description: "התחילי אימון ראשון ולחצי על \"סיים ושמור אימון\" כדי לראות אותו כאן."
				}) : null]
			}) : null,
			activeTab === "cardio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 space-y-3",
				children: [(cardioLogs ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
					className: "surface-card p-4 text-start",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-rose-soft text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-5 w-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-[15.5px] font-semibold text-ink",
									children: c.type
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[12px] text-muted-foreground",
									children: [
										c.date,
										" · ",
										c.durationMin,
										" דקות ",
										c.speedKmH ? `· ${c.speedKmH} קמ״ש` : "",
										c.inclinePct ? ` · שיפוע ${c.inclinePct}%` : ""
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "num-pill px-3 py-1.5 text-[13px] font-bold text-primary",
								children: [c.caloriesBurned, " קל׳"]
							})
						]
					})
				}, c.id)), (cardioLogs ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Activity,
					title: "אין אימוני אירובי מתועדים",
					description: "תוכלי לתעד אירובי (ריצה/הליכון) בלחיצה על כפתור 'אירובי' במסך הבית."
				}) : null]
			}) : null,
			activeTab === "weight" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 space-y-3",
				children: [(bodyWeightLogs ?? []).map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "surface-card p-4 text-start flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-sage-soft text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-[15px] font-semibold text-ink",
							children: w.date
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-muted-foreground",
							children: "שקילת גוף"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-[20px] font-bold text-primary tabular-nums",
						children: [
							w.weight,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[12px] font-normal text-muted-foreground",
								children: "ק״ג"
							})
						]
					})]
				}, w.id)), (bodyWeightLogs ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Scale,
					title: "אין שקילות מתועדות",
					description: "לחצי על תיעוד משקל במסך הבית כדי לעקוב אחר ההתקדמות שלך."
				}) : null]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				open: pendingDelete !== null,
				title: "למחוק את האימון מההיסטוריה?",
				description: pendingDelete ? `הפעולה תמחק את "${pendingDelete.name}" מההיסטוריה. לא ניתן לשחזר.` : void 0,
				confirmLabel: "מחק אימון",
				cancelLabel: "חזרה",
				destructive: true,
				onConfirm: () => {
					if (pendingDelete) deleteSession(pendingDelete.id);
					setPendingDelete(null);
				},
				onCancel: () => setPendingDelete(null)
			})
		]
	});
}
//#endregion
export { HistoryPage as component };
