import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session._workoutId-fWJSfCbU.js
var $$splitComponentImporter = () => import("./session._workoutId-BTpdo02q.mjs");
var Route = createFileRoute("/session/$workoutId")({
	head: () => ({ meta: [
		{ title: "אימון פעיל — הרוטינה שלי" },
		{
			name: "description",
			content: "רשמי סטים, משקלים וחזרות בזמן אמת במהלך האימון."
		},
		{
			property: "og:title",
			content: "אימון פעיל — הרוטינה שלי"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
