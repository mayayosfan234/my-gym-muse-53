import { n as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { F as Dumbbell, I as Copy, K as ArrowLeft, U as Calendar, c as Sparkles, o as Trash2, t as X, v as Plus } from "../_libs/lucide-react.mjs";
import { C as deleteProgram, E as duplicateProgram, d as SecondaryButton, f as SectionHeader, l as Pill, o as EmptyState, s as IconButton, st as useGym, t as AppShell, u as PrimaryButton, v as createProgram } from "./AppShell-KupW-dVq.mjs";
import { t as ConfirmSheet } from "./ConfirmSheet-BxxjdNfI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/programs.index-CRb6YTh7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProgramsPage() {
	const { programs, workouts } = useGym();
	const navigate = useNavigate();
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const submit = () => {
		const value = name.trim();
		if (!value) return;
		const program = createProgram(value);
		setName("");
		setAdding(false);
		navigate({
			to: "/programs/$programId",
			params: { programId: program.id }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: "תוכניות",
		title: "תוכניות אימון",
		subtitle: "בני תכניות שמתאימות בדיוק למטרות שלך",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
			variant: "primary",
			"aria-label": "תכנית חדשה",
			onClick: () => setAdding((value) => !value),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
				className: "h-5 w-5",
				strokeWidth: 2.4
			})
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "ink-card-soft relative overflow-hidden p-5 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 max-w-sm text-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
								className: "h-3.5 w-3.5 text-primary",
								strokeWidth: 2.2
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10.5px] font-bold tracking-[0.16em] text-primary uppercase",
								children: "מרחב האימונים שלך"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-[1.5rem] font-bold leading-[1.15] text-ink",
							children: "הפכי כל אימון לפשוט וזמין לביצוע."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[12.5px] leading-relaxed text-muted-foreground",
							children: "בני תוכניות עבודה שמותאמות בדיוק לצרכים שלך — מסקוואטים ועד ימי אימון קצרים."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-12 -end-10 h-44 w-44 rounded-full bg-sage-soft/60 blur-2xl" })]
			}),
			adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card mt-4 p-4 text-start",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-bold tracking-[0.14em] text-muted-foreground uppercase",
							children: "תכנית חדשה"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setAdding(false);
								setName("");
							},
							"aria-label": "סגור",
							className: "press grid h-8 w-8 place-items-center rounded-xl text-muted-foreground hover:bg-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: name,
						onChange: (event) => setName(event.target.value),
						onKeyDown: (event) => event.key === "Enter" && submit(),
						placeholder: "למשל: תכנית חיטוב 4 ימים",
						className: "mt-2 w-full rounded-2xl border border-border/60 bg-secondary px-4 py-3.5 text-base outline-none placeholder:text-muted-foreground/80 focus:border-primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: submit,
							disabled: !name.trim(),
							children: "צרי תכנית"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
							onClick: () => {
								setAdding(false);
								setName("");
							},
							children: "ביטול"
						})]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "התוכניות שלך",
					subtitle: `${programs.length} תוכניות פעילות`
				}), programs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: programs.map((program) => {
						const daysCount = program.dayIds.length;
						const exerciseCount = program.dayIds.reduce((sum, id) => {
							return sum + (workouts.find((workout) => workout.id === id)?.items.length ?? 0);
						}, 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "surface-card press p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-sage-soft text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
											className: "h-5 w-5",
											strokeWidth: 2
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "min-w-0 flex-1 text-start",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/programs/$programId",
											params: { programId: program.id },
											className: "block",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate font-display text-[16px] font-bold text-ink",
												children: program.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-0.5 text-[12.5px] font-medium text-muted-foreground",
												children: [
													daysCount,
													" ימי אימון · ",
													exerciseCount,
													" תרגילים"
												]
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex shrink-0 items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => duplicateProgram(program.id),
												"aria-label": `שכפל ${program.name}`,
												className: "press grid h-9 w-9 place-items-center rounded-xl text-muted-foreground hover:bg-secondary hover:text-primary",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setPendingDelete({
													id: program.id,
													name: program.name
												}),
												"aria-label": `מחק את ${program.name}`,
												className: "press grid h-9 w-9 place-items-center rounded-xl text-muted-foreground hover:bg-secondary hover:text-destructive",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/programs/$programId",
												params: { programId: program.id },
												"aria-label": "פתח תכנית",
												className: "press grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
											})
										]
									})
								]
							}), program.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 line-clamp-2 text-start text-[12.5px] leading-relaxed text-muted-foreground",
								children: program.notes
							}) : null]
						}, program.id);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Dumbbell,
					title: "צרי קצב אימונים קבוע",
					description: "הוסיפי תכנית ראשונה ובני ימי אימון שמתאימים לשגרה שלך.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setAdding(true),
						className: "press inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-[13.5px] font-bold text-primary-foreground shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "h-4 w-4",
							strokeWidth: 2.4
						}), "יצירת תכנית אימונים"]
					})
				})]
			}),
			programs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ink-card-soft flex items-center gap-3 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/70",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
							className: "bg-transparent",
							children: "💡"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-start text-[12.5px] leading-relaxed text-muted-foreground",
						children: "רוצה להתחיל מהר? שכפלי תכנית קיימת והתאימי אותה לשבוע הבא."
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				open: pendingDelete !== null,
				title: "למחוק את התכנית?",
				description: pendingDelete ? `הפעולה תמחק את "${pendingDelete.name}" יחד עם כל ימי האימון והתרגילים שבה. לא ניתן לשחזר.` : void 0,
				confirmLabel: "מחק תכנית",
				cancelLabel: "חזרה",
				destructive: true,
				onConfirm: () => {
					if (pendingDelete) deleteProgram(pendingDelete.id);
					setPendingDelete(null);
				},
				onCancel: () => setPendingDelete(null)
			})
		]
	});
}
//#endregion
export { ProgramsPage as component };
