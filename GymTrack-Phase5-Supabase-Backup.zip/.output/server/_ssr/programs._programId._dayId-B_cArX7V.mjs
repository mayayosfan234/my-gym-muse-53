import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/programs._programId._dayId-B_cArX7V.js
var $$splitComponentImporter = () => import("./programs._programId._dayId-Cmdl-CEa.mjs");
var Route = createFileRoute("/programs/$programId/$dayId")({
	head: () => ({ meta: [{ title: "עורך יום אימון — הרוטינה שלי" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
