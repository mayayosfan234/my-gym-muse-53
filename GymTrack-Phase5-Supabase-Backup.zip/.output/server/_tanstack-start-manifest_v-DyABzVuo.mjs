//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DyABzVuo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/src/routes/__root.tsx",
		children: [
			"/",
			"/history",
			"/exercises/$exerciseId",
			"/programs/$programId",
			"/session/$workoutId",
			"/workouts/$workoutId",
			"/exercises/",
			"/nutrition/",
			"/programs/",
			"/workouts/",
			"/nutrition/foods/$foodId",
			"/nutrition/foods/"
		],
		css: ["/assets/index-pE5nYxUh.css"],
		preloads: [
			"/assets/index-DIiCVtrC.js",
			"/assets/link-Cdkys2yX.js",
			"/assets/preload-helper-B32On_yT.js",
			"/assets/exercises._exerciseId-CDEoZjwe.js",
			"/assets/programs._programId-sT16_JYc.js",
			"/assets/session._workoutId-DO5eOUD8.js",
			"/assets/workouts._workoutId-CmT4DuNo.js",
			"/assets/nutrition.foods._foodId-CgnEOjAv.js",
			"/assets/programs._programId._dayId-DZNugnjq.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DIiCVtrC.js"
		} }]
	},
	"/": {
		filePath: "/app/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D4ew-0p-.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/chevron-left-D57uaFsV.js",
			"/assets/flame-ig_Wg3NO.js",
			"/assets/play-CkI4xdhZ.js",
			"/assets/plus-B_5NnKQk.js",
			"/assets/utensils-bMp5QLCM.js"
		]
	},
	"/history": {
		filePath: "/app/src/routes/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-CnKT5iPa.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/trash-2-DMxrb6Aq.js",
			"/assets/ConfirmSheet-sWYQh5IN.js"
		]
	},
	"/exercises/$exerciseId": {
		filePath: "/app/src/routes/exercises.$exerciseId.tsx",
		children: void 0,
		preloads: [
			"/assets/exercises._exerciseId-BzJLLvjx.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/arrow-right-BNlCAyKW.js",
			"/assets/check-Bcbgoh1o.js",
			"/assets/pencil-R74SE_DC.js",
			"/assets/save-BGud6Ny2.js",
			"/assets/trash-2-DMxrb6Aq.js"
		]
	},
	"/programs/$programId": {
		filePath: "/app/src/routes/programs.$programId.tsx",
		children: ["/programs/$programId/$dayId"],
		preloads: [
			"/assets/programs._programId-qcVYosZ-.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/arrow-right-BNlCAyKW.js",
			"/assets/grip-vertical-Cyh9yhDm.js",
			"/assets/pencil-R74SE_DC.js",
			"/assets/play-CkI4xdhZ.js",
			"/assets/plus-B_5NnKQk.js",
			"/assets/save-BGud6Ny2.js",
			"/assets/trash-2-DMxrb6Aq.js",
			"/assets/ConfirmSheet-sWYQh5IN.js",
			"/assets/sortable.esm-BG7F_2py.js"
		]
	},
	"/session/$workoutId": {
		filePath: "/app/src/routes/session.$workoutId.tsx",
		children: void 0,
		preloads: [
			"/assets/session._workoutId-Bddim-CO.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/check-Bcbgoh1o.js",
			"/assets/chevron-left-D57uaFsV.js",
			"/assets/copy-BVI9MqCC.js",
			"/assets/Stepper-D3rQMtba.js",
			"/assets/play-CkI4xdhZ.js",
			"/assets/plus-B_5NnKQk.js",
			"/assets/search-C_WKJVpb.js",
			"/assets/ConfirmSheet-sWYQh5IN.js"
		]
	},
	"/workouts/$workoutId": {
		filePath: "/app/src/routes/workouts.$workoutId.tsx",
		children: void 0,
		preloads: [
			"/assets/workouts._workoutId-DvvW8ask.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/arrow-right-BNlCAyKW.js",
			"/assets/grip-vertical-Cyh9yhDm.js",
			"/assets/Stepper-D3rQMtba.js",
			"/assets/plus-B_5NnKQk.js",
			"/assets/trash-2-DMxrb6Aq.js"
		]
	},
	"/exercises/": {
		filePath: "/app/src/routes/exercises.index.tsx",
		children: void 0,
		preloads: [
			"/assets/exercises.index-hGt8Sgv2.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/chevron-left-D57uaFsV.js",
			"/assets/plus-B_5NnKQk.js",
			"/assets/search-C_WKJVpb.js",
			"/assets/sliders-horizontal-zbhxbYFz.js",
			"/assets/sparkles-DkDmGFqa.js",
			"/assets/trash-2-DMxrb6Aq.js",
			"/assets/ConfirmSheet-sWYQh5IN.js"
		]
	},
	"/nutrition/": {
		filePath: "/app/src/routes/nutrition.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.index-BHJTt0Uz.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/arrow-left-B4qxUBbJ.js",
			"/assets/chevron-left-D57uaFsV.js",
			"/assets/Stepper-D3rQMtba.js",
			"/assets/plus-B_5NnKQk.js",
			"/assets/shuffle-B2dkvhRH.js",
			"/assets/trash-2-DMxrb6Aq.js",
			"/assets/utensils-bMp5QLCM.js"
		]
	},
	"/programs/": {
		filePath: "/app/src/routes/programs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/programs.index-CWrig9Y5.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/arrow-left-B4qxUBbJ.js",
			"/assets/copy-BVI9MqCC.js",
			"/assets/plus-B_5NnKQk.js",
			"/assets/sparkles-DkDmGFqa.js",
			"/assets/trash-2-DMxrb6Aq.js",
			"/assets/ConfirmSheet-sWYQh5IN.js"
		]
	},
	"/workouts/": {
		filePath: "/app/src/routes/workouts.index.tsx",
		children: void 0,
		preloads: [
			"/assets/workouts.index-WXRVcTif.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js"
		]
	},
	"/nutrition/foods/$foodId": {
		filePath: "/app/src/routes/nutrition.foods.$foodId.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.foods._foodId-B3JAU1Hg.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/arrow-right-BNlCAyKW.js",
			"/assets/check-Bcbgoh1o.js",
			"/assets/Stepper-D3rQMtba.js",
			"/assets/shuffle-B2dkvhRH.js",
			"/assets/trash-2-DMxrb6Aq.js"
		]
	},
	"/programs/$programId/$dayId": {
		filePath: "/app/src/routes/programs.$programId.$dayId.tsx",
		children: void 0,
		preloads: [
			"/assets/programs._programId._dayId-CtlQ43_L.js",
			"/assets/flame-ig_Wg3NO.js",
			"/assets/Stepper-D3rQMtba.js",
			"/assets/search-C_WKJVpb.js",
			"/assets/sliders-horizontal-zbhxbYFz.js"
		]
	},
	"/nutrition/foods/": {
		filePath: "/app/src/routes/nutrition.foods.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.foods.index-7nVa_GNe.js",
			"/assets/useNavigate-DjOvJjbk.js",
			"/assets/AppShell-DsziWjwk.js",
			"/assets/arrow-right-BNlCAyKW.js",
			"/assets/plus-B_5NnKQk.js",
			"/assets/search-C_WKJVpb.js",
			"/assets/sparkles-DkDmGFqa.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
