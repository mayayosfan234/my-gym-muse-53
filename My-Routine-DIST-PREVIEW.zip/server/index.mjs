globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/manifest.json": {
		"type": "application/json",
		"etag": "\"1a3-Mjgn8clsjOleFrTtV+Ya/uOZhWw\"",
		"mtime": "2026-08-21T14:11:49.699Z",
		"size": 419,
		"path": "../public/manifest.json"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-21T14:11:49.699Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/AppShell-vK154XkK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"59649-TC9JSUJUigzTeMe4Qk34vi/jIzw\"",
		"mtime": "2026-08-21T14:11:47.691Z",
		"size": 366153,
		"path": "../public/assets/AppShell-vK154XkK.js"
	},
	"/assets/ConfirmSheet-O5ouLyqC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a85-eAHKWef6TNH1OCcjDX053p8kMbY\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 2693,
		"path": "../public/assets/ConfirmSheet-O5ouLyqC.js"
	},
	"/assets/Stepper-iFyn65nM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"674-7Zm9NL0iIoITQ2sv3rVl+Cw930w\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 1652,
		"path": "../public/assets/Stepper-iFyn65nM.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-08-21T14:11:49.699Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/arrow-left-DgaAc-YO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d-NGj1k61v1QhcdWkbHP/WwfIPp54\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 157,
		"path": "../public/assets/arrow-left-DgaAc-YO.js"
	},
	"/assets/arrow-right-vwfY00jK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d-qKVJ6g3sCwp+ACbzqvVz3u9cZAc\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 157,
		"path": "../public/assets/arrow-right-vwfY00jK.js"
	},
	"/assets/award-0rcO9xJo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10a-N+p12eu8h+nogi5ONBnlptAO0yo\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 266,
		"path": "../public/assets/award-0rcO9xJo.js"
	},
	"/assets/check-BlPOCqKX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74-lkBqWZN5JLo0kGKEl38f0SuOBxc\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 116,
		"path": "../public/assets/check-BlPOCqKX.js"
	},
	"/assets/chevron-left-Bket5n8Z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7a-SDTpE7JV1Fcs/J/Bnq9Qpx+8ZSU\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 122,
		"path": "../public/assets/chevron-left-Bket5n8Z.js"
	},
	"/assets/coach-D32HnGwa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b16-x6nltlFkwrsn5Km02M15xiL5JMg\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 23318,
		"path": "../public/assets/coach-D32HnGwa.js"
	},
	"/assets/exercises._exerciseId-BeCc3ZKH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ab-458kgRCvCt/F9SKIROiMhUYfiGY\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 939,
		"path": "../public/assets/exercises._exerciseId-BeCc3ZKH.js"
	},
	"/assets/exercises._exerciseId-CcLwki1-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"393b-crsNSOT7rKvDenfaW02MDKmw54I\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 14651,
		"path": "../public/assets/exercises._exerciseId-CcLwki1-.js"
	},
	"/assets/exercises.index-Brq1V2l6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1856-vYzqJxuNfrroV0eTo7HwZi0HB4U\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 6230,
		"path": "../public/assets/exercises.index-Brq1V2l6.js"
	},
	"/assets/flame-jblFR0GR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bf-9Q0M+OiFs3Hm9Ex36as9PIAgWrk\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 191,
		"path": "../public/assets/flame-jblFR0GR.js"
	},
	"/assets/grip-vertical-DNlZ6iKt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16b-oYbjP6CchtBUYECk+46gL6NFZNw\"",
		"mtime": "2026-08-21T14:11:47.695Z",
		"size": 363,
		"path": "../public/assets/grip-vertical-DNlZ6iKt.js"
	},
	"/assets/index-B0cbc7E1.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"18e85-YoirnJa0UQK5QzHZQ27aJTdCfhA\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 102021,
		"path": "../public/assets/index-B0cbc7E1.css"
	},
	"/assets/index-hPE_G0sv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4bc3d-Rlzwd5eyZaID0QJI20iyoaVgBJk\"",
		"mtime": "2026-08-21T14:11:47.683Z",
		"size": 310333,
		"path": "../public/assets/index-hPE_G0sv.js"
	},
	"/assets/link-yee4p_0-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"897e-cYwjZNyRCjP47AXaq7fiPT5PedA\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 35198,
		"path": "../public/assets/link-yee4p_0-.js"
	},
	"/assets/message-square-C6s3uJNP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e1-0Rmnl07DUJ8uxbzwTvMGLYZbf5o\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 225,
		"path": "../public/assets/message-square-C6s3uJNP.js"
	},
	"/assets/nutrition.foods._foodId-BwAsmm2p.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a08-V2EORlZqecZAgzjlfE71hfqRn7w\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 6664,
		"path": "../public/assets/nutrition.foods._foodId-BwAsmm2p.js"
	},
	"/assets/nutrition.foods._foodId-CEXSpdSj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"396-/1ed7Xu0Y5QzkZw805LsE8kjlLg\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 918,
		"path": "../public/assets/nutrition.foods._foodId-CEXSpdSj.js"
	},
	"/assets/nutrition.foods.index-zQxW-S_A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c0d-Nv8SY6md3IhwXfm0qQLr1/kWrjQ\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 3085,
		"path": "../public/assets/nutrition.foods.index-zQxW-S_A.js"
	},
	"/assets/nutrition.index-kJulzzN2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5529-j9DiP6zK+sH3AfbjefMmyElB5js\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 21801,
		"path": "../public/assets/nutrition.index-kJulzzN2.js"
	},
	"/assets/pencil-BKki-UVz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10c-muyyFqClATtsofsVPyTnlzoffLo\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 268,
		"path": "../public/assets/pencil-BKki-UVz.js"
	},
	"/assets/play-C1GJrWKJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b6-qJL9jw8AUorfgFNCwsW9YPGd/dA\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 182,
		"path": "../public/assets/play-C1GJrWKJ.js"
	},
	"/assets/plus-uCm-h4KE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"91-ZJrXPSYRN5kFy+lwbejFsBszzhQ\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 145,
		"path": "../public/assets/plus-uCm-h4KE.js"
	},
	"/assets/preload-helper-BjxpSAmc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1801-848pW+al7Z8r9/6PPvrQTmqzNxM\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 6145,
		"path": "../public/assets/preload-helper-BjxpSAmc.js"
	},
	"/assets/primitives-D5LuL0I9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7976-+bWSFRXa+3/oKJ8qrrTjcmDGnx0\"",
		"mtime": "2026-08-21T14:11:47.699Z",
		"size": 31094,
		"path": "../public/assets/primitives-D5LuL0I9.js"
	},
	"/assets/programs._programId-C0Nsl7Cz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d72-FnbmQpO3Wt7ev5GWt4o2a3FsYvc\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 7538,
		"path": "../public/assets/programs._programId-C0Nsl7Cz.js"
	},
	"/assets/programs._programId-Uc_F4C6Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"35f-87MoCC22kDNcuu1hstr1IxyN1O4\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 863,
		"path": "../public/assets/programs._programId-Uc_F4C6Q.js"
	},
	"/assets/programs._programId._dayId-BbaxdxGd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5199-KLO3vZbFNRfoRapqhiY3QVLfYYw\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 20889,
		"path": "../public/assets/programs._programId._dayId-BbaxdxGd.js"
	},
	"/assets/programs._programId._dayId-DXupF51D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c1-qxUHUwTrioIQQ17SMUguV0LV+oI\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 961,
		"path": "../public/assets/programs._programId._dayId-DXupF51D.js"
	},
	"/assets/programs.index-DwXteopI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1afe-GAQr3EGvrMij66wjjP2faWQ7Wk8\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 6910,
		"path": "../public/assets/programs.index-DwXteopI.js"
	},
	"/assets/routes-bUTzK3Ht.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3916-JIuEnC7xvHmgfTRVISAH8D2MT3w\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 14614,
		"path": "../public/assets/routes-bUTzK3Ht.js"
	},
	"/assets/save-DOwPy-dO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13f-x2kUMRBLaPbsy8tWA6uW5kzZ8w8\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 319,
		"path": "../public/assets/save-DOwPy-dO.js"
	},
	"/assets/search-CFZW9Ii3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a6-AgKjhNaCwILs7dXuOoGmMSaVF2g\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 166,
		"path": "../public/assets/search-CFZW9Ii3.js"
	},
	"/assets/session._workoutId-DciLfqPo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"464a-Nf6XmJZ5lMZOxWnTruG30hzmv1w\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 17994,
		"path": "../public/assets/session._workoutId-DciLfqPo.js"
	},
	"/assets/session._workoutId-Djfy6GEg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3e7-1DrjgCBT7B5/ayq0pZwqegRkeck\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 999,
		"path": "../public/assets/session._workoutId-Djfy6GEg.js"
	},
	"/assets/shuffle-BY3ypF2b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"177-xdUyKiq9uFTbOH22GbFBE01AHus\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 375,
		"path": "../public/assets/shuffle-BY3ypF2b.js"
	},
	"/assets/sliders-horizontal-DN9tU0qH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a0-euB/au55Lsip2xR97bTvEecqhaM\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 416,
		"path": "../public/assets/sliders-horizontal-DN9tU0qH.js"
	},
	"/assets/sortable.esm-D6X6Ol3k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a63b-9P+ZaojgxBqFPCX4hoPTojJiObo\"",
		"mtime": "2026-08-21T14:11:47.703Z",
		"size": 42555,
		"path": "../public/assets/sortable.esm-D6X6Ol3k.js"
	},
	"/assets/sparkles-DgFTihfE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e6-SsCIaQJamZpgbB8iy5G5pp5rg5k\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 486,
		"path": "../public/assets/sparkles-DgFTihfE.js"
	},
	"/assets/trash-2-YR-wzKnZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-UCBVzakQ0GNUgJgx60zdAz3eq4Y\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 320,
		"path": "../public/assets/trash-2-YR-wzKnZ.js"
	},
	"/assets/useNavigate-B4W8BEpo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8-vmRF1FjmTr/wfwe1PhQ8LJjK3BU\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 184,
		"path": "../public/assets/useNavigate-B4W8BEpo.js"
	},
	"/assets/utensils-BFPIkwNt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fd-8nClm+KKCozYsIgqjLbOE6Ybobo\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 253,
		"path": "../public/assets/utensils-BFPIkwNt.js"
	},
	"/assets/workouts._workoutId-DwH1fQcL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"301-dOork5Czdv2L2mjAY8uPSiy8ibM\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 769,
		"path": "../public/assets/workouts._workoutId-DwH1fQcL.js"
	},
	"/assets/workouts._workoutId-Pq6bSibv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14bc-ScFahj8KAybrSfSEYBQh91uum2o\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 5308,
		"path": "../public/assets/workouts._workoutId-Pq6bSibv.js"
	},
	"/assets/workouts.index-ChQFRdZ5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21f-ClbAi0lpxpGIe6nXzAPMeO+DqbI\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 543,
		"path": "../public/assets/workouts.index-ChQFRdZ5.js"
	},
	"/assets/x-BYaubBQm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"92-YJaCOARs1r5kl8TxruQJb4F8dO0\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 146,
		"path": "../public/assets/x-BYaubBQm.js"
	},
	"/assets/zap-BXHyPPEJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe-YmrkzVy6OgUZr/myVr7oGl3e4FY\"",
		"mtime": "2026-08-21T14:11:47.707Z",
		"size": 254,
		"path": "../public/assets/zap-BXHyPPEJ.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_jPnBRt = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_jPnBRt
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
