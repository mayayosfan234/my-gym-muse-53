import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/primitives-dLo4KDUl.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
/** Soft card with consistent padding + rounded corners. */
function Card({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("surface-card px-4 py-4 text-foreground sm:px-5", className),
		...props,
		children
	});
}
/** Pill / chip — used for tags, filters, status. */
function Pill({ children, variant = "neutral", className, onClick, active }) {
	const styles = {
		neutral: "bg-secondary text-secondary-foreground",
		sage: "bg-rose-soft text-primary",
		rose: "bg-rose-soft text-rose",
		ink: "bg-ink text-primary-foreground",
		cream: "bg-secondary text-ink-soft"
	};
	const interactive = Boolean(onClick);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: interactive ? "button" : void 0,
		onClick,
		"data-active": active ? "true" : void 0,
		className: cn("inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-[11.5px] font-bold transition-colors", active ? "bg-primary text-primary-foreground shadow-sm" : styles[variant], interactive && "press active:scale-95", className),
		children
	});
}
/** Compact icon-only round button — used in headers. */
function IconButton({ className, children, variant = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: cn("grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-transparent transition-all active:scale-95", {
			default: "bg-white/90 border border-border/60 text-ink hover:bg-white shadow-sm",
			primary: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm",
			ghost: "bg-transparent text-ink hover:bg-secondary"
		}[variant], className),
		...props,
		children
	});
}
/** Section header — title + optional action link. */
function SectionHeader({ title, subtitle, action, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("mb-3 flex items-end justify-between gap-3", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 text-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-[18px] font-bold tracking-tight text-ink",
				children: title
			}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-[12.5px] text-muted-foreground",
				children: subtitle
			}) : null]
		}), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0",
			children: action
		}) : null]
	});
}
/** Statistic tile — label + value + icon. */
function StatTile({ label, value, hint, icon: Icon, tone = "sage" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card flex flex-col gap-1 px-3.5 py-3.5 text-start",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("grid h-9 w-9 place-items-center rounded-xl", {
					sage: "bg-rose-soft text-primary",
					rose: "bg-rose-soft text-rose",
					cream: "bg-secondary text-ink-soft",
					ink: "bg-ink text-primary-foreground"
				}[tone]),
				children: Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "h-4 w-4",
					strokeWidth: 2.2
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-[22px] font-bold leading-none tabular-nums text-ink",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11.5px] font-medium leading-tight text-muted-foreground",
				children: label
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-[10.5px] leading-tight text-muted-foreground/80",
				children: hint
			}) : null
		]
	});
}
/** "Empty state" component. */
function EmptyState({ icon: Icon, title, description, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-card mx-auto flex max-w-sm flex-col items-center px-6 py-10 text-center",
		children: [
			Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-16 w-16 place-items-center rounded-2xl bg-rose-soft text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "h-7 w-7",
					strokeWidth: 1.8
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 font-display text-[19px] font-bold text-ink",
				children: title
			}),
			description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-[13px] leading-relaxed text-muted-foreground",
				children: description
			}) : null,
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: action
			}) : null
		]
	});
}
/** Big primary CTA button — full-width mobile. */
function PrimaryButton({ className, children, leading, trailing, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: cn("press inline-flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-primary px-5 text-[14.5px] font-bold text-primary-foreground shadow-[0_8px_20px_oklch(0.55_0.16_350/0.25)] hover:bg-primary/90 disabled:opacity-50", className),
		...props,
		children: [
			leading,
			children,
			trailing
		]
	});
}
/** Soft secondary button — full-width mobile. */
function SecondaryButton({ className, children, leading, trailing, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: cn("press inline-flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-secondary px-5 text-[14.5px] font-bold text-secondary-foreground hover:bg-secondary/80 disabled:opacity-50", className),
		...props,
		children: [
			leading,
			children,
			trailing
		]
	});
}
//#endregion
export { PrimaryButton as a, StatTile as c, Pill as i, EmptyState as n, SecondaryButton as o, IconButton as r, SectionHeader as s, Card as t };
