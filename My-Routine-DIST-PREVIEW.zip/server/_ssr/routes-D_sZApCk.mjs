import { r as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { $ as ChevronLeft, D as Play, E as Plus, G as Dumbbell, K as Droplets, M as MessageSquare, W as Flame, X as Circle, Z as CircleCheck, l as TrendingUp, r as Utensils, w as Ruler } from "../_libs/lucide-react.mjs";
import { K as useGym, U as todayKey, d as dayTotals, l as calculateRmr, n as AppShell, r as CARDIO_TYPES, t as ANIMAL_CHARACTERS, z as saveUserProfile } from "./AppShell-B7KD4DGt.mjs";
import { c as StatTile, s as SectionHeader, t as Card } from "./primitives-dLo4KDUl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D_sZApCk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatHebrewDate(date) {
	return date.toLocaleDateString("he-IL", {
		weekday: "long",
		day: "numeric",
		month: "long"
	});
}
function Dashboard() {
	const navigate = useNavigate();
	const { workouts, exercises, history, programs, nutritionDays, userProfile, cardioLogs, coachMessages } = useGym();
	const now = /* @__PURE__ */ new Date();
	const [waterMl, setWaterMl] = (0, import_react.useState)(1500);
	const waterTargetMl = 2500;
	const [showMeasurementModal, setShowMeasurementModal] = (0, import_react.useState)(false);
	const [waistCm, setWaistCm] = (0, import_react.useState)("72");
	const [hipsCm, setHipsCm] = (0, import_react.useState)("95");
	const [routineChecklist, setRoutineChecklist] = (0, import_react.useState)({
		workout: false,
		water: true,
		steps: false,
		nutrition: false
	});
	const [showCharModal, setShowCharModal] = (0, import_react.useState)(false);
	const selectedCharId = userProfile?.animalCharacter || "dog";
	const charMeta = ANIMAL_CHARACTERS.find((c) => c.id === selectedCharId) || ANIMAL_CHARACTERS[0];
	const startOfWeek = new Date(now);
	const dow = (now.getDay() + 6) % 7;
	startOfWeek.setDate(now.getDate() - dow);
	startOfWeek.setHours(0, 0, 0, 0);
	const thisWeek = history.filter((s) => new Date(s.date) >= startOfWeek);
	const volume = thisWeek.reduce((sum, s) => sum + s.entries.reduce((v, e) => v + e.sets.filter((x) => x.done).reduce((a, b) => a + b.reps * b.weight, 0), 0), 0);
	const totalDurationMin = Math.round(thisWeek.reduce((sum, s) => sum + (s.durationSec || 0), 0) / 60);
	const consistencyScore = Math.min(100, Math.round(thisWeek.length / (userProfile?.workoutsPerWeek || 4) * 100));
	const todayDateStr = todayKey();
	const nutritionToday = nutritionDays.find((d) => d.date === todayDateStr);
	const totalsToday = nutritionToday ? dayTotals(nutritionToday) : {
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0,
		fiber: 0
	};
	const targetCals = 2e3;
	const remainingCals = Math.max(0, targetCals - totalsToday.calories);
	calculateRmr(userProfile);
	const [weightInput, setWeightInput] = (0, import_react.useState)(String(userProfile?.weight ?? 65));
	const [workoutsWeekInput, setWorkoutsWeekInput] = (0, import_react.useState)(String(userProfile?.workoutsPerWeek ?? 4));
	const [showBodyModal, setShowBodyModal] = (0, import_react.useState)(false);
	const [showCardioModal, setShowCardioModal] = (0, import_react.useState)(false);
	const [cardioType, setCardioType] = (0, import_react.useState)(CARDIO_TYPES[0]);
	const [cardioDuration, setCardioDuration] = (0, import_react.useState)("20");
	const [cardioSpeed, setCardioSpeed] = (0, import_react.useState)("8.0");
	const [cardioIncline, setCardioIncline] = (0, import_react.useState)("2.0");
	const nextWorkout = workouts[0];
	const nextProgram = nextWorkout ? programs.find((p) => p.dayIds.includes(nextWorkout.id)) : void 0;
	const handleSelectAnimalChar = (charId) => {
		saveUserProfile({
			...userProfile ?? {
				weight: 65,
				height: 165,
				age: 26,
				gender: "female"
			},
			animalCharacter: charId
		});
		setShowCharModal(false);
	};
	const toggleChecklistItem = (key) => {
		setRoutineChecklist((prev) => ({
			...prev,
			[key]: !prev[key]
		}));
	};
	const latestCoachMsg = coachMessages && coachMessages.length > 0 ? coachMessages[0] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: formatHebrewDate(now),
		subtitle: "אימונים ותזונה",
		children: [
			latestCoachMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card p-4 rounded-3xl bg-linear-to-r from-primary/10 via-rose-50 to-primary/5 border border-primary/20 text-start space-y-1.5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 font-bold text-xs text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "h-4 w-4" }), " הודעה מהמאמן שלך"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] text-muted-foreground",
						children: new Date(latestCoachMsg.createdAt).toLocaleDateString("he-IL")
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold text-ink leading-relaxed",
					children: [
						"\"",
						latestCoachMsg.message,
						"\""
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card p-4 rounded-3xl bg-white border border-border/60 flex items-center justify-between text-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShowCharModal(true),
						className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-50 text-2xl border border-rose-100 shadow-xs cursor-pointer hover:scale-105 transition-transform",
						title: "לחץ להחלפת דמות מלווה",
						children: charMeta.emoji
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 font-bold text-sm text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [charMeta.name, " המלווה שלך"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-primary",
							children: "★"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: ["מדד עקביות שבועי: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "text-emerald-700",
							children: [consistencyScore, "%"]
						})]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setShowCharModal(true),
					className: "text-xs font-bold text-primary hover:underline cursor-pointer",
					children: "החלף דמות"
				})]
			}),
			nextWorkout ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ink-card p-5 text-start mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-white/20 px-3 py-1 text-[11px] font-bold text-primary-foreground uppercase",
							children: "האימון הבא"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[12px] text-primary-foreground/80 font-medium",
							children: [
								"~",
								nextWorkout.items.length * 12 + 15,
								" דקות"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-[22px] font-bold leading-tight text-primary-foreground",
						children: nextWorkout.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-[13px] text-primary-foreground/80",
						children: [
							nextProgram?.name ?? "תכנית אימונים",
							" · ",
							nextWorkout.items.length,
							" תרגילים"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => navigate({
								to: "/session/$workoutId",
								params: { workoutId: nextWorkout.id }
							}),
							className: "press inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-2xl bg-white px-4 text-[14px] font-bold text-ink shadow-sm cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 fill-current text-primary" }), "התחל אימון עכשיו"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/programs/$programId/$dayId",
							params: {
								programId: nextProgram?.id ?? "p-default",
								dayId: nextWorkout.id
							},
							className: "press grid h-11 w-11 place-items-center rounded-2xl bg-white/15 text-primary-foreground cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "text-start mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-[16px] font-bold text-ink",
						children: "אין תכניות אימון עדיין"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[13px] text-muted-foreground",
						children: "צרי תכנית אימונים ראשונה כדי להתחיל להתאמן בחדר כושר."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/programs",
						className: "press mt-3 inline-flex h-10 items-center justify-center gap-2 rounded-2xl bg-primary px-4 text-[13px] font-bold text-primary-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " צרי תכנית"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 text-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "הרוטינה של היום",
					subtitle: "משימות יומיות לשמירה על רצף"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: [
						{
							key: "workout",
							label: `אימון יומיומי: ${nextWorkout?.name || "מנוחה"}`
						},
						{
							key: "water",
							label: `שתיית מים (יעד 2,500 מ״ל): ${waterMl} מ״ל`
						},
						{
							key: "steps",
							label: "צעדים יומיים (יעד 8,000 צעדים)"
						},
						{
							key: "nutrition",
							label: `תיעוד תזונה ביומן: ${Math.round(totalsToday.calories)} קל׳`
						}
					].map(({ key, label }) => {
						const isDone = routineChecklist[key] || false;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							onClick: () => toggleChecklistItem(key),
							className: `surface-card p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between text-xs ${isDone ? "bg-emerald-50/50 border-emerald-200 line-through opacity-70" : "bg-white border-border/60 font-bold"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), isDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-emerald-600 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-4 w-4 text-muted-foreground shrink-0" })]
						}, key);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 text-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "הרגלים והיקפי גוף",
					subtitle: "מעקב מים והיקפים"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-card p-3.5 rounded-2xl border border-blue-100 bg-blue-50/40 space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 font-bold text-xs text-blue-900",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, { className: "h-4 w-4 text-blue-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "שתיית מים" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] font-bold text-blue-800",
								children: [
									waterMl,
									"/",
									waterTargetMl,
									" מ״ל"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1 pt-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setWaterMl((w) => Math.min(waterTargetMl, w + 250)),
								className: "flex-1 rounded-xl bg-blue-600 py-1 text-[11px] font-bold text-white shadow-xs cursor-pointer",
								children: "+250 מ״ל"
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => setShowMeasurementModal(true),
						className: "surface-card p-3.5 rounded-2xl border border-rose-100 bg-rose-50/40 space-y-1.5 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 font-bold text-xs text-rose-900",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ruler, { className: "h-4 w-4 text-rose-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "היקפים (ס״מ)" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-bold text-rose-800",
								children: "עדכון"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-muted-foreground pt-1",
							children: [
								"מותניים: ",
								waistCm,
								" ס״מ · ירכיים: ",
								hipsCm,
								" ס״מ"
							]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "פעילות השבוע",
					subtitle: `${thisWeek.length} אימונים בוצעו השבוע`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "אימונים",
							value: String(thisWeek.length),
							icon: Flame,
							tone: "rose"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "נפח ק״ג",
							value: volume >= 1e3 ? `${(volume / 1e3).toFixed(1)}k` : String(Math.round(volume)),
							icon: TrendingUp,
							tone: "sage"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "זמן אימון",
							value: `${totalDurationMin}m`,
							icon: Dumbbell,
							tone: "cream"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "תזונה להיום",
					subtitle: `נותרו עוד ${remainingCals} קלוריות`,
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/nutrition",
						className: "press rounded-full bg-secondary px-3 py-1.5 text-[12px] font-bold text-primary",
						children: "פתחי יומן"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rose-card p-4 text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-bold tracking-wider text-primary uppercase",
							children: "קלוריות שנצרכו"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 font-display text-[28px] font-bold tabular-nums text-ink",
							children: [
								Math.round(totalsToday.calories),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[14px] font-normal text-muted-foreground",
									children: ["/ ", targetCals]
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-12 w-12 place-items-center rounded-2xl bg-white/80 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Utensils, { className: "h-5 w-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-white/80 p-2.5 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-muted-foreground uppercase",
									children: "חלבון"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-[15px] font-bold tabular-nums text-ink",
									children: [Math.round(totalsToday.protein), "g"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-white/80 p-2.5 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-muted-foreground uppercase",
									children: "פחמימות"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-[15px] font-bold tabular-nums text-ink",
									children: [Math.round(totalsToday.carbs), "g"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-white/80 p-2.5 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-muted-foreground uppercase",
									children: "שומן"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-[15px] font-bold tabular-nums text-ink",
									children: [Math.round(totalsToday.fat), "g"]
								})]
							})
						]
					})]
				})]
			}),
			showCharModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm p-4",
				onClick: () => setShowCharModal(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-3xl border border-white/80 bg-white p-5 shadow-2xl space-y-3 text-start",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-bold text-base text-ink flex items-center gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "בחרי דמות אישית מלווה" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowCharModal(false),
							className: "text-muted-foreground font-bold text-sm cursor-pointer",
							children: "✕"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2 pt-1",
						children: ANIMAL_CHARACTERS.map((char) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleSelectAnimalChar(char.id),
							className: `p-3 rounded-2xl border text-center transition-all cursor-pointer ${selectedCharId === char.id ? "border-primary bg-primary/10 shadow-xs scale-105" : "border-border/60 hover:border-border"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-3xl block",
								children: char.emoji
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold text-ink mt-1 block",
								children: char.name
							})]
						}, char.id))
					})]
				})
			}),
			showMeasurementModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm p-4",
				onClick: () => setShowMeasurementModal(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-3xl border border-white/80 bg-white p-5 shadow-2xl space-y-3 text-start",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-bold text-base text-ink flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ruler, { className: "h-5 w-5 text-rose-600" }), " תיעוד היקפי גוף"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setShowMeasurementModal(false),
								className: "text-muted-foreground font-bold text-sm cursor-pointer",
								children: "✕"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block font-bold text-muted-foreground mb-1",
								children: "היקף מותניים (ס״מ)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								value: waistCm,
								onChange: (e) => setWaistCm(e.target.value),
								className: "w-full rounded-xl border border-border p-2"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block font-bold text-muted-foreground mb-1",
								children: "היקף ירכיים (ס״מ)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								value: hipsCm,
								onChange: (e) => setHipsCm(e.target.value),
								className: "w-full rounded-xl border border-border p-2"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowMeasurementModal(false),
							className: "w-full rounded-2xl bg-primary py-2.5 text-xs font-bold text-white shadow-md cursor-pointer",
							children: "שמור היקפים"
						})
					]
				})
			})
		]
	});
}
//#endregion
export { Dashboard as component };
