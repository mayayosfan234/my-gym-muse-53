import { r as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as Pause, D as Play, N as Meh, T as RefreshCw, U as Frown, _ as SkipForward, d as Timer, h as Smile, it as Award, m as Sparkles, n as X, t as Zap, tt as Check, z as Info } from "../_libs/lucide-react.mjs";
import { K as useGym, N as repLabel, R as saveSession, T as lastPerformance, W as uid, n as AppShell } from "./AppShell-B7KD4DGt.mjs";
import { a as PrimaryButton, r as IconButton } from "./primitives-dLo4KDUl.mjs";
import { a as Route$5 } from "./router-Dp2wwZ4h.mjs";
import { t as Stepper } from "./Stepper-gj3wsFLX.mjs";
import { t as ConfirmSheet } from "./ConfirmSheet-CYVKGo2b.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session._workoutId-DtCcBt2g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function supersetLabels(items) {
	const labels = {};
	let group = -1;
	let i = 0;
	while (i < items.length) {
		const sid = items[i]?.supersetId;
		if (sid) {
			let j = i;
			const run = [];
			while (j < items.length && items[j]?.supersetId === sid) {
				run.push(j);
				j += 1;
			}
			if (run.length >= 2) {
				group += 1;
				const letter = String.fromCharCode(65 + group % 26);
				run.forEach((idx, k) => {
					labels[idx] = `${letter}${k + 1}`;
				});
			}
			i = j;
		} else i += 1;
	}
	return labels;
}
var ACTIVE_SESSION_KEY = (id) => `gymtrack.active_session.${id}`;
function Session() {
	const { workoutId } = Route$5.useParams();
	const navigate = useNavigate();
	const { workouts, exercises, history, programs } = useGym();
	const workout = workouts.find((w) => w.id === workoutId);
	const currentProgram = programs.find((program) => program.dayIds.includes(workoutId));
	const [cardExercise, setCardExercise] = (0, import_react.useState)(null);
	const [isLowEnergy, setIsLowEnergy] = (0, import_react.useState)(false);
	const [isPaused, setIsPaused] = (0, import_react.useState)(false);
	const [showFeedbackModal, setShowFeedbackModal] = (0, import_react.useState)(false);
	const [difficultyRating, setDifficultyRating] = (0, import_react.useState)("appropriate");
	const [discomfortNotes, setDiscomfortNotes] = (0, import_react.useState)("");
	const [replacingIndex, setReplacingIndex] = (0, import_react.useState)(null);
	const [replaceSearch, setReplaceSearch] = (0, import_react.useState)("");
	const initial = (0, import_react.useMemo)(() => {
		if (!workout) return [];
		try {
			const saved = localStorage.getItem(ACTIVE_SESSION_KEY(workoutId));
			if (saved) {
				const parsed = JSON.parse(saved);
				if (Array.isArray(parsed) && parsed.length === workout.items.length) return parsed;
			}
		} catch {}
		return workout.items.map((item) => {
			const ex = exercises.find((e) => e.id === item.exerciseId);
			const last = lastPerformance(history, item.exerciseId);
			const isRange = item.repType === "range";
			const weightMult = isLowEnergy ? .85 : 1;
			const prescribedWeight = Math.round((item.targetWeight || item.weight) * weightMult * 2) / 2;
			const targetReps = isRange ? Math.max(1, (item.repMin ?? item.reps) - (isLowEnergy ? 1 : 0)) : Math.max(1, item.reps - (isLowEnergy ? 1 : 0));
			const targetRepMax = isRange ? item.repMax : void 0;
			const warmups = (item.warmups ?? []).map((w) => ({
				reps: w.reps,
				weight: w.weight,
				done: false,
				warmup: true
			}));
			const working = Array.from({ length: item.sets }, (_, i) => ({
				reps: last?.sets[i]?.reps ?? item.workingSets?.[i]?.reps ?? targetReps,
				weight: prescribedWeight,
				done: false,
				targetReps,
				targetRepMax,
				warmup: false,
				dropSet: item.workingSets?.[i]?.dropSet || item.dropSetConfig?.enabled
			}));
			return {
				exerciseId: item.exerciseId,
				exerciseName: ex?.name ?? "תרגיל שהוסר",
				equipment: ex?.equipment,
				notes: item.notes,
				targetSets: item.sets,
				targetReps,
				targetRepMax,
				repType: item.repType,
				sets: [...warmups, ...working]
			};
		});
	}, [workoutId, isLowEnergy]);
	const [entries, setEntries] = (0, import_react.useState)(initial);
	const [startedAt] = (0, import_react.useState)(() => Date.now());
	const [rest, setRest] = (0, import_react.useState)(0);
	const [pendingExit, setPendingExit] = (0, import_react.useState)(false);
	const timerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setEntries(initial);
	}, [initial]);
	(0, import_react.useEffect)(() => {
		if (!workoutId || entries.length === 0) return;
		try {
			localStorage.setItem(ACTIVE_SESSION_KEY(workoutId), JSON.stringify(entries));
		} catch {}
	}, [entries, workoutId]);
	(0, import_react.useEffect)(() => {
		if (rest <= 0 || isPaused) return;
		timerRef.current = setInterval(() => setRest((r) => Math.max(0, r - 1)), 1e3);
		return () => {
			if (timerRef.current) clearInterval(timerRef.current);
		};
	}, [rest > 0, isPaused]);
	if (!workout) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "אימון לא נמצא",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "surface-card p-5 text-muted-foreground text-start",
			children: "אימון זה אינו קיים עוד בספרייה."
		})
	});
	const labels = supersetLabels(workout.items);
	const patchSet = (ei, si, patch) => setEntries((prev) => prev.map((e, i) => i === ei ? {
		...e,
		sets: e.sets.map((s, j) => j === si ? {
			...s,
			...patch
		} : s)
	} : e));
	const toggleSetDone = (ei, si) => {
		const currentSet = entries[ei]?.sets[si];
		if (!currentSet) return;
		const isNowDone = !currentSet.done;
		patchSet(ei, si, { done: isNowDone });
		if (isNowDone && !currentSet.warmup) {
			const restSec = workout.items[ei]?.rest ?? 60;
			setRest(restSec);
		}
	};
	const replaceExercise = (ei, newEx) => {
		setEntries((prev) => prev.map((e, i) => i === ei ? {
			...e,
			exerciseId: newEx.id,
			exerciseName: newEx.name,
			equipment: newEx.equipment
		} : e));
		setReplacingIndex(null);
		setReplaceSearch("");
	};
	const clearSavedSession = () => {
		try {
			localStorage.removeItem(ACTIVE_SESSION_KEY(workout.id));
		} catch {}
	};
	const totalSets = entries.reduce((a, e) => a + e.sets.filter((s) => !s.warmup).length, 0);
	const doneSets = entries.reduce((a, e) => a + e.sets.filter((s) => s.done && !s.warmup).length, 0);
	const handleFinishConfirm = () => {
		saveSession({
			id: uid(),
			workoutId: workout.id,
			workoutName: workout.name,
			programName: currentProgram?.name,
			date: (/* @__PURE__ */ new Date()).toISOString(),
			durationSec: Math.round((Date.now() - startedAt) / 1e3),
			entries: entries.map((e) => ({
				...e,
				sets: e.sets.filter((s) => s.done)
			})),
			difficultyRating,
			discomfortNotes: discomfortNotes.trim() || void 0
		});
		clearSavedSession();
		setShowFeedbackModal(false);
		navigate({ to: "/programs" });
	};
	const progress = totalSets ? doneSets / totalSets * 100 : 0;
	const approvedIds = (replacingIndex !== null ? workout.items[replacingIndex] : null)?.approvedAlternatives;
	const allowedExercisesForReplace = exercises.filter((ex) => {
		if (approvedIds && approvedIds.length > 0) return approvedIds.includes(ex.id);
		return ex.name.toLowerCase().includes(replaceSearch.toLowerCase()) || ex.muscleGroup.toLowerCase().includes(replaceSearch.toLowerCase());
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: currentProgram?.name ?? "אימון",
		title: workout.name,
		subtitle: `${doneSets} מתוך ${totalSets} סטים · בהצלחה!`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setIsLowEnergy(!isLowEnergy),
					className: `p-2 rounded-full border transition-colors cursor-pointer ${isLowEnergy ? "bg-amber-100 text-amber-800 border-amber-300" : "bg-secondary text-ink hover:bg-secondary/80"}`,
					title: "מצב ללא אנרגיה",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setIsPaused(!isPaused),
					className: `p-2 rounded-full border transition-colors cursor-pointer ${isPaused ? "bg-amber-100 text-amber-800 border-amber-300" : "bg-secondary text-ink hover:bg-secondary/80"}`,
					title: isPaused ? "המשך אימון" : "השהה אימון",
					children: isPaused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-4 w-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					"aria-label": "יציאה מהאימון",
					onClick: () => setPendingExit(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
				})
			]
		}),
		children: [
			isLowEnergy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card p-3 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200 text-start space-y-1 mb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 font-bold text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4 text-amber-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "מצב יום ללא אנרגיה מופעל" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11.5px] text-amber-700",
					children: "הותאם עבורך נפח אימון קל יותר (משקל קל ב-15%) מבלי לשנות את התוכנית המקורית של המאמן!"
				})]
			}),
			isPaused && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "surface-card p-3 rounded-2xl bg-amber-50 text-amber-800 border border-amber-200 text-center font-bold text-xs mb-3",
				children: "⏸ האימון מושהה כעת. חזרי מתי שנוח לך!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card flex items-center gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3.5 w-3.5 fill-current" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1 text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold tracking-[0.14em] text-muted-foreground uppercase",
							children: "התקדמות אימון"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11.5px] font-semibold tabular-nums text-ink",
							children: [Math.round(progress), "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary transition-all duration-500",
							style: { width: `${progress}%` }
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-4",
				children: entries.map((entry, ei) => {
					const item = workout.items[ei];
					const targetLabel = item ? repLabel(item) : String(entry.targetReps ?? "");
					const supersetLabel = labels[ei];
					const fullExercise = exercises.find((e) => e.id === entry.exerciseId);
					const workingCount = entry.sets.filter((s) => !s.warmup).length;
					const prescribedWeight = item?.targetWeight || item?.weight || 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `surface-card p-4 text-start ${supersetLabel ? "border-s-4 border-s-primary rounded-s-none" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => fullExercise && setCardExercise(fullExercise),
										className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-sage-soft text-primary press cursor-pointer",
										"aria-label": `פתח פרטי ${entry.exerciseName}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
											className: "h-4 w-4",
											strokeWidth: 2
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1 text-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [supersetLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "shrink-0 rounded-lg bg-primary px-2 py-0.5 text-[11px] font-bold text-primary-foreground",
												children: supersetLabel
											}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => fullExercise && setCardExercise(fullExercise),
												className: "min-w-0 truncate text-start font-display text-[15.5px] font-semibold text-ink hover:text-primary cursor-pointer",
												children: entry.exerciseName
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-0.5 text-[12px] text-muted-foreground",
											children: [
												"יעד מאמן: ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "text-ink",
													children: [prescribedWeight, " ק\"ג"]
												}),
												" ·",
												" ",
												entry.targetSets ?? workingCount,
												"× ",
												targetLabel,
												" חזרות"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setReplacingIndex(ei),
											className: "press grid h-9 w-9 place-items-center rounded-full bg-secondary text-muted-foreground hover:text-primary cursor-pointer",
											title: "תחליף מורשה",
											"aria-label": "תחליף מורשה",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-3.5 w-3.5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setRest(item?.rest ?? 60),
											className: "press flex shrink-0 items-center gap-1 rounded-full bg-secondary px-3 py-2 text-[12px] font-semibold text-ink cursor-pointer",
											"aria-label": "התחל מנוחה",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "h-3.5 w-3.5 text-primary" }),
												item?.rest ?? 60,
												"ש׳"
											]
										})]
									})
								]
							}),
							item?.techniqueNotes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2.5 rounded-2xl bg-primary/5 p-2.5 text-[12px] text-primary font-medium border border-primary/10 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["הנחיית טכניקה ממאמן: ", item.techniqueNotes] })]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 space-y-2",
								children: entry.sets.map((s, si) => {
									const workingIndex = entry.sets.slice(0, si + 1).filter((x) => !x.warmup).length;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `rounded-2xl border p-3 transition-all ${s.done ? "border-primary bg-primary/10 shadow-sm" : "border-border/60 bg-secondary/60"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `grid h-7 w-7 place-items-center rounded-lg text-[11px] font-bold ${s.done ? "bg-primary text-primary-foreground" : "bg-primary/15 text-primary"}`,
													children: workingIndex
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "min-w-0 flex-1 text-start",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "truncate text-[12.5px] font-semibold text-ink",
														children: [s.dropSet ? "Drop Set" : `סט ${workingIndex}`, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "ms-1 text-[11px] font-normal text-muted-foreground",
															children: [
																"· יעד ",
																s.targetReps,
																" ",
																s.targetRepMax ? `-${s.targetRepMax}` : ""
															]
														})]
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => toggleSetDone(ei, si),
													className: `press grid h-11 w-11 place-items-center rounded-2xl text-[13px] font-bold transition-colors cursor-pointer ${s.done ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:bg-secondary/80"}`,
													"aria-label": s.done ? "בטל סיום סט" : "סמן סט כבוצע",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
														className: "h-5 w-5",
														strokeWidth: 2.6
													})
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 grid grid-cols-2 gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
												label: "משקל בפועל",
												value: s.weight,
												step: 2.5,
												suffix: "ק״ג",
												onChange: (v) => patchSet(ei, si, { weight: v })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
												label: "חזרות בפועל",
												value: s.reps,
												min: 0,
												onChange: (v) => patchSet(ei, si, { reps: v })
											})]
										})]
									}, si);
								})
							})
						]
					}, `${entry.exerciseId}-${ei}`);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => setShowFeedbackModal(true),
					leading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "h-4 w-4",
						strokeWidth: 2.4
					}),
					children: "סיים ושמור אימון"
				})
			}),
			showFeedbackModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm",
				onClick: () => setShowFeedbackModal(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-3xl border border-white/80 bg-white p-5 shadow-2xl space-y-4 text-start",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "h-6 w-6" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg font-bold text-ink",
									children: "אימון מצוין! איך הרגשת?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "המשוב ישודר ישירות ללוח המאמן שלך"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-bold text-muted-foreground",
								children: "דרגת קושי"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									{
										id: "easy",
										label: "קל מדי",
										icon: Smile,
										color: "text-emerald-600"
									},
									{
										id: "appropriate",
										label: "מדויק",
										icon: Meh,
										color: "text-primary"
									},
									{
										id: "difficult",
										label: "קשה מדי",
										icon: Frown,
										color: "text-rose-600"
									}
								].map(({ id, label, icon: Icon, color }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setDifficultyRating(id),
									className: `p-2.5 rounded-2xl border text-center font-bold text-xs flex flex-col items-center gap-1 cursor-pointer transition-all ${difficultyRating === id ? "border-primary bg-primary/10 shadow-xs scale-105" : "border-border/60 hover:border-border"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `h-5 w-5 ${color}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
								}, id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-muted-foreground mb-1",
							children: "דיווח על אי-נוחות / הערה למאמן (אופציונלי)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: discomfortNotes,
							onChange: (e) => setDiscomfortNotes(e.target.value),
							placeholder: "למשל: עומס קל במרפק ימין בסט האחרון...",
							className: "w-full rounded-2xl border border-border p-2.5 text-xs outline-none focus:border-primary h-16"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: handleFinishConfirm,
							className: "w-full rounded-2xl bg-primary py-3 text-sm font-bold text-white shadow-md cursor-pointer hover:bg-primary/90",
							children: "אישור ושמירת אימון"
						})
					]
				})
			}),
			rest > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scale-in fixed inset-x-0 z-40 mx-auto max-w-xl px-4",
				style: { bottom: "calc(5.5rem + env(safe-area-inset-bottom))" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ink-card flex items-center gap-2 p-3.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white/15",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "h-4 w-4 text-primary-foreground" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0 text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-semibold tracking-[0.14em] text-primary-foreground/80 uppercase",
								children: "זמן מנוחה"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-[20px] font-semibold tabular-nums text-primary-foreground",
								children: [
									Math.floor(rest / 60),
									":",
									String(rest % 60).padStart(2, "0")
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setRest((r) => Math.max(0, r - 15)),
									className: "press rounded-xl bg-white/15 px-2.5 py-1.5 text-[12px] font-bold text-primary-foreground hover:bg-white/25 cursor-pointer",
									children: "-15ש׳"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setRest((r) => r + 15),
									className: "press rounded-xl bg-white/15 px-2.5 py-1.5 text-[12px] font-bold text-primary-foreground hover:bg-white/25 cursor-pointer",
									children: "+15ש׳"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setRest(0),
									className: "press flex items-center gap-1 rounded-xl bg-white/20 px-3 py-1.5 text-[12px] font-bold text-primary-foreground hover:bg-white/30 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "h-3.5 w-3.5 fill-current" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "דילוג" })]
								})
							]
						})
					]
				})
			}) : null,
			replacingIndex !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fade-in fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 backdrop-blur-sm",
				onClick: () => setReplacingIndex(null),
				style: { paddingBottom: "env(safe-area-inset-bottom)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "scale-in max-h-[85dvh] w-full max-w-xl overflow-y-auto rounded-t-[2rem] border-t border-border/40 bg-card p-5 text-start shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1.5 w-12 rounded-full bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-[18px] font-bold text-ink",
								children: "תרגיל חלופי מורשה למתאמן"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								"aria-label": "סגור",
								onClick: () => setReplacingIndex(null),
								variant: "ghost",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 space-y-2 pb-6",
							children: allowedExercisesForReplace.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => replaceExercise(replacingIndex, ex),
								className: "press flex w-full items-center justify-between rounded-2xl bg-secondary p-3.5 text-start hover:bg-secondary/80 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold text-ink text-[14px]",
									children: ex.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[12px] text-muted-foreground",
									children: [
										ex.muscleGroup,
										" ",
										ex.equipment ? `· ${ex.equipment}` : ""
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-xl bg-primary/10 px-2.5 py-1 text-[12px] font-semibold text-primary",
									children: "בחר"
								})]
							}, ex.id))
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				open: pendingExit,
				title: "לצאת מהאימון?",
				description: "הסטים שתיעדת יישמרו רק אם לא תנקי אותם.",
				confirmLabel: "צאי בלי לשמור",
				cancelLabel: "המשיכי באימון",
				destructive: true,
				onConfirm: () => {
					clearSavedSession();
					setPendingExit(false);
					navigate({ to: "/programs" });
				},
				onCancel: () => setPendingExit(false)
			})
		]
	});
}
//#endregion
export { Session as component };
