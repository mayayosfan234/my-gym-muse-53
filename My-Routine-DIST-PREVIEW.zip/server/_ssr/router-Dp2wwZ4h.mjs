import { r as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { _ as useRouter, c as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Dp2wwZ4h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "העמוד לא נמצא"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "העמוד שחיפשת אינו קיים או שהועבר לכתובת אחרת."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90",
						children: "חזרה לדף הבית"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "אירעה שגיאה בטעינת העמוד"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "משהו השתבש, אפשר לנסות לרענן או לחזור לדף הבית."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90",
						children: "נסה שוב"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-xl border border-input bg-background px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:bg-accent",
						children: "חזרה לדף הבית"
					})]
				})
			]
		})
	});
}
var Route$13 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1"
			},
			{ title: "הרוטינה שלי — אימונים ותזונה" },
			{
				name: "description",
				content: "מעקב אימונים, תזונה, תרגילים ושיאים אישיים בעברית."
			},
			{
				name: "theme-color",
				content: "#567765"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "black-translucent"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "הרוטינה שלי"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:title",
				content: "הרוטינה שלי — אימונים ותזונה"
			}
		],
		links: [{
			rel: "icon",
			href: "/favicon.ico",
			type: "image/x-icon"
		}, {
			rel: "manifest",
			href: "/manifest.json"
		}]
	}),
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
/**
* Reset window scroll position to the top after every navigation. Subscribes
* to the router's `onResolved` event so the reset runs at the end of the
* router's own pipeline (after matchers + loaders) rather than racing against
* it the way an effect-on-pathname-change did. With `scrollRestoration: false`
* on the router, this is the single source of truth for "scroll to top on
* navigation", which is what fixes detail pages opening at the bottom when
* the user was deep-scrolled on a list page.
*
* Note: `behavior: 'instant'` is non-standard; browsers may fall back to
* smooth. A bare `scrollTo(0, 0)` is synchronous on every modern engine.
*/
function ScrollToTop() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		const resetScroll = () => {
			window.scrollTo(0, 0);
			document.documentElement.scrollTop = 0;
			document.body.scrollTop = 0;
		};
		resetScroll();
		return router.subscribe("onResolved", resetScroll);
	}, [router]);
	return null;
}
function RootComponent() {
	const { queryClient } = Route$13.useRouteContext();
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = "he";
		document.documentElement.dir = "rtl";
		document.body.dir = "rtl";
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollToTop, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		]
	});
}
var $$splitComponentImporter$12 = () => import("./routes-D_sZApCk.mjs");
var Route$12 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "לוח בקרה — הרוטינה שלי" },
		{
			name: "description",
			content: "מעקב אימונים, משקל גוף ותזונה יומית."
		},
		{
			property: "og:title",
			content: "לוח בקרה — הרוטינה שלי"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./coach-koFGG_rq.mjs");
var Route$11 = createFileRoute("/coach")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./exercises.index-ByEbT9XE.mjs");
var Route$10 = createFileRoute("/exercises/")({
	head: () => ({ meta: [
		{ title: "ספריית תרגילים — הרוטינה שלי" },
		{
			name: "description",
			content: "עייני, הוסיפי, ערכי ונהלי את תרגילי הכושר שלך בספרייה."
		},
		{
			property: "og:title",
			content: "ספריית תרגילים — הרוטינה שלי"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./exercises._exerciseId-BHRNpijv.mjs");
var Route$9 = createFileRoute("/exercises/$exerciseId")({
	head: () => ({ meta: [
		{ title: "פרטי תרגיל — הרוטינה שלי" },
		{
			name: "description",
			content: "פרטי תרגיל: קבוצת שרירים, ציוד, הוראות ביצוע והערות אישיות."
		},
		{
			property: "og:title",
			content: "פרטי תרגיל — הרוטינה שלי"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./nutrition.index-DdqOJP8q.mjs");
var Route$8 = createFileRoute("/nutrition/")({
	head: () => ({ meta: [{ title: "יומן תזונה — הרוטינה שלי" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./programs.index-D41Z-W7x.mjs");
var Route$7 = createFileRoute("/programs/")({
	head: () => ({ meta: [{ title: "תוכניות אימון — הרוטינה שלי" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./programs._programId-CKbD3LCm.mjs");
var Route$6 = createFileRoute("/programs/$programId")({
	head: () => ({ meta: [{ title: "תכנית אימונים — הרוטינה שלי" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./session._workoutId-DtCcBt2g.mjs");
var Route$5 = createFileRoute("/session/$workoutId")({
	head: () => ({ meta: [
		{ title: "אימון פעיל — הרוטינה שלי" },
		{
			name: "description",
			content: "רשמי סטים, משקלים וחזרות בזמן אמת במהלך האימון."
		},
		{
			property: "og:title",
			content: "אימון פעיל — הרוטינה שלי"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./workouts.index-DwWAQ84O.mjs");
var Route$4 = createFileRoute("/workouts/")({
	head: () => ({ meta: [{ title: "האימונים שלי — הרוטינה שלי" }, {
		property: "og:title",
		content: "האימונים שלי — הרוטינה שלי"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./workouts._workoutId-CI_RaVVP.mjs");
var Route$3 = createFileRoute("/workouts/$workoutId")({
	head: () => ({ meta: [{ title: "עורך אימון — הרוטינה שלי" }, {
		property: "og:title",
		content: "עורך אימון — הרוטינה שלי"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./nutrition.foods.index-DPUy5MJ8.mjs");
var Route$2 = createFileRoute("/nutrition/foods/")({
	head: () => ({ meta: [{ title: "ספריית מאכלים — הרוטינה שלי" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./nutrition.foods._foodId-BQj6TE6u.mjs");
var Route$1 = createFileRoute("/nutrition/foods/$foodId")({
	head: () => ({ meta: [{ title: "פרטי מאכל — הרוטינה שלי" }] }),
	validateSearch: (search) => ({
		mealDate: typeof search.mealDate === "string" ? search.mealDate : void 0,
		mealId: typeof search.mealId === "string" ? search.mealId : void 0,
		logFoodId: typeof search.logFoodId === "string" ? search.logFoodId : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./programs._programId._dayId-DvIhQ9pA.mjs");
var Route = createFileRoute("/programs/$programId/$dayId")({
	head: () => ({ meta: [{ title: "עורך יום אימון — הרוטינה שלי" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$12.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$13
});
var CoachRoute = Route$11.update({
	id: "/coach",
	path: "/coach",
	getParentRoute: () => Route$13
});
var ExercisesIndexRoute = Route$10.update({
	id: "/exercises/",
	path: "/exercises/",
	getParentRoute: () => Route$13
});
var ExercisesExerciseIdRoute = Route$9.update({
	id: "/exercises/$exerciseId",
	path: "/exercises/$exerciseId",
	getParentRoute: () => Route$13
});
var NutritionIndexRoute = Route$8.update({
	id: "/nutrition/",
	path: "/nutrition/",
	getParentRoute: () => Route$13
});
var ProgramsIndexRoute = Route$7.update({
	id: "/programs/",
	path: "/programs/",
	getParentRoute: () => Route$13
});
var ProgramsProgramIdRoute = Route$6.update({
	id: "/programs/$programId",
	path: "/programs/$programId",
	getParentRoute: () => Route$13
});
var SessionWorkoutIdRoute = Route$5.update({
	id: "/session/$workoutId",
	path: "/session/$workoutId",
	getParentRoute: () => Route$13
});
var WorkoutsIndexRoute = Route$4.update({
	id: "/workouts/",
	path: "/workouts/",
	getParentRoute: () => Route$13
});
var WorkoutsWorkoutIdRoute = Route$3.update({
	id: "/workouts/$workoutId",
	path: "/workouts/$workoutId",
	getParentRoute: () => Route$13
});
var NutritionFoodsIndexRoute = Route$2.update({
	id: "/nutrition/foods/",
	path: "/nutrition/foods/",
	getParentRoute: () => Route$13
});
var NutritionFoodsFoodIdRoute = Route$1.update({
	id: "/nutrition/foods/$foodId",
	path: "/nutrition/foods/$foodId",
	getParentRoute: () => Route$13
});
var ProgramsProgramIdRouteChildren = { ProgramsProgramIdDayIdRoute: Route.update({
	id: "/$dayId",
	path: "/$dayId",
	getParentRoute: () => ProgramsProgramIdRoute
}) };
var rootRouteChildren = {
	IndexRoute,
	CoachRoute,
	ExercisesExerciseIdRoute,
	ProgramsProgramIdRoute: ProgramsProgramIdRoute._addFileChildren(ProgramsProgramIdRouteChildren),
	SessionWorkoutIdRoute,
	WorkoutsWorkoutIdRoute,
	ExercisesIndexRoute,
	NutritionIndexRoute,
	ProgramsIndexRoute,
	WorkoutsIndexRoute,
	NutritionFoodsFoodIdRoute,
	NutritionFoodsIndexRoute
};
var routeTree = Route$13._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: false,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { Route$5 as a, Route$3 as i, Route as n, Route$6 as o, Route$1 as r, Route$9 as s, router_exports as t };
