import { r as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { E as Plus, S as Search, at as ArrowRight, st as Apple } from "../_libs/lucide-react.mjs";
import { K as useGym, n as AppShell } from "./AppShell-B7KD4DGt.mjs";
import { i as Pill, n as EmptyState, s as SectionHeader } from "./primitives-dLo4KDUl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nutrition.foods.index-DPUy5MJ8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FoodLibrary() {
	const { foods } = useGym();
	const [query, setQuery] = (0, import_react.useState)("");
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLocaleLowerCase();
		return foods.filter((f) => !q || f.name.toLocaleLowerCase().includes(q) || (f.category ?? "").toLocaleLowerCase().includes(q)).sort((a, b) => a.name.localeCompare(b.name, "he"));
	}, [foods, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: "תזונה",
		title: "ספריית מאכלים",
		subtitle: `${foods.length} מוצרים זמינים`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/nutrition",
				"aria-label": "חזרה ליומן",
				className: "press grid h-11 w-11 place-items-center rounded-2xl bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-5 w-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/nutrition/foods/$foodId",
				params: { foodId: "new" },
				"aria-label": "הוסף מאכל",
				className: "press grid h-11 w-11 place-items-center rounded-2xl bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "h-5 w-5",
					strokeWidth: 2.4
				})
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "num-pill flex h-12 items-center gap-2 px-3.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 shrink-0 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "חפשי מאכל בספרייה...",
					className: "w-full min-w-0 bg-transparent text-[14px] outline-none placeholder:text-muted-foreground"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				className: "mt-5",
				title: `${filtered.length} תוצאות`,
				subtitle: "לחצי על מאכל לעריכה או החלפה"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: filtered.slice(0, 80).map((food) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/nutrition/foods/$foodId",
					params: { foodId: food.id },
					className: "surface-card press block p-3.5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-sage-soft text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Apple, {
								className: "h-4 w-4",
								strokeWidth: 1.8
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-display text-[14.5px] font-semibold text-ink",
								children: food.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 text-[11.5px] text-muted-foreground",
								children: [
									food.servingSize,
									" · ",
									food.calories,
									" קלוריות · חלבון ",
									food.protein,
									"g · פחמימות",
									" ",
									food.carbs,
									"g · שומן ",
									food.fat,
									"g"
								]
							})]
						})]
					})
				}, food.id))
			}),
			filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Apple,
				title: "לא נמצאו מאכלים",
				description: "לחצי על + כדי ליצור מאכל חדש.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/nutrition/foods/$foodId",
					params: { foodId: "new" },
					className: "press inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-[13.5px] font-semibold text-primary-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "h-4 w-4",
						strokeWidth: 2.4
					}), "מאכל חדש"]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {})
			})
		]
	});
}
//#endregion
export { FoodLibrary as component };
