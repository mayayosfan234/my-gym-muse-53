import { r as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { F as LogIn, G as Dumbbell, P as LogOut, R as LayoutGrid, V as House, Y as Cloud, a as User, b as Shield, q as Crown, st as Apple } from "../_libs/lucide-react.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AppShell-B7KD4DGt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Database of AT LEAST 488 distinct realistic Israeli supermarket food entries */
var ISRAELI_FOOD_DATABASE = [
	{
		id: "f-israel-1",
		name: "חלב 3% - תנובה / שטראוס",
		category: "חלב",
		servingSize: "100 מ\"ל",
		calories: 60,
		protein: 3.2,
		carbs: 4.7,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (חלב)"
	},
	{
		id: "f-israel-2",
		name: "חלב 1% - תנובה",
		category: "חלב",
		servingSize: "100 מ\"ל",
		calories: 42,
		protein: 3.3,
		carbs: 4.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (חלב)"
	},
	{
		id: "f-israel-3",
		name: "חלב דל לקטוז 2%",
		category: "חלב",
		servingSize: "100 מ\"ל",
		calories: 50,
		protein: 3.3,
		carbs: 4.7,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (חלב)"
	},
	{
		id: "f-israel-4",
		name: "חלב סויה ללא סוכר - אלפרו",
		category: "תחליפי חלב",
		servingSize: "100 מ\"ל",
		calories: 33,
		protein: 3.3,
		carbs: .2,
		fat: 1.8,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי חלב)"
	},
	{
		id: "f-israel-5",
		name: "חלב שקדים ללא סוכר",
		category: "תחליפי חלב",
		servingSize: "100 מ\"ל",
		calories: 15,
		protein: .5,
		carbs: .2,
		fat: 1.2,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי חלב)"
	},
	{
		id: "f-israel-6",
		name: "חלב שיבולת שועל - אלפרו",
		category: "תחליפי חלב",
		servingSize: "100 מ\"ל",
		calories: 45,
		protein: 1,
		carbs: 6.8,
		fat: 1.5,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי חלב)"
	},
	{
		id: "f-israel-7",
		name: "קוטג' 5% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 95,
		protein: 11,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-8",
		name: "קוטג' 3% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 78,
		protein: 11.5,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-9",
		name: "קוטג' 9% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 124,
		protein: 10.5,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-10",
		name: "קוטג' פרו 12g חלבון",
		category: "גבינות",
		servingSize: "גביע (125g)",
		calories: 105,
		protein: 12,
		carbs: 2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-11",
		name: "גבינה לבנה 5% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 90,
		protein: 10,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-12",
		name: "גבינה לבנה 3% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 73,
		protein: 10.2,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-13",
		name: "גבינה לבנה 9% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 120,
		protein: 9.5,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-14",
		name: "גבינה צהובה עמק 28% - תנובה",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 98,
		protein: 7,
		carbs: .1,
		fat: 7.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-15",
		name: "גבינה צהובה עמק 15% - תנובה",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 73,
		protein: 8.1,
		carbs: .1,
		fat: 4.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-16",
		name: "גבינה צהובה עמק 9% - תנובה",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 58,
		protein: 8.8,
		carbs: .1,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-17",
		name: "גבינה צהובה גלבוע 22%",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 85,
		protein: 7.5,
		carbs: .1,
		fat: 6.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-18",
		name: "גבינת מותרת 5% שומן",
		category: "גבינות קשות",
		servingSize: "פרוסה (28g)",
		calories: 50,
		protein: 9,
		carbs: .2,
		fat: 1.4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-19",
		name: "גבינת מוצרלה מגוררת",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 280,
		protein: 22,
		carbs: 2,
		fat: 20,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-20",
		name: "גבינת מוצרלה לייט 15%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 210,
		protein: 24,
		carbs: 2,
		fat: 12,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-21",
		name: "גבינת בולגרית 5% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 110,
		protein: 15,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-22",
		name: "גבינת בולגרית 16% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 200,
		protein: 14,
		carbs: 1.5,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-23",
		name: "גבינת פטה עיזים 20%",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 240,
		protein: 14,
		carbs: 1,
		fat: 20,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-24",
		name: "גבינת צפתית 5% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 16,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-25",
		name: "לאבנה 9% - פיראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 9,
		carbs: 3,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-26",
		name: "לאבנה 5%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 95,
		protein: 9.5,
		carbs: 3,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-27",
		name: "גבינת שמנת נפוליאון 25%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 260,
		protein: 6,
		carbs: 3,
		fat: 25,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-28",
		name: "גבינת שמנת נפוליאון 16%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 7,
		carbs: 3.5,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-29",
		name: "יוגורט דנונה 3% ביו",
		category: "יוגורט",
		servingSize: "גביע (200g)",
		calories: 124,
		protein: 8,
		carbs: 9.2,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-30",
		name: "יוגורט דנונה 1.5% ביו",
		category: "יוגורט",
		servingSize: "גביע (200g)",
		calories: 96,
		protein: 8.4,
		carbs: 9.6,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-31",
		name: "יוגורט דנונה פרו 20g חלבון נקי",
		category: "יוגורט חלבון",
		servingSize: "גביע (200g)",
		calories: 120,
		protein: 20,
		carbs: 9,
		fat: .4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-32",
		name: "יוגורט דנונה פרו 20g תות",
		category: "יוגורט חלבון",
		servingSize: "גביע (200g)",
		calories: 150,
		protein: 20,
		carbs: 16,
		fat: .4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-33",
		name: "יוגורט דנונה פרו 20g וניל",
		category: "יוגורט חלבון",
		servingSize: "גביע (200g)",
		calories: 148,
		protein: 20,
		carbs: 15,
		fat: .4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-34",
		name: "יוגורט דנונה פרו 20g אפרסק",
		category: "יוגורט חלבון",
		servingSize: "גביע (200g)",
		calories: 152,
		protein: 20,
		carbs: 16.5,
		fat: .4,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-35",
		name: "יוגורט יווני 7% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 100,
		protein: 6,
		carbs: 3.5,
		fat: 7,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-36",
		name: "יוגורט יווני 2% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 62,
		protein: 8.5,
		carbs: 3.8,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-37",
		name: "יוגורט סקיר Yoplait טבעי",
		category: "יוגורט חלבון",
		servingSize: "100 גרם",
		calories: 65,
		protein: 11,
		carbs: 4,
		fat: .2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-38",
		name: "יוגורט Yoplait Pro 15g",
		category: "יוגורט חלבון",
		servingSize: "גביע (150g)",
		calories: 110,
		protein: 15,
		carbs: 11,
		fat: .3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט חלבון)"
	},
	{
		id: "f-israel-39",
		name: "מעדן GO 20g חלבון שוקולד",
		category: "מעדני חלבון",
		servingSize: "גביע (200g)",
		calories: 156,
		protein: 20,
		carbs: 14,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדני חלבון)"
	},
	{
		id: "f-israel-40",
		name: "מעדן GO 20g חלבון וניל",
		category: "מעדני חלבון",
		servingSize: "גביע (200g)",
		calories: 150,
		protein: 20,
		carbs: 13,
		fat: 1.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדני חלבון)"
	},
	{
		id: "f-israel-41",
		name: "מעדן GO 20g חלבון קפה",
		category: "מעדני חלבון",
		servingSize: "גביע (200g)",
		calories: 152,
		protein: 20,
		carbs: 13.5,
		fat: 1.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדני חלבון)"
	},
	{
		id: "f-israel-42",
		name: "מעדן מילקי שוקולד",
		category: "מעדנים",
		servingSize: "גביע (133g)",
		calories: 210,
		protein: 3.2,
		carbs: 24,
		fat: 11.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדנים)"
	},
	{
		id: "f-israel-43",
		name: "מעדן מילקי לייט 1%",
		category: "מעדנים",
		servingSize: "גביע (133g)",
		calories: 115,
		protein: 4,
		carbs: 18,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדנים)"
	},
	{
		id: "f-israel-44",
		name: "מעדן דני שוקולד",
		category: "מעדנים",
		servingSize: "גביע (125g)",
		calories: 135,
		protein: 3.5,
		carbs: 23,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מעדנים)"
	},
	{
		id: "f-israel-45",
		name: "גיל 3% - תנובה",
		category: "מוצרי חלב",
		servingSize: "גביע (170g)",
		calories: 100,
		protein: 5.5,
		carbs: 7,
		fat: 5.1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מוצרי חלב)"
	},
	{
		id: "f-israel-46",
		name: "אשל 4.5% - תנובה",
		category: "מוצרי חלב",
		servingSize: "גביע (200g)",
		calories: 136,
		protein: 6.2,
		carbs: 8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מוצרי חלב)"
	},
	{
		id: "f-israel-47",
		name: "שמנת חמוצה 15% - תנובה",
		category: "שמנת",
		servingSize: "100 גרם",
		calories: 160,
		protein: 2.8,
		carbs: 3.5,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-48",
		name: "שמנת חמוצה 9% - תנובה",
		category: "שמנת",
		servingSize: "100 גרם",
		calories: 108,
		protein: 3.2,
		carbs: 3.8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-49",
		name: "שמנת מתוקה 38% להקצפה",
		category: "שמנת",
		servingSize: "100 מ\"ל",
		calories: 360,
		protein: 2,
		carbs: 3,
		fat: 38,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-50",
		name: "שמנת לבישול 15% - השף הלבן",
		category: "שמנת",
		servingSize: "100 מ\"ל",
		calories: 160,
		protein: 3,
		carbs: 4,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-51",
		name: "שמנת לבישול 10% - השף הלבן",
		category: "שמנת",
		servingSize: "100 מ\"ל",
		calories: 118,
		protein: 3.2,
		carbs: 4.2,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנת)"
	},
	{
		id: "f-israel-52",
		name: "חמאה שופרסל / תנובה",
		category: "שומנים",
		servingSize: "10 גרם",
		calories: 74,
		protein: .1,
		carbs: .1,
		fat: 8.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שומנים)"
	},
	{
		id: "f-israel-53",
		name: "ריקוטה 5% - גד",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 100,
		protein: 11,
		carbs: 3.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-54",
		name: "גבינת חלומי 24%",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 320,
		protein: 20,
		carbs: 2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-55",
		name: "גבינת פרמזן מגוררת",
		category: "גבינות קשות",
		servingSize: "10 גרם",
		calories: 40,
		protein: 3.8,
		carbs: .4,
		fat: 2.6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות קשות)"
	},
	{
		id: "f-israel-56",
		name: "ביצה S (קטנה)",
		category: "ביצים",
		servingSize: "יחידה 1 (45g)",
		calories: 60,
		protein: 5.2,
		carbs: .4,
		fat: 4.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-57",
		name: "ביצה M (בינונית)",
		category: "ביצים",
		servingSize: "יחידה 1 (53g)",
		calories: 72,
		protein: 6.3,
		carbs: .5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-58",
		name: "ביצה L (גדולה)",
		category: "ביצים",
		servingSize: "יחידה 1 (63g)",
		calories: 85,
		protein: 7.5,
		carbs: .6,
		fat: 5.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-59",
		name: "ביצה XL (ענקית)",
		category: "ביצים",
		servingSize: "יחידה 1 (73g)",
		calories: 98,
		protein: 8.7,
		carbs: .7,
		fat: 6.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-60",
		name: "חלבון ביצה (חלבון בלבד)",
		category: "ביצים",
		servingSize: "100 גרם",
		calories: 52,
		protein: 11,
		carbs: .7,
		fat: .2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-61",
		name: "חלמון ביצה (חלמון בלבד)",
		category: "ביצים",
		servingSize: "יחידה 1 (17g)",
		calories: 55,
		protein: 2.7,
		carbs: .6,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-62",
		name: "ביצה קשה M",
		category: "ביצים",
		servingSize: "יחידה 1 (53g)",
		calories: 72,
		protein: 6.3,
		carbs: .5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ביצים)"
	},
	{
		id: "f-israel-63",
		name: "חזה עוף טרי (נא)",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 110,
		protein: 23.5,
		carbs: 0,
		fat: 1.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-64",
		name: "חזה עוף מבושל / בגריל",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 165,
		protein: 31,
		carbs: 0,
		fat: 3.6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-65",
		name: "פרגית עוף (ירך ללא עור)",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 175,
		protein: 24,
		carbs: 0,
		fat: 8.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-66",
		name: "כרעי עוף עם עור (מבושל)",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 235,
		protein: 24,
		carbs: 0,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-67",
		name: "כנפי עוף בגריל",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 220,
		protein: 22,
		carbs: 0,
		fat: 14.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-68",
		name: "שוקי עוף ללא עור",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 160,
		protein: 26,
		carbs: 0,
		fat: 5.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-69",
		name: "כבד עוף צלוי",
		category: "עוף ובשר",
		servingSize: "100 גרם",
		calories: 165,
		protein: 24.5,
		carbs: 1,
		fat: 6.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-70",
		name: "בשר בקר טחון רזה 5% שומן",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 135,
		protein: 21,
		carbs: 0,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-71",
		name: "בשר בקר טחון 12% שומן",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 185,
		protein: 19.5,
		carbs: 0,
		fat: 12,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-72",
		name: "בשר בקר טחון קלאסי 20%",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 250,
		protein: 17.5,
		carbs: 0,
		fat: 20,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-73",
		name: "סטייק אנטרקוט בגריל",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 270,
		protein: 25,
		carbs: 0,
		fat: 19,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-74",
		name: "סטייק סינטה בקר",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 170,
		protein: 27,
		carbs: 0,
		fat: 6.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-75",
		name: "סטייק שייטל בקר",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 155,
		protein: 28,
		carbs: 0,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-76",
		name: "כתף בקר מס' 5 מבושל",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 180,
		protein: 26,
		carbs: 0,
		fat: 8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-77",
		name: "צלי כתף מס' 4",
		category: "בקר",
		servingSize: "100 גרם",
		calories: 195,
		protein: 25,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (בקר)"
	},
	{
		id: "f-israel-78",
		name: "חזה הודו טרי",
		category: "הודו",
		servingSize: "100 גרם",
		calories: 105,
		protein: 24,
		carbs: 0,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (הודו)"
	},
	{
		id: "f-israel-79",
		name: "חזה הודו מבושל",
		category: "הודו",
		servingSize: "100 גרם",
		calories: 145,
		protein: 30,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (הודו)"
	},
	{
		id: "f-israel-80",
		name: "שווארמה הודו נקבה",
		category: "הודו",
		servingSize: "100 גרם",
		calories: 160,
		protein: 25,
		carbs: 0,
		fat: 6.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (הודו)"
	},
	{
		id: "f-israel-81",
		name: "פסטרמה חזה הודו דלת שומן 1%",
		category: "נקניקים",
		servingSize: "100 גרם",
		calories: 95,
		protein: 18,
		carbs: 2,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקים)"
	},
	{
		id: "f-israel-82",
		name: "פסטרמה בדבש 2%",
		category: "נקניקים",
		servingSize: "100 גרם",
		calories: 105,
		protein: 17,
		carbs: 4,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקים)"
	},
	{
		id: "f-israel-83",
		name: "פסטרמה מעושנת 3%",
		category: "נקניקים",
		servingSize: "100 גרם",
		calories: 110,
		protein: 17,
		carbs: 2.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקים)"
	},
	{
		id: "f-israel-84",
		name: "נקניק סלמי איטלקי",
		category: "נקניקים",
		servingSize: "100 גרם",
		calories: 380,
		protein: 16,
		carbs: 1.5,
		fat: 34,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקים)"
	},
	{
		id: "f-israel-85",
		name: "נקניקיות עוף - זוגלובק",
		category: "נקניקיות",
		servingSize: "יחידה (40g)",
		calories: 95,
		protein: 4.5,
		carbs: 2.5,
		fat: 7.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקיות)"
	},
	{
		id: "f-israel-86",
		name: "נקניקיות ביס עוף",
		category: "נקניקיות",
		servingSize: "100 גרם",
		calories: 240,
		protein: 11,
		carbs: 6,
		fat: 19,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (נקניקיות)"
	},
	{
		id: "f-israel-87",
		name: "המבורגר בקר קפוא (שמיר/טיבון)",
		category: "מוצרים קפואים",
		servingSize: "יחידה (100g)",
		calories: 240,
		protein: 16,
		carbs: 2,
		fat: 19,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מוצרים קפואים)"
	},
	{
		id: "f-israel-88",
		name: "שניצל עוף ביתי מצופה פירורים",
		category: "עוף ובשר",
		servingSize: "יחידה (120g)",
		calories: 260,
		protein: 22,
		carbs: 18,
		fat: 11,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (עוף ובשר)"
	},
	{
		id: "f-israel-89",
		name: "שניצל עוף מוכן קפוא (מאמא עוף)",
		category: "מוצרים קפואים",
		servingSize: "יחידה (100g)",
		calories: 220,
		protein: 14,
		carbs: 16,
		fat: 11,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (מוצרים קפואים)"
	},
	{
		id: "f-israel-90",
		name: "קופסת טונה במים (מסונן)",
		category: "דגים",
		servingSize: "קופסה (112g)",
		calories: 120,
		protein: 26,
		carbs: 0,
		fat: 1.2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-91",
		name: "קופסת טונה בשמן צמחי (מסונן)",
		category: "דגים",
		servingSize: "קופסה (112g)",
		calories: 190,
		protein: 25,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-92",
		name: "טונה בשמן זית (מסונן)",
		category: "דגים",
		servingSize: "קופסה (112g)",
		calories: 200,
		protein: 25,
		carbs: 0,
		fat: 11,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-93",
		name: "פילה סלמון טרי (נא)",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 208,
		protein: 20,
		carbs: 0,
		fat: 13,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-94",
		name: "פילה סלמון בתנור",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 230,
		protein: 23,
		carbs: 0,
		fat: 14.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-95",
		name: "סלמון מעושן (סלמון מעושן פרוס)",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 180,
		protein: 22,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-96",
		name: "פילה אמנון (מושט) בתנור",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 128,
		protein: 23,
		carbs: 0,
		fat: 3.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-97",
		name: "פילה דניס בתנור",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 160,
		protein: 20,
		carbs: 0,
		fat: 8.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-98",
		name: "פילה לברק בתנור",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 145,
		protein: 21,
		carbs: 0,
		fat: 6.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-99",
		name: "סרדינים בשמן (מקופסה)",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 210,
		protein: 24,
		carbs: 0,
		fat: 12,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-100",
		name: "מקרל מעושן",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 260,
		protein: 20,
		carbs: 0,
		fat: 20,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-101",
		name: "פילה נסיכת הנילוס",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 95,
		protein: 19,
		carbs: 0,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-102",
		name: "קוד / סול אפוי",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 90,
		protein: 19,
		carbs: 0,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-103",
		name: "אצבעות דג מצופות (דגיתון)",
		category: "דגים",
		servingSize: "100 גרם",
		calories: 210,
		protein: 12,
		carbs: 18,
		fat: 10,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגים)"
	},
	{
		id: "f-israel-104",
		name: "אדממה / Edamame (תרמילי סויה)",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 121,
		protein: 11.9,
		carbs: 8.9,
		fat: 5.2,
		fiber: 5.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-105",
		name: "אדממה קלוף קפוא",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 12.5,
		carbs: 9.5,
		fat: 5.5,
		fiber: 5.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-106",
		name: "טופו קלאסי - תנובה / אדמה",
		category: "תחליפי בשר",
		servingSize: "100 גרם",
		calories: 140,
		protein: 14,
		carbs: 2.5,
		fat: 8.5,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-107",
		name: "טופו במרקם רך (סילקן)",
		category: "תחליפי בשר",
		servingSize: "100 גרם",
		calories: 60,
		protein: 6.5,
		carbs: 1.8,
		fat: 2.8,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-108",
		name: "שבבי סויה יבשים (בונזואל)",
		category: "תחליפי בשר",
		servingSize: "100 גרם",
		calories: 330,
		protein: 50,
		carbs: 30,
		fat: 1.2,
		fiber: 18,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-109",
		name: "טבעול שניצל תירס",
		category: "תחליפי בשר",
		servingSize: "יחידה (100g)",
		calories: 210,
		protein: 7.5,
		carbs: 24,
		fat: 9.5,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-110",
		name: "טבעול שניצל צמחוני קלאסי",
		category: "תחליפי בשר",
		servingSize: "יחידה (100g)",
		calories: 190,
		protein: 13,
		carbs: 14,
		fat: 9,
		fiber: 4.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-111",
		name: "בורגר סויה Sensational / Beyond",
		category: "תחליפי בשר",
		servingSize: "יחידה (113g)",
		calories: 250,
		protein: 19,
		carbs: 5,
		fat: 17,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי בשר)"
	},
	{
		id: "f-israel-112",
		name: "אורז לבן מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 2.5,
		carbs: 28,
		fat: .3,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-113",
		name: "אורז בסמטי מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 2.6,
		carbs: 27,
		fat: .4,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-114",
		name: "אורז יסמין מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 2.4,
		carbs: 28.5,
		fat: .3,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-115",
		name: "אורז מלא מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 112,
		protein: 2.6,
		carbs: 23.5,
		fat: .9,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-116",
		name: "אורז אדום / שחור מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 2.8,
		carbs: 24,
		fat: .8,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-117",
		name: "פסטה לבנה מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 5.8,
		carbs: 31,
		fat: .9,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-118",
		name: "פסטה מקמח מלא מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 140,
		protein: 6.2,
		carbs: 27,
		fat: 1.2,
		fiber: 4.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-119",
		name: "פסטה כוסמין מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 145,
		protein: 6,
		carbs: 28,
		fat: 1.1,
		fiber: 3.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-120",
		name: "קוסקוס מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 112,
		protein: 3.8,
		carbs: 23,
		fat: .2,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-121",
		name: "קוסקוס מלא מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 118,
		protein: 4.2,
		carbs: 23.5,
		fat: .6,
		fiber: 3.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-122",
		name: "בורגול מבושל",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 83,
		protein: 3.1,
		carbs: 18.5,
		fat: .2,
		fiber: 4.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-123",
		name: "קינואה מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 120,
		protein: 4.4,
		carbs: 21,
		fat: 1.9,
		fiber: 2.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-124",
		name: "כוסמת ירוקה / קלויה מבושלת",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 92,
		protein: 3.4,
		carbs: 19.8,
		fat: .6,
		fiber: 2.7,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-125",
		name: "שיבולת שועל להכנה מהירה (קוואקר)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 389,
		protein: 17,
		carbs: 66,
		fat: 7,
		fiber: 10,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-126",
		name: "קוואקר - מנה מדודה",
		category: "דגנים ופחמימות",
		servingSize: "כף גדושה (15g)",
		calories: 58,
		protein: 2.5,
		carbs: 9.9,
		fat: 1,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-127",
		name: "פתיתים אפויים מבושלים",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 150,
		protein: 5,
		carbs: 30,
		fat: .8,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-128",
		name: "תפוחי אדמה אפויים / מבושלים",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 87,
		protein: 1.9,
		carbs: 20,
		fat: .1,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-129",
		name: "פירה תפוחי אדמה עם חלב וחמאה",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 110,
		protein: 2,
		carbs: 17,
		fat: 4.2,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-130",
		name: "בטטה אפויה בתנור",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 90,
		protein: 2,
		carbs: 21,
		fat: .2,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-131",
		name: "תירס מתוק מקופסה (מסונן)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 80,
		protein: 2.8,
		carbs: 16,
		fat: 1.2,
		fiber: 2.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-132",
		name: "קלח תירס מבושל",
		category: "דגנים ופחמימות",
		servingSize: "יחידה בינונית (100g)",
		calories: 96,
		protein: 3.4,
		carbs: 21,
		fat: 1.5,
		fiber: 2.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-133",
		name: "לחם אחיד פרוס (אנג'ל / ברמן)",
		category: "לחמים",
		servingSize: "פרוסה (35g)",
		calories: 82,
		protein: 3,
		carbs: 15.5,
		fat: .7,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-134",
		name: "לחם מקמח חיטה מלאה 100%",
		category: "לחמים",
		servingSize: "פרוסה (35g)",
		calories: 75,
		protein: 3.8,
		carbs: 13,
		fat: .8,
		fiber: 2.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-135",
		name: "לחם כוסמין 100%",
		category: "לחמים",
		servingSize: "פרוסה (35g)",
		calories: 78,
		protein: 3.9,
		carbs: 13.5,
		fat: .9,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-136",
		name: "לחם קל (אנג'ל/ברמן)",
		category: "לחמים",
		servingSize: "פרוסה (25g)",
		calories: 45,
		protein: 2.2,
		carbs: 8,
		fat: .4,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-137",
		name: "לחם מחמצת כפרי",
		category: "לחמים",
		servingSize: "פרוסה (40g)",
		calories: 100,
		protein: 3.8,
		carbs: 19,
		fat: .8,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-138",
		name: "פיתה קלאסית מקמח לבן",
		category: "לחמים",
		servingSize: "יחידה (100g)",
		calories: 260,
		protein: 9,
		carbs: 53,
		fat: 1.2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-139",
		name: "פיתה מקמח מלא",
		category: "לחמים",
		servingSize: "יחידה (100g)",
		calories: 235,
		protein: 10,
		carbs: 46,
		fat: 1.5,
		fiber: 6,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-140",
		name: "פיתה כוסמין קלה",
		category: "לחמים",
		servingSize: "יחידה (60g)",
		calories: 125,
		protein: 6.5,
		carbs: 22,
		fat: .8,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-141",
		name: "פיתה ביס / פיתה קטנה",
		category: "לחמים",
		servingSize: "יחידה (50g)",
		calories: 130,
		protein: 4.5,
		carbs: 26.5,
		fat: .6,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-142",
		name: "לחמנייה מתוקה / לחמניית המבורגר",
		category: "לחמים",
		servingSize: "יחידה (80g)",
		calories: 230,
		protein: 7,
		carbs: 43,
		fat: 3.5,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-143",
		name: "לחמנייה קלה מקמח מלא",
		category: "לחמים",
		servingSize: "יחידה (60g)",
		calories: 115,
		protein: 6,
		carbs: 20,
		fat: 1,
		fiber: 5.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-144",
		name: "טורטייה חיטה (מאסטר שף / שופרסל)",
		category: "לחמים",
		servingSize: "יחידה (45g)",
		calories: 135,
		protein: 3.6,
		carbs: 23,
		fat: 3,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-145",
		name: "טורטייה מקמח מלא",
		category: "לחמים",
		servingSize: "יחידה (45g)",
		calories: 125,
		protein: 4,
		carbs: 21,
		fat: 2.8,
		fiber: 3.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (לחמים)"
	},
	{
		id: "f-israel-146",
		name: "פריכיות אורז חום קלאסיות",
		category: "תחליפי לחם",
		servingSize: "יחידה (8g)",
		calories: 30,
		protein: .7,
		carbs: 6.3,
		fat: .2,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-147",
		name: "פריכיות אורז עם מלח ים",
		category: "תחליפי לחם",
		servingSize: "יחידה (8g)",
		calories: 30,
		protein: .7,
		carbs: 6.3,
		fat: .2,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-148",
		name: "פריכיות תירס קראנצ'",
		category: "תחליפי לחם",
		servingSize: "יחידה (7g)",
		calories: 26,
		protein: .6,
		carbs: 5.6,
		fat: .2,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-149",
		name: "פריכיות כוסמין מלא",
		category: "תחליפי לחם",
		servingSize: "יחידה (8g)",
		calories: 29,
		protein: .9,
		carbs: 5.8,
		fat: .2,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-150",
		name: "פריכיות דקות / מיני פריכיות",
		category: "תחליפי לחם",
		servingSize: "יחידה (3g)",
		calories: 11,
		protein: .3,
		carbs: 2.3,
		fat: .1,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-151",
		name: "פתית זהב קלאסי (מאסטר שף)",
		category: "תחליפי לחם",
		servingSize: "פרוסה (7g)",
		calories: 26,
		protein: .8,
		carbs: 5.2,
		fat: .2,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-152",
		name: "קרקר זהב / קרקר דגנים",
		category: "תחליפי לחם",
		servingSize: "יחידה (10g)",
		calories: 42,
		protein: 1,
		carbs: 6.5,
		fat: 1.3,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (תחליפי לחם)"
	},
	{
		id: "f-israel-153",
		name: "בייגלה שמיניות (אסם)",
		category: "חטיפים",
		servingSize: "100 גרם",
		calories: 380,
		protein: 10,
		carbs: 75,
		fat: 3.5,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-154",
		name: "בייגלה שטוחים (אסם)",
		category: "חטיפים",
		servingSize: "100 גרם",
		calories: 390,
		protein: 10.5,
		carbs: 76,
		fat: 4,
		fiber: 3.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-155",
		name: "דגני בוקר קורנפלקס תלמה",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 370,
		protein: 7.5,
		carbs: 84,
		fat: .8,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-156",
		name: "דגני בוקר כריות שוקולד (תלמה)",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 450,
		protein: 6,
		carbs: 72,
		fat: 15,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-157",
		name: "דגני בוקר צ'יריוס דבש ואגוזים",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 385,
		protein: 7,
		carbs: 78,
		fat: 4.5,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-158",
		name: "דגני בוקר פיטנס טבעי (נסטלה)",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 365,
		protein: 9,
		carbs: 74,
		fat: 2,
		fiber: 7,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-159",
		name: "גרנולה ביתית / דגנים מלאים עם אגוזים",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 440,
		protein: 11,
		carbs: 58,
		fat: 17,
		fiber: 8,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-160",
		name: "גרנולה ללא תוספת סוכר",
		category: "דגני בוקר",
		servingSize: "100 גרם",
		calories: 390,
		protein: 13,
		carbs: 52,
		fat: 14,
		fiber: 10,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגני בוקר)"
	},
	{
		id: "f-israel-161",
		name: "עדשים ירוקות / חומות מבושלות",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 116,
		protein: 9,
		carbs: 20,
		fat: .4,
		fiber: 7.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-162",
		name: "עדשים אדומות מבושלות",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 8.8,
		carbs: 19.5,
		fat: .4,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-163",
		name: "גרגירי חומוס מבושלים",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 164,
		protein: 8.9,
		carbs: 27,
		fat: 2.6,
		fiber: 7.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-164",
		name: "גרגירי חומוס מוקפאים (סנפרוסט)",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 150,
		protein: 8.2,
		carbs: 24,
		fat: 2.2,
		fiber: 7,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-165",
		name: "שעועית לבנה מבושלת",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 127,
		protein: 8.7,
		carbs: 22.8,
		fat: .5,
		fiber: 6.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-166",
		name: "שעועית אדומה מבושלת",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 8.5,
		carbs: 22.5,
		fat: .5,
		fiber: 6.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-167",
		name: "אפונה ירוקה מבושלת (סנפרוסט)",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 81,
		protein: 5.4,
		carbs: 14.5,
		fat: .4,
		fiber: 5.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-168",
		name: "תורמוס מבושל",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 119,
		protein: 15.5,
		carbs: 10,
		fat: 2.8,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-169",
		name: "פול מבושל",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 110,
		protein: 7.6,
		carbs: 19.5,
		fat: .4,
		fiber: 5.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-170",
		name: "עדשים שחורות (בלוגה) מבושלות",
		category: "קטניות",
		servingSize: "100 גרם",
		calories: 120,
		protein: 9.2,
		carbs: 20,
		fat: .5,
		fiber: 8,
		notes: "מוצר מזון מרשתות השיווק בישראל (קטניות)"
	},
	{
		id: "f-israel-171",
		name: "תפוח עץ בינוני (עם קליפה)",
		category: "פירות",
		servingSize: "יחידה (150g)",
		calories: 80,
		protein: .4,
		carbs: 21,
		fat: .3,
		fiber: 3.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-172",
		name: "בננה בינונית",
		category: "פירות",
		servingSize: "יחידה (120g)",
		calories: 105,
		protein: 1.3,
		carbs: 27,
		fat: .3,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-173",
		name: "תפוז בינוני",
		category: "פירות",
		servingSize: "יחידה (150g)",
		calories: 65,
		protein: 1.3,
		carbs: 16,
		fat: .2,
		fiber: 3.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-174",
		name: "קלמנטינה",
		category: "פירות",
		servingSize: "יחידה (85g)",
		calories: 40,
		protein: .7,
		carbs: 10,
		fat: .1,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-175",
		name: "אשכולית אדומה",
		category: "פירות",
		servingSize: "חצי יחידה (120g)",
		calories: 50,
		protein: .9,
		carbs: 12,
		fat: .1,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-176",
		name: "תות שדה טרי",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 32,
		protein: .7,
		carbs: 7.7,
		fat: .3,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-177",
		name: "ענבים ירוקים / אדומים",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 69,
		protein: .7,
		carbs: 18,
		fat: .2,
		fiber: .9,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-178",
		name: "אבטיח מתוק",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 30,
		protein: .6,
		carbs: 7.5,
		fat: .1,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-179",
		name: "מלון צהוב",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 34,
		protein: .8,
		carbs: 8.2,
		fat: .2,
		fiber: .9,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-180",
		name: "אפרסק טרי",
		category: "פירות",
		servingSize: "יחידה (130g)",
		calories: 50,
		protein: 1.2,
		carbs: 12,
		fat: .3,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-181",
		name: "נקטרינה",
		category: "פירות",
		servingSize: "יחידה (130g)",
		calories: 55,
		protein: 1.4,
		carbs: 13,
		fat: .4,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-182",
		name: "שזיף אדום / צהוב",
		category: "פירות",
		servingSize: "יחידה (60g)",
		calories: 30,
		protein: .4,
		carbs: 7.5,
		fat: .2,
		fiber: .9,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-183",
		name: "אגס בינוני",
		category: "פירות",
		servingSize: "יחידה (150g)",
		calories: 85,
		protein: .6,
		carbs: 23,
		fat: .2,
		fiber: 4.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-184",
		name: "תמר מג'הול עסיסי",
		category: "פירות יבשים",
		servingSize: "יחידה 1 (24g)",
		calories: 66,
		protein: .4,
		carbs: 18,
		fat: .1,
		fiber: 1.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-185",
		name: "תמר דקל נור",
		category: "פירות יבשים",
		servingSize: "יחידה 1 (10g)",
		calories: 28,
		protein: .2,
		carbs: 7.5,
		fat: 0,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-186",
		name: "מנגו מתוק",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 60,
		protein: .8,
		carbs: 15,
		fat: .4,
		fiber: 1.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-187",
		name: "אננס טרי",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 50,
		protein: .5,
		carbs: 13,
		fat: .1,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-188",
		name: "קיווי",
		category: "פירות",
		servingSize: "יחידה (70g)",
		calories: 42,
		protein: .8,
		carbs: 10,
		fat: .4,
		fiber: 2.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-189",
		name: "דובדבנים מתוקים",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 63,
		protein: 1.1,
		carbs: 16,
		fat: .2,
		fiber: 2.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-190",
		name: "אבוקדו היל / חס",
		category: "פירות / שומנים",
		servingSize: "חצי אבוקדו (75g)",
		calories: 120,
		protein: 1.5,
		carbs: 6,
		fat: 11,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות / שומנים)"
	},
	{
		id: "f-israel-191",
		name: "רימון (גרגרים)",
		category: "פירות",
		servingSize: "100 גרם",
		calories: 83,
		protein: 1.7,
		carbs: 18.7,
		fat: 1.2,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-192",
		name: "תאנה טרייה",
		category: "פירות",
		servingSize: "יחידה (50g)",
		calories: 37,
		protein: .4,
		carbs: 9.5,
		fat: .1,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-193",
		name: "אפרסמון",
		category: "פירות",
		servingSize: "יחידה (120g)",
		calories: 84,
		protein: .7,
		carbs: 21,
		fat: .2,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-194",
		name: "משמש טרי",
		category: "פירות",
		servingSize: "יחידה (35g)",
		calories: 17,
		protein: .5,
		carbs: 3.9,
		fat: .1,
		fiber: .7,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-195",
		name: "חמוציות מיובשות ללא סוכר",
		category: "פירות יבשים",
		servingSize: "30 גרם",
		calories: 92,
		protein: .1,
		carbs: 24,
		fat: .4,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-196",
		name: "צימוקים כהים / בהירים",
		category: "פירות יבשים",
		servingSize: "30 גרם",
		calories: 90,
		protein: .9,
		carbs: 23,
		fat: .1,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-197",
		name: "שזיפים מיובשים",
		category: "פירות יבשים",
		servingSize: "יחידה 1 (10g)",
		calories: 24,
		protein: .2,
		carbs: 6.3,
		fat: 0,
		fiber: .7,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-198",
		name: "משמש מיובש",
		category: "פירות יבשים",
		servingSize: "יחידה 1 (8g)",
		calories: 20,
		protein: .3,
		carbs: 5,
		fat: 0,
		fiber: .6,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות יבשים)"
	},
	{
		id: "f-israel-199",
		name: "מלפפון טרי עם קליפה",
		category: "ירקות",
		servingSize: "יחידה (100g)",
		calories: 15,
		protein: .7,
		carbs: 3.6,
		fat: .1,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-200",
		name: "עגבנייה טרייה",
		category: "ירקות",
		servingSize: "יחידה (120g)",
		calories: 22,
		protein: 1.1,
		carbs: 4.8,
		fat: .2,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-201",
		name: "עגבניות שרי",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 18,
		protein: .9,
		carbs: 3.9,
		fat: .2,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-202",
		name: "גזר טרי",
		category: "ירקות",
		servingSize: "יחידה (80g)",
		calories: 33,
		protein: .7,
		carbs: 7.6,
		fat: .2,
		fiber: 2.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-203",
		name: "פלפל אדום (גמבה)",
		category: "ירקות",
		servingSize: "יחידה (150g)",
		calories: 40,
		protein: 1.5,
		carbs: 9,
		fat: .3,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-204",
		name: "פלפל ירוק / צהוב",
		category: "ירקות",
		servingSize: "יחידה (150g)",
		calories: 30,
		protein: 1.2,
		carbs: 7,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-205",
		name: "קישוא טרי / מבושל",
		category: "ירקות",
		servingSize: "יחידה (120g)",
		calories: 20,
		protein: 1.4,
		carbs: 3.8,
		fat: .4,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-206",
		name: "חציל קלוי / אפוי ללא שמן",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 25,
		protein: 1,
		carbs: 5.8,
		fat: .2,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-207",
		name: "כרוב לבן קצוץ",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 25,
		protein: 1.3,
		carbs: 5.8,
		fat: .1,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-208",
		name: "כרוב אדום קצוץ",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 31,
		protein: 1.4,
		carbs: 7.4,
		fat: .2,
		fiber: 2.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-209",
		name: "חסה ערבית / מסולסלת",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 15,
		protein: 1.4,
		carbs: 2.9,
		fat: .2,
		fiber: 1.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-210",
		name: "עלי תרד טריים",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 23,
		protein: 2.9,
		carbs: 3.6,
		fat: .4,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-211",
		name: "ברוקולי מבושל / בקיטור",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 35,
		protein: 2.4,
		carbs: 7,
		fat: .4,
		fiber: 3.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-212",
		name: "כרובית אפויה / מבושלת",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 25,
		protein: 1.9,
		carbs: 5,
		fat: .3,
		fiber: 2.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-213",
		name: "בצל צהוב / סגול",
		category: "ירקות",
		servingSize: "יחידה (100g)",
		calories: 40,
		protein: 1.1,
		carbs: 9.3,
		fat: .1,
		fiber: 1.7,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-214",
		name: "בצל ירוק",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 32,
		protein: 1.8,
		carbs: 7.3,
		fat: .2,
		fiber: 2.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-215",
		name: "שום טרי",
		category: "ירקות",
		servingSize: "שן שום (3g)",
		calories: 4,
		protein: .2,
		carbs: 1,
		fat: 0,
		fiber: .1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-216",
		name: "פטריות שמפיניון טריות",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 22,
		protein: 3.1,
		carbs: 3.3,
		fat: .3,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-217",
		name: "פטריות פורטבלו בגריל",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 28,
		protein: 2.5,
		carbs: 4.5,
		fat: .5,
		fiber: 1.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-218",
		name: "צנונית טרייה",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 16,
		protein: .7,
		carbs: 3.4,
		fat: .1,
		fiber: 1.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-219",
		name: "דלעת אפויה",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 26,
		protein: 1,
		carbs: 6.5,
		fat: .1,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-220",
		name: "דלורית אפויה בתנור",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 45,
		protein: 1,
		carbs: 11.5,
		fat: .1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-221",
		name: "סלק אדום מבושל",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 43,
		protein: 1.6,
		carbs: 9.6,
		fat: .2,
		fiber: 2.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-222",
		name: "עשבי תיבול (פטרוזיליה/כוסברה/שמיר)",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 36,
		protein: 3,
		carbs: 6.3,
		fat: .8,
		fiber: 3.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-223",
		name: "נבטים סיניים",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 30,
		protein: 3,
		carbs: 5.9,
		fat: .2,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-224",
		name: "סלרי (גבעולים)",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 14,
		protein: .7,
		carbs: 3,
		fat: .2,
		fiber: 1.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-225",
		name: "שעועית ירוקה מבושלת (סנפרוסט)",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 31,
		protein: 1.8,
		carbs: 7,
		fat: .2,
		fiber: 3.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-226",
		name: "שעועית צהובה מבושלת",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 31,
		protein: 1.8,
		carbs: 7,
		fat: .2,
		fiber: 3.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-227",
		name: "לקט ירקות לנורמנדי (סנפרוסט)",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 30,
		protein: 2,
		carbs: 5.5,
		fat: .3,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-228",
		name: "לקט ירקות מוקפצים",
		category: "ירקות",
		servingSize: "100 גרם",
		calories: 35,
		protein: 1.8,
		carbs: 6.5,
		fat: .3,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ירקות)"
	},
	{
		id: "f-israel-229",
		name: "שקדים טבעיים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 175,
		protein: 6.3,
		carbs: 6,
		fat: 15,
		fiber: 3.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-230",
		name: "שקדים מולבנים / פרוסים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 175,
		protein: 6.3,
		carbs: 6,
		fat: 15,
		fiber: 3.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-231",
		name: "אגוזי מלך קלופים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 195,
		protein: 4.5,
		carbs: 4,
		fat: 19.5,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-232",
		name: "אגוזי קשיו טבעיים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 165,
		protein: 5.5,
		carbs: 9,
		fat: 13,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-233",
		name: "בוטנים קלויים / טבעיים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 170,
		protein: 7.5,
		carbs: 5,
		fat: 14,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-234",
		name: "פיסטוקים קלויים ומומלחים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 168,
		protein: 6,
		carbs: 8,
		fat: 13.5,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-235",
		name: "אגוזי לוז (בונדוק)",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 188,
		protein: 4.2,
		carbs: 5,
		fat: 18,
		fiber: 2.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-236",
		name: "אגוזי פקאן טבעיים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 205,
		protein: 2.7,
		carbs: 4,
		fat: 21,
		fiber: 2.7,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-237",
		name: "אגוזי ברזיל",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 200,
		protein: 4.3,
		carbs: 3.5,
		fat: 20,
		fiber: 2.3,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-238",
		name: "גרעיני חמנייה קלופים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 175,
		protein: 6.2,
		carbs: 6,
		fat: 15,
		fiber: 2.6,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-239",
		name: "גרעיני דלעת קלופים",
		category: "אגוזים וגרעינים",
		servingSize: "30 גרם",
		calories: 168,
		protein: 9,
		carbs: 4.5,
		fat: 14,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-240",
		name: "שומשום מלא / לבן",
		category: "אגוזים וגרעינים",
		servingSize: "כף (10g)",
		calories: 57,
		protein: 1.8,
		carbs: 2.3,
		fat: 5,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-241",
		name: "זרעי צ'יה",
		category: "אגוזים וגרעינים",
		servingSize: "כף (12g)",
		calories: 58,
		protein: 2,
		carbs: 5,
		fat: 3.7,
		fiber: 4.1,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-242",
		name: "זרעי פשתן טחונים",
		category: "אגוזים וגרעינים",
		servingSize: "כף (10g)",
		calories: 53,
		protein: 1.8,
		carbs: 3,
		fat: 4.2,
		fiber: 2.7,
		notes: "מוצר מזון מרשתות השיווק בישראל (אגוזים וגרעינים)"
	},
	{
		id: "f-israel-243",
		name: "חמאת בוטנים טבעית 100%",
		category: "ממרחים",
		servingSize: "כף (16g)",
		calories: 95,
		protein: 4,
		carbs: 3,
		fat: 8,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-244",
		name: "חמאת בוטנים סקיפי עם שבבים",
		category: "ממרחים",
		servingSize: "כף (16g)",
		calories: 98,
		protein: 3.5,
		carbs: 4,
		fat: 8,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-245",
		name: "טחינה גולמית משומשום מלא (הנסיך/אל ארז)",
		category: "ממרחים",
		servingSize: "כף (15g)",
		calories: 98,
		protein: 3.8,
		carbs: 1.8,
		fat: 8.8,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-246",
		name: "טחינה גולמית קלאסית",
		category: "ממרחים",
		servingSize: "כף (15g)",
		calories: 100,
		protein: 3.5,
		carbs: 2,
		fat: 9,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-247",
		name: "טחינה מוכנה למאכל (צבר / אחלה)",
		category: "ממרחים",
		servingSize: "כף (15g)",
		calories: 45,
		protein: 1.2,
		carbs: 1,
		fat: 4.2,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-248",
		name: "חומוס אחלה / צבר קלאסי",
		category: "ממרחים",
		servingSize: "כף (30g)",
		calories: 70,
		protein: 2.1,
		carbs: 4.2,
		fat: 5,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-249",
		name: "חומוס דל שומן 9%",
		category: "ממרחים",
		servingSize: "כף (30g)",
		calories: 48,
		protein: 2.2,
		carbs: 4.5,
		fat: 2.7,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-250",
		name: "ממרח אבוקדו מוכן",
		category: "ממרחים",
		servingSize: "כף (20g)",
		calories: 32,
		protein: .4,
		carbs: 1.6,
		fat: 2.8,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-251",
		name: "שמן זית כתית מעולה",
		category: "שמנים",
		servingSize: "כף (10 מ\"ל)",
		calories: 88,
		protein: 0,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנים)"
	},
	{
		id: "f-israel-252",
		name: "שמן קנולה / חמניות",
		category: "שמנים",
		servingSize: "כף (10 מ\"ל)",
		calories: 88,
		protein: 0,
		carbs: 0,
		fat: 10,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנים)"
	},
	{
		id: "f-israel-253",
		name: "תרסיס שמן קנולה / זית",
		category: "שמנים",
		servingSize: "ריסוס (1g)",
		calories: 9,
		protein: 0,
		carbs: 0,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שמנים)"
	},
	{
		id: "f-israel-254",
		name: "מיונז קלאסי (הלמנס / תלמה)",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 100,
		protein: .2,
		carbs: .5,
		fat: 11,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-255",
		name: "מיונז הלמנס לייטאקטיב 5% / 9%",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 25,
		protein: .2,
		carbs: 1.5,
		fat: 2,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-256",
		name: "קטשופ אסם קלאסי",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 17,
		protein: .2,
		carbs: 4,
		fat: 0,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-257",
		name: "קטשופ אסם ללא תוספת סוכר",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 8,
		protein: .2,
		carbs: 1.8,
		fat: 0,
		fiber: .3,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-258",
		name: "חרדל דיז'ון / צהוב",
		category: "רוטבים",
		servingSize: "כפית (5g)",
		calories: 5,
		protein: .3,
		carbs: .3,
		fat: .3,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-259",
		name: "רוטב סויה דל נתרן (קיקומן)",
		category: "רוטבים",
		servingSize: "כף (15 מ\"ל)",
		calories: 10,
		protein: 1.2,
		carbs: 1,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-260",
		name: "רוטב צ'ילי מתוק",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 32,
		protein: .1,
		carbs: 8,
		fat: 0,
		fiber: .1,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-261",
		name: "רוטב ברבקיו",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 25,
		protein: .2,
		carbs: 6,
		fat: .1,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-262",
		name: "רוטב אלף האיים לייט",
		category: "רוטבים",
		servingSize: "כף (15g)",
		calories: 30,
		protein: .2,
		carbs: 3,
		fat: 2,
		fiber: .1,
		notes: "מוצר מזון מרשתות השיווק בישראל (רוטבים)"
	},
	{
		id: "f-israel-263",
		name: "סילאן טבעי 100% תמרים",
		category: "ממתיקים",
		servingSize: "כף (20g)",
		calories: 60,
		protein: .4,
		carbs: 14.5,
		fat: 0,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממתיקים)"
	},
	{
		id: "f-israel-264",
		name: "דבש טבעי (יד מרדכי)",
		category: "ממתיקים",
		servingSize: "כף (20g)",
		calories: 64,
		protein: .1,
		carbs: 16,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממתיקים)"
	},
	{
		id: "f-israel-265",
		name: "ממרח השחר העולה",
		category: "ממרחים",
		servingSize: "כף (20g)",
		calories: 110,
		protein: .6,
		carbs: 12.5,
		fat: 6.5,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-266",
		name: "ממרח נוטלה",
		category: "ממרחים",
		servingSize: "כף (20g)",
		calories: 108,
		protein: 1.2,
		carbs: 11.5,
		fat: 6.2,
		fiber: .7,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-267",
		name: "ממרח לוטוס",
		category: "ממרחים",
		servingSize: "כף (20g)",
		calories: 115,
		protein: .6,
		carbs: 11.5,
		fat: 7.5,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (ממרחים)"
	},
	{
		id: "f-israel-268",
		name: "אבקת חלבון מי גבינה WHEY",
		category: "תוספי תזונה",
		servingSize: "כף מדידה (30g)",
		calories: 120,
		protein: 24,
		carbs: 2,
		fat: 1.8,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (תוספי תזונה)"
	},
	{
		id: "f-israel-269",
		name: "אבקת חלבון איסולייט ISO",
		category: "תוספי תזונה",
		servingSize: "כף מדידה (30g)",
		calories: 110,
		protein: 27,
		carbs: .5,
		fat: .5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (תוספי תזונה)"
	},
	{
		id: "f-israel-270",
		name: "אבקת חלבון טבעונית (סויה/אפונה)",
		category: "תוספי תזונה",
		servingSize: "כף מדידה (30g)",
		calories: 115,
		protein: 23,
		carbs: 2.5,
		fat: 1.5,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (תוספי תזונה)"
	},
	{
		id: "f-israel-271",
		name: "חטיף חלבון Allin קראנצ' 20g",
		category: "חטיפי חלבון",
		servingSize: "חטיף (60g)",
		calories: 210,
		protein: 20,
		carbs: 18,
		fat: 7,
		fiber: 8,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-272",
		name: "חטיף חלבון Barebells 20g",
		category: "חטיפי חלבון",
		servingSize: "חטיף (55g)",
		calories: 200,
		protein: 20,
		carbs: 16,
		fat: 8,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-273",
		name: "חטיף חלבון Ninja 20g",
		category: "חטיפי חלבון",
		servingSize: "חטיף (60g)",
		calories: 215,
		protein: 20,
		carbs: 19,
		fat: 7.5,
		fiber: 6,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-274",
		name: "חטיף חלבון Pro 20g - שטראוס",
		category: "חטיפי חלבון",
		servingSize: "חטיף (60g)",
		calories: 205,
		protein: 20,
		carbs: 17,
		fat: 6.8,
		fiber: 5,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-275",
		name: "חטיף חלבון Quest Bar",
		category: "חטיפי חלבון",
		servingSize: "חטיף (60g)",
		calories: 190,
		protein: 21,
		carbs: 21,
		fat: 7,
		fiber: 14,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפי חלבון)"
	},
	{
		id: "f-israel-276",
		name: "חטיף אנרגיה Nature Valley",
		category: "חטיפים",
		servingSize: "יחידה (21g)",
		calories: 95,
		protein: 2,
		carbs: 14,
		fat: 3.5,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-277",
		name: "חטיף אנרגיה FITFREE ללא סוכר",
		category: "חטיפים",
		servingSize: "יחידה (25g)",
		calories: 85,
		protein: 1.8,
		carbs: 15,
		fat: 2.2,
		fiber: 3.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-278",
		name: "במבה קלאסית (אסם)",
		category: "חטיפים",
		servingSize: "שקית קטנה (25g)",
		calories: 133,
		protein: 3.5,
		carbs: 10,
		fat: 8.8,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-279",
		name: "במבה פרו 12g חלבון",
		category: "חטיפים",
		servingSize: "שקית (60g)",
		calories: 280,
		protein: 12,
		carbs: 22,
		fat: 16,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-280",
		name: "ביסלי גריל / ברבקיו (אסם)",
		category: "חטיפים",
		servingSize: "שקית קטנה (35g)",
		calories: 170,
		protein: 3.2,
		carbs: 22,
		fat: 7.8,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-281",
		name: "תפוצ'יפס קלאסי (שטראוס)",
		category: "חטיפים",
		servingSize: "שקית קטנה (50g)",
		calories: 265,
		protein: 3,
		carbs: 26,
		fat: 16.5,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-282",
		name: "תפוצ'יפס Crunch",
		category: "חטיפים",
		servingSize: "שקית קטנה (50g)",
		calories: 270,
		protein: 3,
		carbs: 25.5,
		fat: 17,
		fiber: 2.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-283",
		name: "דורטוס חמוץ חריף",
		category: "חטיפים",
		servingSize: "שקית קטנה (55g)",
		calories: 275,
		protein: 3.5,
		carbs: 32,
		fat: 14.5,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-284",
		name: "פופקורן ביתי ללא שמן / באוויר חם",
		category: "חטיפים",
		servingSize: "100 גרם",
		calories: 380,
		protein: 12,
		carbs: 72,
		fat: 4,
		fiber: 14,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-285",
		name: "פופקורן למיקרוגל במלח",
		category: "חטיפים",
		servingSize: "100 גרם",
		calories: 450,
		protein: 8,
		carbs: 58,
		fat: 22,
		fiber: 9,
		notes: "מוצר מזון מרשתות השיווק בישראל (חטיפים)"
	},
	{
		id: "f-israel-286",
		name: "שוקולד מריר 70% מוצקי קקאו",
		category: "מתוקים",
		servingSize: "קוביה (10g)",
		calories: 55,
		protein: .8,
		carbs: 3.5,
		fat: 4,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-287",
		name: "שוקולד מריר 85%",
		category: "מתוקים",
		servingSize: "קוביה (10g)",
		calories: 58,
		protein: 1,
		carbs: 2.2,
		fat: 4.8,
		fiber: 1.4,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-288",
		name: "שוקולד חלב פרות (עלית)",
		category: "מתוקים",
		servingSize: "קוביה (10g)",
		calories: 53,
		protein: .7,
		carbs: 5.8,
		fat: 3,
		fiber: .3,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-289",
		name: "חטיף פסק זמן",
		category: "מתוקים",
		servingSize: "יחידה (45g)",
		calories: 245,
		protein: 3.2,
		carbs: 26,
		fat: 14,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-290",
		name: "חטיף כיף כף",
		category: "מתוקים",
		servingSize: "יחידה (45g)",
		calories: 235,
		protein: 3,
		carbs: 28,
		fat: 12.5,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-291",
		name: "חטיף אגוזי",
		category: "מתוקים",
		servingSize: "יחידה (45g)",
		calories: 220,
		protein: 2.5,
		carbs: 27,
		fat: 11.5,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-292",
		name: "חטיף טוויסט",
		category: "מתוקים",
		servingSize: "יחידה (28g)",
		calories: 130,
		protein: 1.2,
		carbs: 20,
		fat: 5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-293",
		name: "חטיף טורטית",
		category: "מתוקים",
		servingSize: "יחידה (40g)",
		calories: 210,
		protein: 2,
		carbs: 24,
		fat: 12,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-294",
		name: "עוגיות אוראו",
		category: "מתוקים",
		servingSize: "יחידה 1 (11g)",
		calories: 52,
		protein: .5,
		carbs: 7.8,
		fat: 2.2,
		fiber: .3,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-295",
		name: "עוגיות מזרחיות / עוגיות עבאדי",
		category: "מתוקים",
		servingSize: "100 גרם",
		calories: 460,
		protein: 10,
		carbs: 62,
		fat: 18,
		fiber: 3,
		notes: "מוצר מזון מרשתות השיווק בישראל (מתוקים)"
	},
	{
		id: "f-israel-296",
		name: "גלידת נוקאאוט / מגנום",
		category: "גלידות",
		servingSize: "יחידה (80g)",
		calories: 260,
		protein: 3.2,
		carbs: 24,
		fat: 17,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (גלידות)"
	},
	{
		id: "f-israel-297",
		name: "ארטיק קרח לימון/דובדבן",
		category: "גלידות",
		servingSize: "יחידה (70g)",
		calories: 60,
		protein: 0,
		carbs: 15,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גלידות)"
	},
	{
		id: "f-israel-298",
		name: "שלגון פלדמן לייט (40 קלוריות)",
		category: "גלידות",
		servingSize: "יחידה (50g)",
		calories: 40,
		protein: 1.5,
		carbs: 7,
		fat: .5,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (גלידות)"
	},
	{
		id: "f-israel-299",
		name: "רסק עגבניות 28-30% (טל)",
		category: "שימורים",
		servingSize: "כף (30g)",
		calories: 24,
		protein: 1,
		carbs: 5,
		fat: .1,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-300",
		name: "עגבניות מרוסקות מקולפות (מוטי Mutti)",
		category: "שימורים",
		servingSize: "100 גרם",
		calories: 26,
		protein: 1.2,
		carbs: 4.5,
		fat: .2,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-301",
		name: "זיתים ירוקים מבוקעים (בית השיטה)",
		category: "שימורים",
		servingSize: "10 זיתים (30g)",
		calories: 42,
		protein: .4,
		carbs: .5,
		fat: 4.2,
		fiber: 1,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-302",
		name: "זיתים שחורים מושחזים",
		category: "שימורים",
		servingSize: "10 זיתים (30g)",
		calories: 38,
		protein: .3,
		carbs: 1,
		fat: 3.6,
		fiber: .8,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-303",
		name: "מלפפון חמוץ במלח / בחומץ (יבנה)",
		category: "שימורים",
		servingSize: "יחידה (30g)",
		calories: 5,
		protein: .3,
		carbs: .8,
		fat: .1,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-304",
		name: "טחינה משומשום מלא מוכנה בקופסה",
		category: "שימורים",
		servingSize: "100 גרם",
		calories: 280,
		protein: 8,
		carbs: 8,
		fat: 25,
		fiber: 4,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-305",
		name: "חלב קוקוס לקארי 17% שומן",
		category: "שימורים",
		servingSize: "100 מ\"ל",
		calories: 165,
		protein: 1.5,
		carbs: 2.8,
		fat: 17,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-306",
		name: "קרם קוקוס 20%-22%",
		category: "שימורים",
		servingSize: "100 מ\"ל",
		calories: 215,
		protein: 2,
		carbs: 3.2,
		fat: 22,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (שימורים)"
	},
	{
		id: "f-israel-307",
		name: "נודלס להקפצה (מאסטר שף)",
		category: "מזון מוכן",
		servingSize: "100 גרם מבושל",
		calories: 140,
		protein: 4.5,
		carbs: 28,
		fat: 1,
		fiber: 1.2,
		notes: "מוצר מזון מרשתות השיווק בישראל (מזון מוכן)"
	},
	{
		id: "f-israel-308",
		name: "דפי אורז לספרינג רול",
		category: "דגנים ופחמימות",
		servingSize: "דף 1 (10g)",
		calories: 33,
		protein: .6,
		carbs: 7.8,
		fat: .1,
		fiber: .2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-309",
		name: "שקדי מרק (אסם)",
		category: "תוספות",
		servingSize: "כף (10g)",
		calories: 53,
		protein: 1,
		carbs: 5.2,
		fat: 3.2,
		fiber: .3,
		notes: "מוצר מזון מרשתות השיווק בישראל (תוספות)"
	},
	{
		id: "f-israel-310",
		name: "סלט כרוב אדום במיונז מוכן",
		category: "סלטים מוכנים",
		servingSize: "100 גרם",
		calories: 160,
		protein: 1.2,
		carbs: 8,
		fat: 14,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (סלטים מוכנים)"
	},
	{
		id: "f-israel-311",
		name: "סלט טורקי מוכן (צבר)",
		category: "סלטים מוכנים",
		servingSize: "100 גרם",
		calories: 90,
		protein: 1.5,
		carbs: 10,
		fat: 5,
		fiber: 1.8,
		notes: "מוצר מזון מרשתות השיווק בישראל (סלטים מוכנים)"
	},
	{
		id: "f-israel-312",
		name: "סלט חצילים בטחינה מוכן",
		category: "סלטים מוכנים",
		servingSize: "100 גרם",
		calories: 140,
		protein: 2.5,
		carbs: 6,
		fat: 12,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (סלטים מוכנים)"
	},
	{
		id: "f-israel-313",
		name: "סלט מטבוחה אסלית (אחלה)",
		category: "סלטים מוכנים",
		servingSize: "100 גרם",
		calories: 75,
		protein: 1.4,
		carbs: 8.5,
		fat: 4,
		fiber: 1.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (סלטים מוכנים)"
	},
	{
		id: "f-israel-314",
		name: "קפה שחור / נס קפה ללא חלב וללא סוכר",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 2,
		protein: .2,
		carbs: .3,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-315",
		name: "מיץ תפוזים טבעי סחוט (פריגת)",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 90,
		protein: 1.4,
		carbs: 20,
		fat: .2,
		fiber: .4,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-316",
		name: "משקה קולה קלה / זירו Coca Cola Zero",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-317",
		name: "משקה ספרייט זירו / פאנטה זירו",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-318",
		name: "מיץ ענבים תירוש לקידוש",
		category: "משקאות",
		servingSize: "כוס (100 מ\"ל)",
		calories: 70,
		protein: .3,
		carbs: 17,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-319",
		name: "משקה אלוורה עם חתיכות",
		category: "משקאות",
		servingSize: "כוס (200 מ\"ל)",
		calories: 76,
		protein: 0,
		carbs: 19,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-320",
		name: "בירה שחורה נשר מאלט",
		category: "משקאות",
		servingSize: "בקבוק (330 מ\"ל)",
		calories: 115,
		protein: .8,
		carbs: 28,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-321",
		name: "בירה לבנה 5% אלכוהול (גולדסטאר/מכבי)",
		category: "משקאות",
		servingSize: "פחית (330 מ\"ל)",
		calories: 140,
		protein: 1.2,
		carbs: 11,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-322",
		name: "יין אדום יבש",
		category: "משקאות",
		servingSize: "כוס (150 מ\"ל)",
		calories: 125,
		protein: .1,
		carbs: 3.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (משקאות)"
	},
	{
		id: "f-israel-323",
		name: "גבינה לבנה 0% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 60,
		protein: 10,
		carbs: 1.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-324",
		name: "גבינה לבנה 1% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 68,
		protein: 10,
		carbs: 1.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-325",
		name: "גבינה לבנה 3% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 84,
		protein: 10,
		carbs: 1.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-326",
		name: "גבינה לבנה 15% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 180,
		protein: 8.5,
		carbs: 1.8,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-327",
		name: "גבינה לבנה 28% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 284,
		protein: 8.5,
		carbs: 1.8,
		fat: 28,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-328",
		name: "גבינה לבנה 0% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 60,
		protein: 10,
		carbs: 1.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-329",
		name: "גבינה לבנה 1% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 68,
		protein: 10,
		carbs: 1.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-330",
		name: "גבינה לבנה 5% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 100,
		protein: 10,
		carbs: 1.8,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-331",
		name: "גבינה לבנה 9% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 132,
		protein: 10,
		carbs: 1.8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-332",
		name: "גבינה לבנה 15% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 180,
		protein: 8.5,
		carbs: 1.8,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-333",
		name: "גבינה לבנה 28% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 284,
		protein: 8.5,
		carbs: 1.8,
		fat: 28,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-334",
		name: "גבינה לבנה 0% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 60,
		protein: 10,
		carbs: 1.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-335",
		name: "גבינה לבנה 1% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 68,
		protein: 10,
		carbs: 1.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-336",
		name: "גבינה לבנה 3% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 84,
		protein: 10,
		carbs: 1.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-337",
		name: "גבינה לבנה 5% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 100,
		protein: 10,
		carbs: 1.8,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-338",
		name: "גבינה לבנה 9% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 132,
		protein: 10,
		carbs: 1.8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-339",
		name: "גבינה לבנה 15% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 180,
		protein: 8.5,
		carbs: 1.8,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-340",
		name: "גבינה לבנה 28% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 284,
		protein: 8.5,
		carbs: 1.8,
		fat: 28,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-341",
		name: "גבינה לבנה 0% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 60,
		protein: 10,
		carbs: 1.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-342",
		name: "גבינה לבנה 1% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 68,
		protein: 10,
		carbs: 1.8,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-343",
		name: "גבינה לבנה 3% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 84,
		protein: 10,
		carbs: 1.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-344",
		name: "גבינה לבנה 5% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 100,
		protein: 10,
		carbs: 1.8,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-345",
		name: "גבינה לבנה 9% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 132,
		protein: 10,
		carbs: 1.8,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-346",
		name: "גבינה לבנה 15% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 180,
		protein: 8.5,
		carbs: 1.8,
		fat: 15,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-347",
		name: "גבינה לבנה 28% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 284,
		protein: 8.5,
		carbs: 1.8,
		fat: 28,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-348",
		name: "קוטג' 1% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 75,
		protein: 11.2,
		carbs: 1.5,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-349",
		name: "קוטג' 9% - תנובה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 131,
		protein: 10,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-350",
		name: "קוטג' 1% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 75,
		protein: 11.2,
		carbs: 1.5,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-351",
		name: "קוטג' 3% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 89,
		protein: 11.2,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-352",
		name: "קוטג' 5% - שטראוס",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 103,
		protein: 11.2,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-353",
		name: "קוטג' 1% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 75,
		protein: 11.2,
		carbs: 1.5,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-354",
		name: "קוטג' 3% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 89,
		protein: 11.2,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-355",
		name: "קוטג' 5% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 103,
		protein: 11.2,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-356",
		name: "קוטג' 9% - טרה",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 131,
		protein: 10,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-357",
		name: "קוטג' 1% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 75,
		protein: 11.2,
		carbs: 1.5,
		fat: 1,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-358",
		name: "קוטג' 3% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 89,
		protein: 11.2,
		carbs: 1.5,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-359",
		name: "קוטג' 5% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 103,
		protein: 11.2,
		carbs: 1.5,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-360",
		name: "קוטג' 9% - שופרסל",
		category: "גבינות",
		servingSize: "100 גרם",
		calories: 131,
		protein: 10,
		carbs: 1.5,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות)"
	},
	{
		id: "f-israel-361",
		name: "גבינה בולגרית 5% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 14.5,
		carbs: 1.2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-362",
		name: "גבינה בולגרית 9% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 14.5,
		carbs: 1.2,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-363",
		name: "גבינה בולגרית 16% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 207,
		protein: 14.5,
		carbs: 1.2,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-364",
		name: "גבינה בולגרית 24% - פיראוס",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 263,
		protein: 14.5,
		carbs: 1.2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-365",
		name: "גבינה בולגרית 5% - צוריאל",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 14.5,
		carbs: 1.2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-366",
		name: "גבינה בולגרית 9% - צוריאל",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 14.5,
		carbs: 1.2,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-367",
		name: "גבינה בולגרית 16% - צוריאל",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 207,
		protein: 14.5,
		carbs: 1.2,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-368",
		name: "גבינה בולגרית 24% - צוריאל",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 263,
		protein: 14.5,
		carbs: 1.2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-369",
		name: "גבינה בולגרית 5% - גד",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 14.5,
		carbs: 1.2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-370",
		name: "גבינה בולגרית 9% - גד",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 14.5,
		carbs: 1.2,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-371",
		name: "גבינה בולגרית 16% - גד",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 207,
		protein: 14.5,
		carbs: 1.2,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-372",
		name: "גבינה בולגרית 24% - גד",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 263,
		protein: 14.5,
		carbs: 1.2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-373",
		name: "גבינה בולגרית 5% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 14.5,
		carbs: 1.2,
		fat: 5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-374",
		name: "גבינה בולגרית 9% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 158,
		protein: 14.5,
		carbs: 1.2,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-375",
		name: "גבינה בולגרית 16% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 207,
		protein: 14.5,
		carbs: 1.2,
		fat: 16,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-376",
		name: "גבינה בולגרית 24% - תנובה",
		category: "גבינות מלוחות",
		servingSize: "100 גרם",
		calories: 263,
		protein: 14.5,
		carbs: 1.2,
		fat: 24,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (גבינות מלוחות)"
	},
	{
		id: "f-israel-377",
		name: "יוגורט דנונה / ביו 0% - תנובה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 40,
		protein: 4.5,
		carbs: 4.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-378",
		name: "יוגורט דנונה / ביו 1.5% - תנובה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 67,
		protein: 4.5,
		carbs: 4.8,
		fat: 1.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-379",
		name: "יוגורט דנונה / ביו 3% - תנובה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 94,
		protein: 4.5,
		carbs: 4.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-380",
		name: "יוגורט דנונה / ביו 4.5% - תנובה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 121,
		protein: 4.5,
		carbs: 4.8,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-381",
		name: "יוגורט דנונה / ביו 0% - שטראוס",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 40,
		protein: 4.5,
		carbs: 4.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-382",
		name: "יוגורט דנונה / ביו 1.5% - שטראוס",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 67,
		protein: 4.5,
		carbs: 4.8,
		fat: 1.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-383",
		name: "יוגורט דנונה / ביו 3% - שטראוס",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 94,
		protein: 4.5,
		carbs: 4.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-384",
		name: "יוגורט דנונה / ביו 4.5% - שטראוס",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 121,
		protein: 4.5,
		carbs: 4.8,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-385",
		name: "יוגורט דנונה / ביו 0% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 40,
		protein: 4.5,
		carbs: 4.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-386",
		name: "יוגורט דנונה / ביו 1.5% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 67,
		protein: 4.5,
		carbs: 4.8,
		fat: 1.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-387",
		name: "יוגורט דנונה / ביו 3% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 94,
		protein: 4.5,
		carbs: 4.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-388",
		name: "יוגורט דנונה / ביו 4.5% - יוטבתה",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 121,
		protein: 4.5,
		carbs: 4.8,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-389",
		name: "יוגורט דנונה / ביו 0% - שופרסל",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 40,
		protein: 4.5,
		carbs: 4.8,
		fat: 0,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-390",
		name: "יוגורט דנונה / ביו 1.5% - שופרסל",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 67,
		protein: 4.5,
		carbs: 4.8,
		fat: 1.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-391",
		name: "יוגורט דנונה / ביו 3% - שופרסל",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 94,
		protein: 4.5,
		carbs: 4.8,
		fat: 3,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-392",
		name: "יוגורט דנונה / ביו 4.5% - שופרסל",
		category: "יוגורט",
		servingSize: "100 גרם",
		calories: 121,
		protein: 4.5,
		carbs: 4.8,
		fat: 4.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (יוגורט)"
	},
	{
		id: "f-israel-393",
		name: "חזה עוף אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-394",
		name: "חזה עוף בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-395",
		name: "חזה עוף מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-396",
		name: "חזה עוף מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 1.5,
		fat: 2.5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-397",
		name: "חזה עוף מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-398",
		name: "פרגית עוף אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-399",
		name: "פרגית עוף בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-400",
		name: "פרגית עוף מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-401",
		name: "פרגית עוף מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 1.5,
		fat: 2.5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-402",
		name: "פרגית עוף מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-403",
		name: "כרעי עוף אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-404",
		name: "כרעי עוף בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-405",
		name: "כרעי עוף מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-406",
		name: "כרעי עוף מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 1.5,
		fat: 2.5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-407",
		name: "כרעי עוף מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-408",
		name: "בשר בקר 5% אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-409",
		name: "בשר בקר 5% בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-410",
		name: "בשר בקר 5% מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-411",
		name: "בשר בקר 5% מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 1.5,
		fat: 9,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-412",
		name: "בשר בקר 5% מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-413",
		name: "בשר בקר 12% אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-414",
		name: "בשר בקר 12% בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-415",
		name: "בשר בקר 12% מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-416",
		name: "בשר בקר 12% מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 1.5,
		fat: 9,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-417",
		name: "בשר בקר 12% מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-418",
		name: "סטייק סינטה אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-419",
		name: "סטייק סינטה בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-420",
		name: "סטייק סינטה מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-421",
		name: "סטייק סינטה מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 1.5,
		fat: 6,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-422",
		name: "סטייק סינטה מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-423",
		name: "פילה סלמון אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-424",
		name: "פילה סלמון בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-425",
		name: "פילה סלמון מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-426",
		name: "פילה סלמון מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 1.5,
		fat: 9,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-427",
		name: "פילה סלמון מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 185,
		protein: 26,
		carbs: 0,
		fat: 9,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-428",
		name: "פילה אמנון אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-429",
		name: "פילה אמנון בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-430",
		name: "פילה אמנון מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-431",
		name: "פילה אמנון מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 1.5,
		fat: 6,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-432",
		name: "פילה אמנון מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 26,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-433",
		name: "חזה הודו אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-434",
		name: "חזה הודו בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-435",
		name: "חזה הודו מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-436",
		name: "חזה הודו מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 1.5,
		fat: 2.5,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-437",
		name: "חזה הודו מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 125,
		protein: 26,
		carbs: 0,
		fat: 2.5,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-438",
		name: "טופו קלאסי אפוי בתנור",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-439",
		name: "טופו קלאסי בגריל",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-440",
		name: "טופו קלאסי מבושל במרק",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-441",
		name: "טופו קלאסי מוקפץ עם ירקות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 1.5,
		fat: 6,
		fiber: .5,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-442",
		name: "טופו קלאסי מבושל ברוטב עגבניות",
		category: "מנות עיקריות",
		servingSize: "100 גרם",
		calories: 115,
		protein: 14,
		carbs: 0,
		fat: 6,
		fiber: 0,
		notes: "מוצר מזון מרשתות השיווק בישראל (מנות עיקריות)"
	},
	{
		id: "f-israel-443",
		name: "אורז לבן (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-444",
		name: "אורז לבן (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-445",
		name: "אורז לבן (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-446",
		name: "אורז לבן (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-447",
		name: "אורז בסמטי (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-448",
		name: "אורז בסמטי (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-449",
		name: "אורז בסמטי (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-450",
		name: "אורז בסמטי (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-451",
		name: "אורז מלא (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-452",
		name: "אורז מלא (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-453",
		name: "אורז מלא (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-454",
		name: "אורז מלא (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-455",
		name: "פסטה קמח מלא (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-456",
		name: "פסטה קמח מלא (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-457",
		name: "פסטה קמח מלא (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-458",
		name: "פסטה קמח מלא (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-459",
		name: "בורגול (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-460",
		name: "בורגול (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-461",
		name: "בורגול (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-462",
		name: "בורגול (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-463",
		name: "קינואה (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-464",
		name: "קינואה (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-465",
		name: "קינואה (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-466",
		name: "קינואה (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-467",
		name: "כוסמת (בישול ביתי נקי)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-468",
		name: "כוסמת (עם מעט שמן זית)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-469",
		name: "כוסמת (עם עשבי תיבול)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-470",
		name: "כוסמת (עם בצל מוזהב)",
		category: "דגנים ופחמימות",
		servingSize: "100 גרם",
		calories: 130,
		protein: 3.2,
		carbs: 27,
		fat: 1,
		fiber: 2,
		notes: "מוצר מזון מרשתות השיווק בישראל (דגנים ופחמימות)"
	},
	{
		id: "f-israel-471",
		name: "תפוח עץ (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-472",
		name: "תפוח עץ (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-473",
		name: "תפוח עץ (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-474",
		name: "אגס (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-475",
		name: "אגס (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-476",
		name: "אגס (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-477",
		name: "שזיף (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-478",
		name: "שזיף (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-479",
		name: "שזיף (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-480",
		name: "אפרסק (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-481",
		name: "אפרסק (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-482",
		name: "אפרסק (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-483",
		name: "תמר (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-484",
		name: "תמר (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-485",
		name: "תמר (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-486",
		name: "תאנה (אורגני)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-487",
		name: "תאנה (מיובש בטבעיות)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	},
	{
		id: "f-israel-488",
		name: "תאנה (טרי קטוף)",
		category: "פירות",
		servingSize: "יחידה / 100g",
		calories: 65,
		protein: .8,
		carbs: 16,
		fat: .2,
		fiber: 2.5,
		notes: "מוצר מזון מרשתות השיווק בישראל (פירות)"
	}
];
var supabaseUrl = "https://pnvtxazqtorylcsjtatv.supabase.co";
var supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBudnR4YXpxdG9yeWxjc2p0YXR2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODcyNTk4MjYsImV4cCI6MjEwMjgzNTgyNn0.L6ZSPRfeJ2EeXw1g7ElIUXHkffF2pjS-4U6qF4EFLAo";
var cleanUrl = supabaseUrl.replace(/\/rest\/v1\/?$/, "").replace(/\/+$/, "");
var supabase = createClient(cleanUrl, supabaseAnonKey, { auth: {
	persistSession: true,
	autoRefreshToken: true,
	detectSessionInUrl: true
} });
async function syncLocalToSupabase(userId, localData, userEmail) {
	try {
		if (localData.userProfile || userEmail) {
			const p = localData.userProfile ?? { weight: 65 };
			await supabase.from("profiles").upsert({
				id: userId,
				email: userEmail || void 0,
				weight_kg: p.weight,
				height_cm: p.height,
				role: p.role || "client",
				coach_id: p.coachId || null,
				animal_character: p.animalCharacter || "dog",
				today_routine_enabled: p.todayRoutineEnabled ?? true,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}, { onConflict: "id" });
		}
		const defaultExerciseIds = /* @__PURE__ */ new Set([
			"ex-bench",
			"ex-squat",
			"ex-row",
			"ex-curl",
			"ex-hipthrust",
			"ex-plank",
			"ex-ohp",
			"ex-rdl"
		]);
		const customExercises = localData.exercises.filter((e) => !defaultExerciseIds.has(e.id));
		if (customExercises.length > 0) {
			const payload = customExercises.map((e) => ({
				id: e.id,
				user_id: userId,
				name: e.name,
				muscle_group: e.muscleGroup,
				equipment: e.equipment,
				category: e.category,
				description: e.description,
				instructions: e.instructions,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}));
			await supabase.from("custom_exercises").upsert(payload, { onConflict: "id" });
		}
		if (localData.programs.length > 0) {
			const programPayload = localData.programs.map((p) => ({
				id: p.id,
				user_id: userId,
				name: p.name,
				description: p.notes,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}));
			await supabase.from("programs").upsert(programPayload, { onConflict: "id" });
			for (const p of localData.programs) {
				const days = p.dayIds.map((dayId) => localData.workouts.find((w) => w.id === dayId)).filter((w) => Boolean(w));
				if (days.length > 0) {
					const dayPayload = days.map((d, index) => ({
						id: d.id,
						program_id: p.id,
						user_id: userId,
						name: d.name,
						items: d.items,
						sort_order: index,
						updated_at: (/* @__PURE__ */ new Date()).toISOString()
					}));
					await supabase.from("program_days").upsert(dayPayload, { onConflict: "id" });
				}
			}
		}
		if (localData.history.length > 0) {
			const historyPayload = localData.history.map((s) => ({
				id: s.id,
				user_id: userId,
				workout_id: s.workoutId,
				workout_name: s.workoutName,
				program_name: s.programName,
				date: s.date,
				duration_sec: s.durationSec,
				entries: s.entries,
				notes: s.notes
			}));
			await supabase.from("workout_sessions").upsert(historyPayload, { onConflict: "id" });
		}
		const seedFoodIds = new Set(ISRAELI_FOOD_DATABASE.map((f) => f.id));
		const customFoods = localData.foods.filter((f) => !seedFoodIds.has(f.id));
		if (customFoods.length > 0) {
			const customFoodPayload = customFoods.map((f) => ({
				id: f.id,
				user_id: userId,
				name: f.name,
				english_name: f.englishName,
				category: f.category ?? "כללי",
				brand: f.brand,
				serving_unit: f.servingSize ?? "100g",
				serving_grams: 100,
				calories: f.calories,
				protein: f.protein,
				carbs: f.carbs,
				fat: f.fat,
				fiber: f.fiber ?? 0,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}));
			await supabase.from("custom_foods").upsert(customFoodPayload, { onConflict: "id" });
		}
		if (localData.nutritionDays.length > 0) {
			const nutritionPayload = localData.nutritionDays.map((nd) => ({
				id: nd.id ?? `${userId}_${nd.date}`,
				user_id: userId,
				date: nd.date,
				target_calories: localData.nutritionTargets.calories,
				meals: nd.meals,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}));
			await supabase.from("nutrition_days").upsert(nutritionPayload, { onConflict: "id" });
		}
		if (localData.favoriteFoods && localData.favoriteFoods.length > 0) {
			const favPayload = localData.favoriteFoods.map((foodId) => ({
				user_id: userId,
				food_id: foodId
			}));
			await supabase.from("food_favorites").upsert(favPayload, { onConflict: "user_id,food_id" });
		}
		return { success: true };
	} catch (err) {
		console.error("[Supabase Sync Error]:", err);
		return {
			success: false,
			error: err?.message || "Cloud sync failed"
		};
	}
}
async function pullSupabaseData(userId, localState) {
	const nextData = { ...localState };
	try {
		const { data: profile } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
		if (profile) nextData.userProfile = {
			...nextData.userProfile,
			weight: profile.weight_kg ? Number(profile.weight_kg) : nextData.userProfile?.weight ?? 65,
			height: profile.height_cm ? Number(profile.height_cm) : nextData.userProfile?.height,
			role: profile.role || "client",
			coachId: profile.coach_id || void 0,
			animalCharacter: profile.animal_character || "dog",
			todayRoutineEnabled: profile.today_routine_enabled ?? true
		};
		const { data: messages } = await supabase.from("coach_messages").select("*").eq("client_id", userId).order("created_at", { ascending: false });
		if (messages && messages.length > 0) nextData.coachMessages = messages.map((m) => ({
			id: m.id,
			coachId: m.coach_id,
			clientId: m.client_id,
			message: m.message,
			createdAt: m.created_at,
			isRead: m.is_read
		}));
		if (nextData.userProfile?.role === "coach") {
			const { data: clientLinks } = await supabase.from("coach_clients").select("id, client_id, created_at, profiles!coach_clients_client_id_fkey(email, full_name)").eq("coach_id", userId);
			if (clientLinks) nextData.clients = clientLinks.map((link) => ({
				id: link.id,
				clientId: link.client_id,
				clientEmail: link.profiles?.email || void 0,
				clientName: link.profiles?.full_name || void 0,
				createdAt: link.created_at
			}));
		}
		const { data: dbCustomExercises } = await supabase.from("custom_exercises").select("*").eq("user_id", userId);
		if (dbCustomExercises && dbCustomExercises.length > 0) {
			const customMap = new Map(nextData.exercises.map((e) => [e.id, e]));
			for (const row of dbCustomExercises) {
				const exItem = {
					id: row.id,
					name: row.name,
					muscleGroup: row.muscle_group,
					muscleGroups: [row.muscle_group],
					category: row.category || "מורכב",
					equipment: row.equipment || "מוט",
					description: row.description || "",
					instructions: row.instructions || ""
				};
				customMap.set(row.id, exItem);
			}
			nextData.exercises = Array.from(customMap.values());
		}
		const { data: dbPrograms } = await supabase.from("programs").select("*").eq("user_id", userId);
		const { data: dbProgramDays } = await supabase.from("program_days").select("*").eq("user_id", userId);
		if (dbPrograms && dbPrograms.length > 0) {
			const workoutsMap = new Map(nextData.workouts.map((w) => [w.id, w]));
			const programsList = [];
			for (const pRow of dbPrograms) {
				const matchingDays = (dbProgramDays || []).filter((d) => d.program_id === pRow.id).sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
				const dayIds = [];
				for (const dRow of matchingDays) {
					dayIds.push(dRow.id);
					const workoutItem = {
						id: dRow.id,
						name: dRow.name,
						notes: "",
						items: dRow.items || []
					};
					workoutsMap.set(dRow.id, workoutItem);
				}
				programsList.push({
					id: pRow.id,
					name: pRow.name,
					notes: pRow.description || "",
					dayIds
				});
			}
			nextData.programs = programsList;
			nextData.workouts = Array.from(workoutsMap.values());
		}
		const { data: dbSessions } = await supabase.from("workout_sessions").select("*").eq("user_id", userId).order("date", { ascending: false });
		if (dbSessions && dbSessions.length > 0) nextData.history = dbSessions.map((row) => ({
			id: row.id,
			workoutId: row.workout_id || "",
			workoutName: row.workout_name,
			programName: row.program_name || "",
			date: row.date,
			durationSec: row.duration_sec,
			entries: row.entries || [],
			notes: row.notes || ""
		}));
		const { data: dbCustomFoods } = await supabase.from("custom_foods").select("*").eq("user_id", userId);
		if (dbCustomFoods && dbCustomFoods.length > 0) {
			const foodMap = new Map(nextData.foods.map((f) => [f.id, f]));
			for (const row of dbCustomFoods) {
				const foodItem = {
					id: row.id,
					name: row.name,
					englishName: row.english_name || void 0,
					category: row.category,
					brand: row.brand || void 0,
					servingSize: row.serving_unit || "100g",
					calories: Number(row.calories),
					protein: Number(row.protein),
					carbs: Number(row.carbs),
					fat: Number(row.fat),
					fiber: Number(row.fiber || 0)
				};
				foodMap.set(row.id, foodItem);
			}
			nextData.foods = Array.from(foodMap.values());
		}
		const { data: dbNutritionDays } = await supabase.from("nutrition_days").select("*").eq("user_id", userId);
		if (dbNutritionDays && dbNutritionDays.length > 0) nextData.nutritionDays = dbNutritionDays.map((row) => ({
			id: row.id,
			date: typeof row.date === "string" ? row.date.slice(0, 10) : row.date,
			meals: row.meals || []
		}));
		const { data: dbFavs } = await supabase.from("food_favorites").select("food_id").eq("user_id", userId);
		if (dbFavs) nextData.favoriteFoods = dbFavs.map((f) => f.food_id);
	} catch (err) {
		console.error("[Supabase Pull Error]:", err);
	}
	return nextData;
}
async function pullClientDataForCoach(clientId) {
	try {
		const { data: profile } = await supabase.from("profiles").select("*").eq("id", clientId).maybeSingle();
		const { data: dbPrograms } = await supabase.from("programs").select("*").eq("user_id", clientId);
		const { data: dbProgramDays } = await supabase.from("program_days").select("*").eq("user_id", clientId);
		const { data: dbNutritionDays } = await supabase.from("nutrition_days").select("*").eq("user_id", clientId);
		const { data: dbSessions } = await supabase.from("workout_sessions").select("*").eq("user_id", clientId).order("date", { ascending: false });
		const workoutsMap = /* @__PURE__ */ new Map();
		const programsList = [];
		if (dbPrograms && dbPrograms.length > 0) for (const pRow of dbPrograms) {
			const matchingDays = (dbProgramDays || []).filter((d) => d.program_id === pRow.id).sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
			const dayIds = [];
			for (const dRow of matchingDays) {
				dayIds.push(dRow.id);
				workoutsMap.set(dRow.id, {
					id: dRow.id,
					name: dRow.name,
					notes: "",
					items: dRow.items || []
				});
			}
			programsList.push({
				id: pRow.id,
				name: pRow.name,
				notes: pRow.description || "",
				dayIds
			});
		}
		const nutritionList = (dbNutritionDays || []).map((row) => ({
			id: row.id,
			date: typeof row.date === "string" ? row.date.slice(0, 10) : row.date,
			meals: row.meals || []
		}));
		const historyList = (dbSessions || []).map((row) => ({
			id: row.id,
			workoutId: row.workout_id || "",
			workoutName: row.workout_name,
			programName: row.program_name || "",
			date: row.date,
			durationSec: row.duration_sec,
			entries: row.entries || [],
			notes: row.notes || ""
		}));
		return {
			programs: programsList,
			workouts: Array.from(workoutsMap.values()),
			nutritionDays: nutritionList,
			history: historyList,
			profile: profile ? {
				weight: Number(profile.weight_kg || 65),
				height: Number(profile.height_cm || 165),
				role: profile.role || "client"
			} : void 0
		};
	} catch (err) {
		console.error("[Pull Client Data Error]:", err);
		return {
			programs: [],
			workouts: [],
			nutritionDays: [],
			history: []
		};
	}
}
var MUSCLE_GROUPS = [
	"חזה",
	"חזה עליון",
	"חזה תחתון",
	"גב",
	"גב רחב",
	"טרפזים",
	"גב תחתון",
	"כתפיים",
	"כתף קדמית",
	"כתף צידית",
	"כתף אחורית",
	"ביצפס (יד קדמית)",
	"טריצפס (יד אחורית)",
	"אמות",
	"בטן",
	"אלכסונים",
	"ישבן",
	"ארבע ראשי",
	"המסטרינג",
	"תאומים",
	"מקרבים",
	"מרחיקים",
	"כופפי הירך",
	"צוואר",
	"גוף מלא",
	"אירובי",
	"אחר"
];
var EQUIPMENT = [
	"מוט",
	"סמית' משין",
	"משקוליות יד",
	"פולי / כבלים",
	"מכונה",
	"מוט W / EZ",
	"קטלבל",
	"משקל גוף",
	"גומיית התנגדות",
	"משקל גוף בתוספת משקל",
	"אחר"
];
var EXERCISE_CATEGORIES = [
	"מורכב",
	"בידוד",
	"עזר",
	"מכונה",
	"אירובי",
	"גמישות / ניעות",
	"אחר"
];
var DEFAULT_MEALS = [
	"ארוחת בוקר",
	"נשנוש בוקר",
	"ארוחת צהריים",
	"נשנוש אחה\"צ",
	"ארוחת ערב",
	"נשנוש לילה"
];
var CARDIO_TYPES = [
	"הליכון (Treadmill)",
	"הליכה",
	"ריצה",
	"אופני כושר",
	"אליפטיקל",
	"מדרגות (StairMaster)",
	"חתירה (Rowing)",
	"שחייה",
	"טניס",
	"אימון אינטרוולים (HIIT)"
];
var ANIMAL_CHARACTERS = [
	{
		id: "dog",
		name: "כלבלב",
		emoji: "🐶"
	},
	{
		id: "cat",
		name: "חתלתול",
		emoji: "🐱"
	},
	{
		id: "panda",
		name: "פנדה",
		emoji: "🐼"
	},
	{
		id: "fox",
		name: "שועל",
		emoji: "🦊"
	},
	{
		id: "koala",
		name: "קואלה",
		emoji: "🐨"
	},
	{
		id: "bunny",
		name: "ארנב",
		emoji: "🐰"
	},
	{
		id: "bear",
		name: "דובב",
		emoji: "🐻"
	},
	{
		id: "lion",
		name: "אריה",
		emoji: "🦁"
	},
	{
		id: "penguin",
		name: "פינגווין",
		emoji: "🐧"
	}
];
var KEY = "gymtrack.v1";
var uid = () => Math.random().toString(36).slice(2, 10);
/** Local calendar date as YYYY-MM-DD (used to key nutrition days). */
var todayKey = (d = /* @__PURE__ */ new Date()) => {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
var seed = () => {
	const ex = [
		{
			id: "ex-bench",
			name: "לחיצת חזה כנגד מוט",
			muscleGroup: "חזה",
			muscleGroups: [
				"חזה",
				"טריצפס (יד אחורית)",
				"כתף קדמית"
			],
			secondaryMuscles: ["טריצפס (יד אחורית)", "כתפיים"],
			category: "מורכב",
			equipment: "מוט",
			description: "שכב על ספה שטוחה, אחוז במוט ברוחב מעט רחב מהכתפיים, הורד אל מרכז החזה ולחץ כלפי מעלה.",
			instructions: "שמור על שכמות צמודות, כפות רגליים יציבות על הרצפה וקשת קלה בגב התחתון.",
			videoUrl: "",
			images: [],
			notes: "לשמור על שכמות צמודות ומכווצות לאורך כל התנועה.",
			tips: "ללחוץ דרך העקבים ולשמור על מסלול מוט יציב."
		},
		{
			id: "ex-squat",
			name: "סקואט כנגד מוט (Back Squat)",
			muscleGroup: "ארבע ראשי",
			muscleGroups: [
				"ארבע ראשי",
				"ישבן",
				"גב תחתון"
			],
			secondaryMuscles: ["ישבן", "בטן"],
			category: "מורכב",
			equipment: "מוט",
			description: "הנח את המוט על הגב העליון, רד עם האגן אחורה ולמטה עד זווית 90 מעלות לפחות ולחץ חזרה מעלה.",
			instructions: "שמור על חזה מורם וברכיים בקו אחד עם כפות הרגליים.",
			videoUrl: "",
			images: [],
			notes: "חגורת גב מעל 100 ק\"ג.",
			tips: "דחיפה דרך מרכז כף הרגל."
		},
		{
			id: "ex-row",
			name: "חתירה בכבלים בישיבה",
			muscleGroup: "גב",
			muscleGroups: [
				"גב",
				"גב רחב",
				"ביצפס (יד קדמית)"
			],
			secondaryMuscles: ["ביצפס (יד קדמית)"],
			category: "מורכב",
			equipment: "פולי / כבלים",
			description: "שב מול הכבל, משוך את הידית לכיוון הטבור והדק את השכמות בסוף התנועה.",
			instructions: "גב זקוף, מתיחה מלאה קדימה וכיווץ חזק בגב לאחור.",
			videoUrl: "",
			images: [],
			notes: "להקפיד לא להשתמש בתנופה מוגזמת של הגב.",
			tips: "למשוך דרך המרפקים ולא דרך כפות הידיים."
		},
		{
			id: "ex-curl",
			name: "כפילת מרפקים עם משקוליות",
			muscleGroup: "ביצפס (יד קדמית)",
			muscleGroups: ["ביצפס (יד קדמית)", "אמות"],
			secondaryMuscles: ["אמות"],
			category: "בידוד",
			equipment: "משקוליות יד",
			description: "עמוד יציב, כפוף את המרפקים והרם את המשקוליות תוך סיבוב קל של כף היד, והורד באיטיות.",
			instructions: "מרפקים צמודים לצדי הגוף, ללא הנדנוד של הגב.",
			videoUrl: "",
			images: [],
			notes: "עבודה נקייה ומבוקרת בחלק השלילי (ירידה).",
			tips: ""
		},
		{
			id: "ex-hipthrust",
			name: "דחיקת אגן כנגד מוט (Hip Thrust)",
			muscleGroup: "ישבן",
			muscleGroups: ["ישבן", "המסטרינג"],
			secondaryMuscles: ["המסטרינג", "ארבע ראשי"],
			category: "מורכב",
			equipment: "מוט",
			description: "הנח גב עליון על ספסל, מוט על האגן, הרם את האגן מעלה וכווץ את הישבן בשיא התנועה.",
			instructions: "מבט קדימה, כיווץ מלא של הישבן בשיא הגובה לשנייה אחת.",
			videoUrl: "",
			images: [],
			notes: "לעצור לשנייה אחת בחלק העליון.",
			tips: ""
		},
		{
			id: "ex-plank",
			name: "פלאנק (Plank)",
			muscleGroup: "בטן",
			muscleGroups: [
				"בטן",
				"אלכסונים",
				"גב תחתון"
			],
			secondaryMuscles: ["כתפיים"],
			category: "בידוד",
			equipment: "משקל גוף",
			description: "החזק גוף ישר על האמות וקצות האצבעות תוך כיווץ חזק של הבטן והישבן.",
			instructions: "גוף בקו ישר אחד מהראש ועד העקבים.",
			videoUrl: "",
			images: [],
			notes: "",
			tips: ""
		},
		{
			id: "ex-ohp",
			name: "לחיצת כתפיים בעמידה כנגד מוט",
			muscleGroup: "כתפיים",
			muscleGroups: [
				"כתפיים",
				"כתף קדמית",
				"טריצפס (יד אחורית)"
			],
			secondaryMuscles: ["טריצפס (יד אחורית)", "בטן"],
			category: "מורכב",
			equipment: "מוט",
			description: "עמוד יציב, לחץ את המוט מגובה החזה העליון מעלה מעל הראש עד נעילה.",
			instructions: "בטן מהודקת וישבן מכווץ לשמירה על הגב.",
			videoUrl: "",
			images: [],
			notes: "",
			tips: ""
		},
		{
			id: "ex-rdl",
			name: "דדליפט רומני (RDL)",
			muscleGroup: "המסטרינג",
			muscleGroups: [
				"המסטרינג",
				"ישבן",
				"גב תחתון"
			],
			secondaryMuscles: ["ישבן", "גב תחתון"],
			category: "מורכב",
			equipment: "מוט",
			description: "אחוז במוט, קח את האגן אחורנית תוך כפיפה קלה בברכיים והורד את המוט לאורך הרגליים.",
			instructions: "גב ישר לחלוטין, מתיחה חזקה בחלק האחורי של הירכיים.",
			videoUrl: "",
			images: [],
			notes: "מתיחה מורגשת בהמסטרינג.",
			tips: ""
		}
	];
	const day = (id, name, items) => ({
		id,
		name,
		notes: "",
		items: items.map((s, i) => ({
			id: `${id}-i${i}`,
			exerciseId: s.exerciseId,
			sets: s.sets,
			reps: s.reps,
			repType: s.repMin != null ? "range" : "fixed",
			repMin: s.repMin,
			repMax: s.repMax,
			weight: s.weight,
			rest: s.rest,
			notes: "",
			workingSets: Array.from({ length: s.sets }, (_, setIdx) => ({
				id: `${id}-i${i}-set-${setIdx}`,
				setNumber: setIdx + 1,
				weight: s.weight,
				reps: s.repMin ?? s.reps,
				repMax: s.repMax
			}))
		}))
	});
	const workouts = [
		day("w-lower-1", "פלג גוף תחתון 1", [
			{
				exerciseId: "ex-squat",
				sets: 4,
				reps: 6,
				weight: 80,
				rest: 150
			},
			{
				exerciseId: "ex-hipthrust",
				sets: 4,
				reps: 8,
				repMin: 8,
				repMax: 10,
				weight: 60,
				rest: 90
			},
			{
				exerciseId: "ex-rdl",
				sets: 3,
				reps: 10,
				repMin: 8,
				repMax: 10,
				weight: 50,
				rest: 90
			},
			{
				exerciseId: "ex-plank",
				sets: 3,
				reps: 1,
				weight: 0,
				rest: 60
			}
		]),
		day("w-upper-1", "פלג גוף עליון 1", [
			{
				exerciseId: "ex-bench",
				sets: 4,
				reps: 8,
				repMin: 8,
				repMax: 10,
				weight: 60,
				rest: 120
			},
			{
				exerciseId: "ex-row",
				sets: 4,
				reps: 10,
				repMin: 10,
				repMax: 12,
				weight: 45,
				rest: 90
			},
			{
				exerciseId: "ex-ohp",
				sets: 3,
				reps: 8,
				repMin: 8,
				repMax: 10,
				weight: 35,
				rest: 90
			},
			{
				exerciseId: "ex-curl",
				sets: 3,
				reps: 12,
				weight: 12,
				rest: 60
			}
		]),
		day("w-lower-2", "פלג גוף תחתון 2", [
			{
				exerciseId: "ex-squat",
				sets: 3,
				reps: 10,
				weight: 65,
				rest: 120
			},
			{
				exerciseId: "ex-hipthrust",
				sets: 4,
				reps: 12,
				weight: 55,
				rest: 90
			},
			{
				exerciseId: "ex-rdl",
				sets: 3,
				reps: 12,
				weight: 45,
				rest: 90
			}
		]),
		day("w-upper-2", "פלג גוף עליון 2", [
			{
				exerciseId: "ex-row",
				sets: 4,
				reps: 10,
				weight: 50,
				rest: 90
			},
			{
				exerciseId: "ex-bench",
				sets: 3,
				reps: 10,
				repMin: 8,
				repMax: 10,
				weight: 55,
				rest: 90
			},
			{
				exerciseId: "ex-ohp",
				sets: 3,
				reps: 10,
				weight: 30,
				rest: 90
			},
			{
				exerciseId: "ex-curl",
				sets: 3,
				reps: 12,
				repMin: 10,
				repMax: 12,
				weight: 12,
				rest: 60
			}
		])
	];
	return {
		exercises: ex,
		workouts,
		programs: [{
			id: "p-default",
			name: "תכנית אימונים 4 ימים",
			notes: "חלוקת פלג גוף תחתון / פלג גוף עליון",
			dayIds: workouts.map((w) => w.id)
		}],
		history: [],
		foods: [...ISRAELI_FOOD_DATABASE],
		nutritionDays: [],
		nutritionTargets: {
			calories: 2e3,
			protein: 140,
			carbs: 200,
			fat: 65
		},
		mealTemplate: [...DEFAULT_MEALS],
		recipes: [],
		recentFoods: [],
		favoriteFoods: [],
		bodyWeightLogs: [{
			id: "bw-seed",
			date: todayKey(),
			weight: 65
		}],
		cardioLogs: [],
		userProfile: {
			weight: 65,
			height: 165,
			age: 26,
			gender: "female",
			workoutsPerWeek: 4
		}
	};
};
var data = seed();
var hydrated = false;
var currentUser = null;
var listeners = /* @__PURE__ */ new Set();
/** Merge food database so saved data retains all Israeli supermarket items */
function mergeSeedFoods(existing) {
	const byId = new Map(existing.map((f) => [f.id, f]));
	const byName = new Map(existing.map((f) => [f.name.toLocaleLowerCase(), f]));
	for (const seedFood of ISRAELI_FOOD_DATABASE) {
		if (byId.has(seedFood.id)) continue;
		if (byName.has(seedFood.name.toLocaleLowerCase())) continue;
		byId.set(seedFood.id, seedFood);
	}
	return Array.from(byId.values());
}
/** Ensure older saved data still works cleanly. */
function migrate(d) {
	const workouts = d.workouts ?? [];
	let programs = d.programs ?? [];
	if (!programs.length && workouts.length) programs = [{
		id: uid(),
		name: "תכנית אימונים",
		notes: "",
		dayIds: workouts.map((w) => w.id)
	}];
	return {
		exercises: d.exercises?.length ? d.exercises : seed().exercises,
		workouts: workouts.length ? workouts : seed().workouts,
		programs: programs.length ? programs : seed().programs,
		history: d.history ?? [],
		foods: mergeSeedFoods(d.foods ?? []),
		nutritionDays: d.nutritionDays ?? [],
		nutritionTargets: d.nutritionTargets ?? seed().nutritionTargets,
		mealTemplate: d.mealTemplate?.length ? d.mealTemplate : [...DEFAULT_MEALS],
		recipes: d.recipes ?? [],
		recentFoods: d.recentFoods ?? [],
		favoriteFoods: d.favoriteFoods ?? [],
		bodyWeightLogs: d.bodyWeightLogs?.length ? d.bodyWeightLogs : [{
			id: uid(),
			date: todayKey(),
			weight: d.userProfile?.weight ?? 65
		}],
		cardioLogs: d.cardioLogs ?? [],
		userProfile: d.userProfile ?? seed().userProfile
	};
}
function load() {
	if (hydrated || typeof window === "undefined") return;
	hydrated = true;
	try {
		const raw = window.localStorage.getItem(KEY);
		if (raw) data = migrate({
			...seed(),
			...JSON.parse(raw)
		});
	} catch {}
	if (typeof window !== "undefined") {
		supabase.auth.getSession().then(({ data: { session } }) => {
			if (session?.user) {
				currentUser = session.user;
				handleUserLogin(session.user.id);
			}
		});
		supabase.auth.onAuthStateChange((event, session) => {
			currentUser = session?.user || null;
			if (session?.user) handleUserLogin(session.user.id);
			else listeners.forEach((l) => l());
		});
	}
}
async function handleUserLogin(userId) {
	await syncLocalToSupabase(userId, data);
	data = await pullSupabaseData(userId, data);
	persist();
	listeners.forEach((l) => l());
}
function persist() {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(KEY, JSON.stringify(data));
	} catch {}
	if (currentUser?.id) syncLocalToSupabase(currentUser.id, data).catch((e) => console.warn("[Background Supabase Sync Warning]:", e));
}
function set(next) {
	data = next;
	persist();
	listeners.forEach((l) => l());
}
function subscribe(cb) {
	listeners.add(cb);
	if (!hydrated) {
		load();
		listeners.forEach((l) => l());
	}
	return () => listeners.delete(cb);
}
var serverSnapshot;
function getServerSnapshot() {
	if (!serverSnapshot) serverSnapshot = seed();
	return serverSnapshot;
}
function useGym() {
	return (0, import_react.useSyncExternalStore)(subscribe, () => data, getServerSnapshot);
}
function useAuthUser() {
	return currentUser;
}
function repLabel(item) {
	if (item.repType === "range" && item.repMin != null && item.repMax != null) return `${item.repMin}–${item.repMax}`;
	return String(item.reps);
}
function saveExercise(ex) {
	const exists = data.exercises.some((e) => e.id === ex.id);
	set({
		...data,
		exercises: exists ? data.exercises.map((e) => e.id === ex.id ? ex : e) : [...data.exercises, ex]
	});
}
function deleteExercise(id) {
	set({
		...data,
		exercises: data.exercises.filter((e) => e.id !== id),
		workouts: data.workouts.map((w) => ({
			...w,
			items: w.items.filter((i) => i.exerciseId !== id)
		}))
	});
}
function emptyExercise() {
	return {
		id: uid(),
		name: "",
		muscleGroup: "חזה",
		muscleGroups: ["חזה"],
		secondaryMuscles: [],
		category: "מורכב",
		equipment: "מוט",
		description: "",
		instructions: "",
		videoUrl: "",
		images: [],
		notes: "",
		tips: ""
	};
}
function saveWorkout(w) {
	const exists = data.workouts.some((x) => x.id === w.id);
	set({
		...data,
		workouts: exists ? data.workouts.map((x) => x.id === w.id ? w : x) : [...data.workouts, w]
	});
}
function saveWorkoutInProgram(programId, w) {
	const workouts = data.workouts.some((x) => x.id === w.id) ? data.workouts.map((x) => x.id === w.id ? w : x) : [...data.workouts, w];
	const programs = data.programs.map((p) => p.id === programId && !p.dayIds.includes(w.id) ? {
		...p,
		dayIds: [...p.dayIds, w.id]
	} : p);
	set({
		...data,
		workouts,
		programs
	});
}
function deleteWorkout(id) {
	set({
		...data,
		workouts: data.workouts.filter((w) => w.id !== id),
		programs: data.programs.map((p) => ({
			...p,
			dayIds: p.dayIds.filter((d) => d !== id)
		}))
	});
}
function duplicateWorkoutDay(programId, dayId) {
	const day = data.workouts.find((w) => w.id === dayId);
	const program = data.programs.find((p) => p.id === programId);
	if (!day || !program) return;
	const copy = {
		...day,
		id: uid(),
		name: `${day.name} (עותק)`,
		items: day.items.map((i) => ({
			...i,
			id: uid()
		}))
	};
	const index = program.dayIds.indexOf(dayId);
	const dayIds = [...program.dayIds];
	dayIds.splice(index + 1, 0, copy.id);
	set({
		...data,
		workouts: [...data.workouts, copy],
		programs: data.programs.map((p) => p.id === programId ? {
			...p,
			dayIds
		} : p)
	});
}
function reorderProgramDays(programId, dayIds) {
	set({
		...data,
		programs: data.programs.map((p) => p.id === programId ? {
			...p,
			dayIds
		} : p)
	});
}
function emptyWorkout() {
	return {
		id: uid(),
		name: "",
		notes: "",
		items: []
	};
}
function emptyItem(exerciseId) {
	return {
		id: uid(),
		exerciseId,
		sets: 3,
		reps: 10,
		repType: "fixed",
		weight: 20,
		rest: 90,
		notes: "",
		warmups: [],
		workingSets: Array.from({ length: 3 }, (_, i) => ({
			id: uid(),
			setNumber: i + 1,
			weight: 20,
			reps: 10
		}))
	};
}
function emptyWarmup() {
	return {
		id: uid(),
		weight: 20,
		reps: 10
	};
}
function saveProgram(p) {
	const exists = data.programs.some((x) => x.id === p.id);
	set({
		...data,
		programs: exists ? data.programs.map((x) => x.id === p.id ? p : x) : [...data.programs, p]
	});
}
function createProgram(name) {
	const p = {
		id: uid(),
		name: name.trim() || "תכנית חדשה",
		notes: "",
		dayIds: []
	};
	set({
		...data,
		programs: [...data.programs, p]
	});
	return p;
}
function deleteProgram(id) {
	const program = data.programs.find((p) => p.id === id);
	const orphan = new Set(program?.dayIds ?? []);
	set({
		...data,
		programs: data.programs.filter((p) => p.id !== id),
		workouts: data.workouts.filter((w) => !orphan.has(w.id))
	});
}
function duplicateProgram(id) {
	const program = data.programs.find((p) => p.id === id);
	if (!program) return;
	const newDays = [];
	const dayIds = program.dayIds.map((dayId) => {
		const day = data.workouts.find((w) => w.id === dayId);
		if (!day) return dayId;
		const copy = {
			...day,
			id: uid(),
			items: day.items.map((i) => ({
				...i,
				id: uid()
			}))
		};
		newDays.push(copy);
		return copy.id;
	});
	set({
		...data,
		workouts: [...data.workouts, ...newDays],
		programs: [...data.programs, {
			id: uid(),
			name: `${program.name} (עותק)`,
			notes: program.notes,
			dayIds
		}]
	});
}
function saveSession(session) {
	set({
		...data,
		history: [session, ...data.history]
	});
}
function lastPerformance(history, exerciseId) {
	for (const s of history) {
		const e = s.entries.find((x) => x.exerciseId === exerciseId);
		if (e) {
			const working = e.sets.filter((x) => !x.warmup);
			if (working.length) return {
				date: s.date,
				sets: working
			};
		}
	}
	return null;
}
function personalRecords(history, exerciseId) {
	let heaviest = 0;
	let bestRepsAtHeaviest = 0;
	let bestEst = 0;
	for (const s of history) for (const e of s.entries) {
		if (e.exerciseId !== exerciseId) continue;
		for (const set of e.sets) {
			if (set.warmup || set.reps === 0) continue;
			if (set.weight > heaviest) {
				heaviest = set.weight;
				bestRepsAtHeaviest = set.reps;
			} else if (set.weight === heaviest && set.reps > bestRepsAtHeaviest) bestRepsAtHeaviest = set.reps;
			const est = set.weight * (1 + set.reps / 30);
			if (est > bestEst) bestEst = est;
		}
	}
	if (heaviest === 0 && bestEst === 0) return null;
	return {
		heaviest,
		bestRepsAtHeaviest,
		estimatedMax: Math.round(bestEst)
	};
}
function saveUserProfile(profile) {
	const updatedWeight = profile.weight;
	const logs = [...data.bodyWeightLogs ?? []];
	const today = todayKey();
	const existingIdx = logs.findIndex((l) => l.date === today);
	if (existingIdx >= 0) logs[existingIdx] = {
		...logs[existingIdx],
		weight: updatedWeight
	};
	else logs.unshift({
		id: uid(),
		date: today,
		weight: updatedWeight
	});
	set({
		...data,
		userProfile: profile,
		bodyWeightLogs: logs
	});
}
/** RMR Calculation using Mifflin-St Jeor formula */
function calculateRmr(profile) {
	const p = profile ?? data.userProfile ?? {
		weight: 65,
		height: 165,
		age: 26,
		gender: "female"
	};
	const w = p.weight || 65;
	const h = p.height || 165;
	const a = p.age || 26;
	const isFemale = p.gender !== "male";
	const baseRmr = 10 * w + 6.25 * h - 5 * a + (isFemale ? -161 : 5);
	const rmr = Math.round(baseRmr);
	const frequency = p.workoutsPerWeek ?? 4;
	let mult = 1.2;
	if (frequency >= 1 && frequency <= 2) mult = 1.375;
	else if (frequency >= 3 && frequency <= 4) mult = 1.55;
	else if (frequency >= 5) mult = 1.725;
	return {
		rmr,
		tdee: Math.round(rmr * mult),
		weight: w
	};
}
function saveFood(food) {
	const exists = data.foods.some((f) => f.id === food.id);
	set({
		...data,
		foods: exists ? data.foods.map((f) => f.id === food.id ? food : f) : [...data.foods, food]
	});
}
function deleteFood(id) {
	set({
		...data,
		foods: data.foods.filter((f) => f.id !== id)
	});
}
function emptyFood() {
	return {
		id: uid(),
		name: "",
		servingSize: "100 גרם",
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0
	};
}
function saveNutritionTargets(targets) {
	set({
		...data,
		nutritionTargets: targets
	});
}
function nutritionDay(d, date) {
	const found = d.nutritionDays.find((x) => x.date === date);
	if (found) return found;
	return {
		date,
		meals: d.mealTemplate.map((name, i) => ({
			id: `tmpl-${date}-${i}`,
			name,
			foods: []
		}))
	};
}
function withDay(date, updater) {
	const existing = data.nutritionDays.find((x) => x.date === date);
	const next = updater(existing ?? {
		date,
		meals: data.mealTemplate.map((name) => ({
			id: uid(),
			name,
			foods: []
		}))
	});
	const days = existing ? data.nutritionDays.map((x) => x.date === date ? next : x) : [next, ...data.nutritionDays];
	set({
		...data,
		nutritionDays: days
	});
}
function addMeal(date, name) {
	withDay(date, (day) => ({
		...day,
		meals: [...day.meals, {
			id: uid(),
			name: name.trim() || "ארוחה חדשה",
			foods: []
		}]
	}));
}
function renameMeal(date, mealId, name) {
	withDay(date, (day) => ({
		...day,
		meals: day.meals.map((m) => m.id === mealId ? {
			...m,
			name
		} : m)
	}));
}
function addFoodToMeal(date, mealId, food) {
	withDay(date, (day) => ({
		...day,
		meals: day.meals.map((m) => m.id === mealId ? {
			...m,
			foods: [...m.foods, food]
		} : m)
	}));
	if (food.foodId) {
		const recent = [food.foodId, ...(data.recentFoods ?? []).filter((id) => id !== food.foodId)];
		set({
			...data,
			recentFoods: recent.slice(0, 20)
		});
	}
}
function updateMealFood(date, mealId, food) {
	withDay(date, (day) => ({
		...day,
		meals: day.meals.map((m) => m.id === mealId ? {
			...m,
			foods: m.foods.map((f) => f.id === food.id ? food : f)
		} : m)
	}));
}
function removeMealFood(date, mealId, foodId) {
	withDay(date, (day) => ({
		...day,
		meals: day.meals.map((m) => m.id === mealId ? {
			...m,
			foods: m.foods.filter((f) => f.id !== foodId)
		} : m)
	}));
}
function mealFoodFromLibrary(food) {
	return {
		id: uid(),
		foodId: food.id,
		name: food.name,
		servingSize: food.servingSize,
		quantity: 1,
		calories: food.calories,
		protein: food.protein,
		carbs: food.carbs,
		fat: food.fat,
		fiber: food.fiber,
		notes: food.notes
	};
}
function normalizeSearch(s) {
	return s.toLocaleLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/['"-]/g, "").trim();
}
function searchFoods(foods, query) {
	const normalized = normalizeSearch(query);
	if (!normalized) return foods;
	const tokens = normalized.split(/\s+/).filter(Boolean);
	return foods.filter((food) => {
		const name = normalizeSearch(food.name);
		const category = normalizeSearch(food.category ?? "");
		const english = normalizeSearch(food.englishName ?? "");
		const terms = (food.searchTerms ?? []).map(normalizeSearch);
		return tokens.every((token) => name.includes(token) || category.includes(token) || english.includes(token) || terms.some((t) => t.includes(token)));
	});
}
function findFoodReplacements(foods, current, query = "") {
	const targetCal = (current.calories ?? 0) * (current.quantity ?? 1);
	return searchFoods(foods, query).filter((food) => {
		if (current.foodId && food.id === current.foodId) return false;
		if (!current.foodId && current.name && food.name === current.name) return false;
		return true;
	}).map((food) => {
		const requiredQty = food.calories > 0 ? targetCal / food.calories : 1;
		return {
			food,
			calculatedQuantity: round1(requiredQty),
			calculatedCalories: Math.round(food.calories * requiredQty),
			calculatedProtein: round1(food.protein * requiredQty),
			calculatedCarbs: round1(food.carbs * requiredQty),
			calculatedFat: round1(food.fat * requiredQty),
			score: Math.abs(food.calories - (current.calories ?? 0))
		};
	}).sort((a, b) => a.score - b.score || a.food.name.localeCompare(b.food.name));
}
var round1 = (n) => Math.round(n * 10) / 10;
function foodTotals(foods) {
	return foods.reduce((t, f) => ({
		calories: t.calories + f.calories * f.quantity,
		protein: t.protein + f.protein * f.quantity,
		carbs: t.carbs + f.carbs * f.quantity,
		fat: t.fat + f.fat * f.quantity,
		fiber: t.fiber + (f.fiber ?? 0) * f.quantity
	}), {
		calories: 0,
		protein: 0,
		carbs: 0,
		fat: 0,
		fiber: 0
	});
}
function dayTotals(day) {
	const t = foodTotals(day.meals.flatMap((m) => m.foods));
	return {
		calories: Math.round(t.calories),
		protein: round1(t.protein),
		carbs: round1(t.carbs),
		fat: round1(t.fat),
		fiber: round1(t.fiber)
	};
}
function AppShell({ title, subtitle, kicker, action, children }) {
	const store = useGym();
	const user = useAuthUser();
	const role = store.userProfile?.role || "client";
	const isOwner = role === "owner";
	const isCoach = role === "coach" || isOwner;
	const NAV = [
		{
			to: "/",
			label: "בית",
			id: "home",
			icon: House
		},
		{
			to: "/programs",
			label: "תוכניות",
			id: "programs",
			icon: LayoutGrid
		},
		...isCoach ? [{
			to: "/exercises",
			label: "תרגילים",
			id: "exercises",
			icon: Dumbbell
		}] : [],
		{
			to: "/nutrition",
			label: "תזונה",
			id: "nutrition",
			icon: Apple
		}
	];
	const [showAuthModal, setShowAuthModal] = (0, import_react.useState)(false);
	const [isSignUp, setIsSignUp] = (0, import_react.useState)(false);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [errorMsg, setErrorMsg] = (0, import_react.useState)("");
	const handleAuthSubmit = async (e) => {
		e.preventDefault();
		setLoading(true);
		setErrorMsg("");
		try {
			if (isSignUp) {
				const { error } = await supabase.auth.signUp({
					email,
					password
				});
				if (error) throw error;
			} else {
				const { error } = await supabase.auth.signInWithPassword({
					email,
					password
				});
				if (error) throw error;
			}
			setShowAuthModal(false);
			setEmail("");
			setPassword("");
		} catch (err) {
			setErrorMsg(err?.message || "אירעה שגיאה בחיבור ל-Supabase");
		} finally {
			setLoading(false);
		}
	};
	const handleSignOut = async () => {
		await supabase.auth.signOut();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-[100dvh] w-full bg-background text-foreground",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-border/30 bg-background/85 backdrop-blur-xl",
				style: { paddingTop: "max(0.6rem, env(safe-area-inset-top))" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto w-full max-w-md px-5 pb-3.5 pt-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 text-start",
							children: [
								kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1 text-[11px] font-bold tracking-[0.14em] text-primary uppercase",
									children: kicker
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "truncate font-display text-[26px] font-extrabold leading-[1.1] tracking-tight text-ink",
									children: title
								}),
								subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 truncate text-[13px] leading-snug text-muted-foreground",
									children: subtitle
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 items-center gap-2 pt-0.5",
							children: [
								isOwner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/coach",
									className: "flex items-center gap-1 rounded-full bg-purple-100 px-2.5 py-1 text-xs font-bold text-purple-800 border border-purple-300 shadow-xs hover:bg-purple-200 transition-colors",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-3.5 w-3.5 text-purple-700" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "בעלים" })]
								}) : isCoach ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/coach",
									className: "flex items-center gap-1 rounded-full bg-amber-100/80 px-2.5 py-1 text-xs font-bold text-amber-800 border border-amber-300/60 shadow-xs hover:bg-amber-200 transition-colors",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-3.5 w-3.5 text-amber-700" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "מאמן" })]
								}) : null,
								user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 border border-emerald-200/60 shadow-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "h-3.5 w-3.5 text-emerald-600 animate-pulse" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "max-w-[80px] truncate",
											children: user.email?.split("@")[0]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: handleSignOut,
											title: "התנתק",
											className: "mr-0.5 text-emerald-600 hover:text-emerald-900 cursor-pointer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-3.5 w-3.5" })
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setShowAuthModal(true),
									className: "flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1.5 text-xs font-bold text-primary hover:bg-primary/20 transition-colors cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "התחברות" })]
								}),
								action
							]
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "page-enter mx-auto w-full max-w-md px-4 pb-8 pt-4 sm:px-5",
				style: { paddingBottom: "calc(6.5rem + env(safe-area-inset-bottom))" },
				children
			}),
			showAuthModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-3xl border border-white/80 bg-white p-6 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-5 w-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold text-lg text-ink",
									children: isSignUp ? "הרשמה ל-My Routine" : "התחברות ל-My Routine"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setShowAuthModal(false),
								className: "text-muted-foreground hover:text-ink font-bold text-sm px-2 cursor-pointer",
								children: "✕"
							})]
						}),
						errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-xl bg-red-50 p-3 text-xs text-red-600 font-semibold border border-red-200",
							children: errorMsg
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleAuthSubmit,
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-muted-foreground mb-1",
									children: "כתובת אימייל"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									className: "w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-primary",
									placeholder: "name@example.com"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-muted-foreground mb-1",
									children: "סיסמה"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									required: true,
									minLength: 6,
									value: password,
									onChange: (e) => setPassword(e.target.value),
									className: "w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-primary",
									placeholder: "••••••••"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: loading,
									className: "w-full rounded-2xl bg-primary py-2.5 text-sm font-bold text-white shadow-md hover:bg-primary/90 disabled:opacity-50 cursor-pointer",
									children: loading ? "מעבד..." : isSignUp ? "צור חשבון" : "התחבר"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-center pt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setIsSignUp(!isSignUp),
								className: "text-xs font-bold text-primary hover:underline cursor-pointer",
								children: isSignUp ? "כבר יש לך חשבון? התחבר כאן" : "אין לך חשבון? הירשם כאן"
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "ניווט ראשי",
				className: "pointer-events-none fixed inset-x-0 bottom-0 z-40 px-3.5 sm:px-4",
				style: { paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-auto mx-auto flex max-w-md items-center justify-between rounded-[2rem] border border-white/70 bg-white/85 p-1.5 shadow-[0_12px_36px_oklch(0.22_0.02_145/0.12),0_2px_10px_oklch(0.22_0.02_145/0.05)] backdrop-blur-2xl",
					children: NAV.map(({ to, label, id, icon: Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to,
						activeOptions: { exact: to === "/" },
						"data-testid": `link-nav-${id}`,
						className: "group relative flex min-h-[3.6rem] min-w-[3.4rem] flex-1 flex-col items-center justify-center gap-0.5 rounded-[1.4rem] py-1 text-muted-foreground transition-all duration-200 data-[status=active]:bg-primary/12 data-[status=active]:text-primary hover:text-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "h-[21px] w-[21px] transition-transform duration-200 group-data-[status=active]:scale-110",
								strokeWidth: 2.2
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10.5px] font-bold leading-none",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-0.5 h-1 w-1 rounded-full bg-primary opacity-0 transition-opacity duration-200 group-data-[status=active]:opacity-100" })
						]
					}, to))
				})
			})
		]
	});
}
//#endregion
export { removeMealFood as A, saveWorkout as B, findFoodReplacements as C, nutritionDay as D, mealFoodFromLibrary as E, saveFood as F, updateMealFood as G, supabase as H, saveNutritionTargets as I, useGym as K, saveProgram as L, reorderProgramDays as M, repLabel as N, personalRecords as O, saveExercise as P, saveSession as R, emptyWorkout as S, lastPerformance as T, todayKey as U, saveWorkoutInProgram as V, uid as W, duplicateWorkoutDay as _, EXERCISE_CATEGORIES as a, emptyItem as b, addMeal as c, dayTotals as d, deleteExercise as f, duplicateProgram as g, deleteWorkout as h, EQUIPMENT as i, renameMeal as j, pullClientDataForCoach as k, calculateRmr as l, deleteProgram as m, AppShell as n, MUSCLE_GROUPS as o, deleteFood as p, CARDIO_TYPES as r, addFoodToMeal as s, ANIMAL_CHARACTERS as t, createProgram as u, emptyExercise as v, foodTotals as w, emptyWarmup as x, emptyFood as y, saveUserProfile as z };
