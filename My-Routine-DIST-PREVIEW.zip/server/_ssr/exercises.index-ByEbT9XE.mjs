import { r as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { $ as ChevronLeft, E as Plus, G as Dumbbell, S as Search, b as Shield, g as SlidersHorizontal } from "../_libs/lucide-react.mjs";
import { K as useGym, i as EQUIPMENT, n as AppShell, o as MUSCLE_GROUPS } from "./AppShell-B7KD4DGt.mjs";
import { i as Pill, n as EmptyState, s as SectionHeader } from "./primitives-dLo4KDUl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exercises.index-ByEbT9XE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Library() {
	const { exercises, userProfile } = useGym();
	const navigate = useNavigate();
	const isCoach = userProfile?.role === "coach";
	(0, import_react.useEffect)(() => {
		if (userProfile && !isCoach) navigate({ to: "/" });
	}, [
		userProfile,
		isCoach,
		navigate
	]);
	const [q, setQ] = (0, import_react.useState)("");
	const [group, setGroup] = (0, import_react.useState)("הכל");
	const [equipment, setEquipment] = (0, import_react.useState)("הכל");
	const [filtersOpen, setFiltersOpen] = (0, import_react.useState)(false);
	if (!isCoach) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "ספריית תרגילים",
		kicker: "גישת מאמן בלבד",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card p-6 text-center space-y-4 rounded-3xl mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-600",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-7 w-7" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold text-ink",
					children: "גישה שמורה למאמנים"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground leading-relaxed",
					children: "ספריית התרגילים הכללית מנוהלת על ידי המאמן שלך. התרגילים שהוקצו עבורך מופיעים ישירות בתוך בלשונית \"תוכניות\"."
				})
			]
		})
	});
	const query = q.toLowerCase();
	const list = exercises.filter((e) => (group === "הכל" || e.muscleGroup === group || (e.muscleGroups ?? []).includes(group)) && (equipment === "הכל" || e.equipment === equipment) && (e.name.toLowerCase().includes(query) || e.equipment.toLowerCase().includes(query) || e.muscleGroup.toLowerCase().includes(query) || (e.customMuscleGroup ?? "").toLowerCase().includes(query) || (e.category ?? "").toLowerCase().includes(query)));
	const activeFilters = (group !== "הכל" ? 1 : 0) + (equipment !== "הכל" ? 1 : 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		kicker: "ספרייה",
		title: "תרגילים",
		subtitle: `${exercises.length} תרגילים בספרייה`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/exercises/$exerciseId",
			params: { exerciseId: "new" },
			"aria-label": "הוסף תרגיל",
			className: "press grid h-11 w-11 place-items-center rounded-2xl bg-primary text-primary-foreground cursor-pointer",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
				className: "h-5 w-5",
				strokeWidth: 2.4
			})
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "num-pill flex h-12 items-center gap-2 px-3.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 shrink-0 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "חפשי לפי שם תרגיל, ציוד או שריר...",
						className: "w-full min-w-0 bg-transparent text-[14px] outline-none placeholder:text-muted-foreground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setFiltersOpen((v) => !v),
						className: "press relative grid h-9 w-9 place-items-center rounded-xl text-muted-foreground hover:bg-secondary cursor-pointer",
						"aria-label": "סינון",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-4 w-4" }), activeFilters > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -top-0.5 -end-0.5 grid h-4 w-4 place-items-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground",
							children: activeFilters
						}) : null]
					})
				]
			}),
			(group !== "הכל" || equipment !== "הכל") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-1.5",
				children: [group !== "הכל" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
					active: true,
					onClick: () => setGroup("הכל"),
					variant: "sage",
					children: [group, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[12px] leading-none",
						children: "×"
					})]
				}) : null, equipment !== "הכל" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pill, {
					active: true,
					onClick: () => setEquipment("הכל"),
					variant: "rose",
					children: [equipment, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[12px] leading-none",
						children: "×"
					})]
				}) : null]
			}),
			filtersOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-card mt-3 p-4 text-start",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						title: "סינון לפי שריר",
						className: "mb-2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "-mx-1 flex gap-2 overflow-x-auto px-1 pb-2 no-scrollbar",
						children: ["הכל", ...MUSCLE_GROUPS].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setGroup(g),
							className: `press shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-semibold transition-colors cursor-pointer ${group === g ? "bg-primary text-primary-foreground shadow-sm" : "bg-secondary text-muted-foreground"}`,
							children: g
						}, g))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						title: "סינון לפי ציוד",
						className: "mb-2 mt-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "-mx-1 flex gap-2 overflow-x-auto px-1 pb-2 no-scrollbar",
						children: ["הכל", ...EQUIPMENT].map((eq) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setEquipment(eq),
							className: `press shrink-0 rounded-full px-3 py-1.5 text-[11.5px] font-semibold transition-colors cursor-pointer ${equipment === eq ? "bg-primary text-primary-foreground shadow-sm" : "bg-secondary text-muted-foreground"}`,
							children: eq
						}, eq))
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				className: "mt-5 text-start",
				title: `${list.length} תרגילים בספרייה`,
				subtitle: "לחצי על תרגיל לעריכה ופרטים"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2.5",
				children: list.map((e) => {
					const primary = e.muscleGroup === "אחר" && e.customMuscleGroup ? e.customMuscleGroup : e.muscleGroup;
					const secondaryCount = (e.muscleGroups?.length ?? 1) - 1;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/exercises/$exerciseId",
						params: { exerciseId: e.id },
						className: "surface-card press flex items-center gap-3.5 p-3.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-sage-soft text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, {
									className: "h-5 w-5",
									strokeWidth: 1.8
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1 text-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-display text-[15px] font-semibold text-ink",
									children: e.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-0.5 truncate text-[12px] text-muted-foreground",
									children: [
										primary,
										secondaryCount > 0 ? ` (+${secondaryCount})` : "",
										e.category ? ` · ${e.category}` : ""
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "num-pill shrink-0 px-2.5 py-1 text-[11px] font-medium text-muted-foreground",
								children: e.equipment
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4 shrink-0 text-muted-foreground/60" })
						]
					}, e.id);
				})
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Dumbbell,
				title: "לא נמצאו תרגילים",
				description: q || activeFilters > 0 ? "נסי לשנות את החיפוש או הסינון." : "התחילי לבנות את ספריית התרגילים שלך.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/exercises/$exerciseId",
					params: { exerciseId: "new" },
					className: "press inline-flex h-11 items-center gap-2 rounded-full bg-primary px-5 text-[13.5px] font-semibold text-primary-foreground cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "h-4 w-4",
						strokeWidth: 2.4
					}), "תרגיל חדש"]
				})
			}) : null
		]
	});
}
//#endregion
export { Library as component };
