import { r as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { $ as ChevronLeft, C as Save, E as Plus, G as Dumbbell, M as MessageSquare, S as Search, b as Shield, i as Users, it as Award, k as Pen, o as UserPlus, q as Crown, s as UserCheck, st as Apple, u as Trash2 } from "../_libs/lucide-react.mjs";
import { H as supabase, K as useGym, W as uid, k as pullClientDataForCoach, n as AppShell } from "./AppShell-B7KD4DGt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/coach-koFGG_rq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CoachDashboardPage() {
	const store = useGym();
	const role = store.userProfile?.role || "client";
	const isOwner = role === "owner";
	const isCoach = role === "coach" || isOwner;
	const [clients, setClients] = (0, import_react.useState)(store.clients || []);
	const [allProfiles, setAllProfiles] = (0, import_react.useState)([]);
	const [clientSearch, setClientSearch] = (0, import_react.useState)("");
	const [selectedClientId, setSelectedClientId] = (0, import_react.useState)(null);
	const [clientDetails, setClientDetails] = (0, import_react.useState)(null);
	const [loadingDetails, setLoadingDetails] = (0, import_react.useState)(false);
	const [inviteEmail, setInviteEmail] = (0, import_react.useState)("");
	const [inviteMsg, setInviteMsg] = (0, import_react.useState)("");
	const [showAddModal, setShowAddModal] = (0, import_react.useState)(false);
	const [coachMsgText, setCoachMsgText] = (0, import_react.useState)("");
	const [msgSentNotice, setMsgSentNotice] = (0, import_react.useState)("");
	const [newProgramName, setNewProgramName] = (0, import_react.useState)("");
	const [editingProgramId, setEditingProgramId] = (0, import_react.useState)(null);
	const [editingDayId, setEditingDayId] = (0, import_react.useState)(null);
	const [newDayName, setNewDayName] = (0, import_react.useState)("");
	const [selectedExId, setSelectedExId] = (0, import_react.useState)("");
	const [targetWeight, setTargetWeight] = (0, import_react.useState)(20);
	const [setsCount, setSetsCount] = (0, import_react.useState)(3);
	const [repMin, setRepMin] = (0, import_react.useState)(8);
	const [repMax, setRepMax] = (0, import_react.useState)(10);
	const [restSec, setRestSec] = (0, import_react.useState)(90);
	const [techNotes, setTechniqueNotes] = (0, import_react.useState)("");
	const [supersetGroup, setSupersetGroup] = (0, import_react.useState)("");
	const [dropSetEnabled, setDropSetEnabled] = (0, import_react.useState)(false);
	const [dropSetCount, setDropSetCount] = (0, import_react.useState)(1);
	const [approvedAltIds, setApprovedAltIds] = (0, import_react.useState)([]);
	const [editingNutrition, setEditingNutrition] = (0, import_react.useState)(false);
	const [calTarget, setCalTarget] = (0, import_react.useState)(2e3);
	const [protTarget, setProtTarget] = (0, import_react.useState)(140);
	const loadCoachClients = async () => {
		const { data: { user } } = await supabase.auth.getUser();
		if (!user) return;
		const { data } = await supabase.from("coach_clients").select("id, client_id, created_at, profiles!coach_clients_client_id_fkey(email, full_name, weight_kg)").eq("coach_id", user.id);
		if (data) setClients(data);
	};
	const loadAllProfilesForOwner = async () => {
		if (!isOwner) return;
		const { data } = await supabase.from("profiles").select("*");
		if (data) setAllProfiles(data);
	};
	(0, import_react.useEffect)(() => {
		if (isCoach) loadCoachClients();
		if (isOwner) loadAllProfilesForOwner();
	}, [isCoach, isOwner]);
	(0, import_react.useEffect)(() => {
		if (!selectedClientId) {
			setClientDetails(null);
			return;
		}
		setLoadingDetails(true);
		pullClientDataForCoach(selectedClientId).then((res) => {
			setClientDetails(res);
			setLoadingDetails(false);
		});
	}, [selectedClientId]);
	const handleOwnerChangeRole = async (targetUserId, newRole) => {
		try {
			const { error } = await supabase.rpc("change_user_role", {
				target_user_id: targetUserId,
				new_role: newRole
			});
			if (error) throw error;
			loadAllProfilesForOwner();
			alert(`תפקיד המשתמש עודכן בהצלחה ל-${newRole === "coach" ? "מאמן" : "מתאמן"}`);
		} catch (err) {
			alert(err?.message || "שגיאה בשינוי תפקיד");
		}
	};
	const handleSendCoachMessage = async (e) => {
		e.preventDefault();
		if (!selectedClientId || !coachMsgText.trim()) return;
		try {
			const { data: { user } } = await supabase.auth.getUser();
			if (!user) return;
			const { error } = await supabase.from("coach_messages").insert({
				coach_id: user.id,
				client_id: selectedClientId,
				message: coachMsgText.trim()
			});
			if (!error) {
				setMsgSentNotice("הודעת החיזוק נשלחה בהצלחה למתאמן!");
				setCoachMsgText("");
				setTimeout(() => setMsgSentNotice(""), 3e3);
			}
		} catch {}
	};
	const handleAddClient = async (e) => {
		e.preventDefault();
		setInviteMsg("");
		try {
			const { data: { user } } = await supabase.auth.getUser();
			if (!user) throw new Error("מנוי לא מחובר");
			const { data: lookupRes, error: lookupErr } = await supabase.rpc("lookup_client_id_by_email", { lookup_email: inviteEmail.trim() });
			if (lookupErr || !lookupRes || lookupRes.length === 0) throw new Error("משתמש לא נמצא. יש לוודא שהמתאמן נרשם ל-My Routine בכתובת זו.");
			const foundClientId = lookupRes[0].client_id;
			const { error: linkErr } = await supabase.from("coach_clients").insert({
				coach_id: user.id,
				client_id: foundClientId
			});
			if (linkErr) throw linkErr;
			setInviteMsg("המתאמן שויך בהצלחה לחשבון המאמן שלך!");
			setInviteEmail("");
			setShowAddModal(false);
			loadCoachClients();
		} catch (err) {
			setInviteMsg(err?.message || "אירעה שגיאה בשיוך המתאמן");
		}
	};
	const handleRemoveClient = async (linkId) => {
		if (!confirm("האם למחוק את המתאמן מלוח הבקרה שלך?")) return;
		await supabase.from("coach_clients").delete().eq("id", linkId);
		if (selectedClientId === clients.find((c) => c.id === linkId)?.client_id) setSelectedClientId(null);
		loadCoachClients();
	};
	const handleCreateClientProgram = async (e) => {
		e.preventDefault();
		if (!selectedClientId || !newProgramName.trim()) return;
		const programId = uid();
		const { error } = await supabase.from("programs").insert({
			id: programId,
			user_id: selectedClientId,
			name: newProgramName.trim(),
			description: "תוכנית נבנתה על ידי המאמן"
		});
		if (!error) {
			setNewProgramName("");
			pullClientDataForCoach(selectedClientId).then(setClientDetails);
		}
	};
	const handleAddProgramDay = async (e) => {
		e.preventDefault();
		if (!selectedClientId || !editingProgramId || !newDayName.trim()) return;
		const dayId = uid();
		const { error } = await supabase.from("program_days").insert({
			id: dayId,
			program_id: editingProgramId,
			user_id: selectedClientId,
			name: newDayName.trim(),
			items: [],
			sort_order: (clientDetails?.workouts?.length || 0) + 1
		});
		if (!error) {
			setNewDayName("");
			pullClientDataForCoach(selectedClientId).then(setClientDetails);
		}
	};
	const handleAddExerciseToDay = async (e) => {
		e.preventDefault();
		if (!selectedClientId || !editingDayId || !selectedExId) return;
		const currentDay = clientDetails?.workouts?.find((w) => w.id === editingDayId);
		if (!currentDay) return;
		const newWorkoutItem = {
			id: uid(),
			exerciseId: selectedExId,
			sets: setsCount,
			reps: repMin,
			repType: "range",
			repMin,
			repMax,
			targetWeight,
			weight: targetWeight,
			rest: restSec,
			notes: "",
			techniqueNotes: techNotes.trim() || void 0,
			approvedAlternatives: approvedAltIds.length > 0 ? approvedAltIds : void 0,
			supersetId: supersetGroup.trim() || void 0,
			dropSetConfig: dropSetEnabled ? {
				enabled: true,
				drops: dropSetCount,
				percentReduction: 20
			} : void 0,
			workingSets: Array.from({ length: setsCount }, (_, i) => ({
				id: uid(),
				setNumber: i + 1,
				weight: targetWeight,
				reps: repMin,
				repMax
			}))
		};
		const updatedItems = [...currentDay.items, newWorkoutItem];
		const { error } = await supabase.from("program_days").update({
			items: updatedItems,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", editingDayId);
		if (!error) {
			setSelectedExId("");
			setTechniqueNotes("");
			setSupersetGroup("");
			setDropSetEnabled(false);
			setApprovedAltIds([]);
			pullClientDataForCoach(selectedClientId).then(setClientDetails);
		}
	};
	const handleRemoveExerciseFromDay = async (dayId, itemId) => {
		const currentDay = clientDetails?.workouts?.find((w) => w.id === dayId);
		if (!currentDay) return;
		const updatedItems = currentDay.items.filter((i) => i.id !== itemId);
		const { error } = await supabase.from("program_days").update({
			items: updatedItems,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", dayId);
		if (!error) pullClientDataForCoach(selectedClientId).then(setClientDetails);
	};
	const handleSaveNutritionTargets = async () => {
		if (!selectedClientId) return;
		const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
		const { error } = await supabase.from("nutrition_days").upsert({
			id: `${selectedClientId}_${today}`,
			user_id: selectedClientId,
			date: today,
			target_calories: calTarget,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		});
		if (!error) {
			setEditingNutrition(false);
			pullClientDataForCoach(selectedClientId).then(setClientDetails);
		}
	};
	if (!isCoach) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "דשבורד מאמן",
		kicker: "מאמנים וצוות מקצועי",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card p-6 text-center space-y-4 rounded-3xl mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-600",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-7 w-7" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold text-ink",
					children: "גישת מאמן מוגבלת"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground leading-relaxed",
					children: "חשבונך מוגדר כחבר/מתאמן (Client). דשבורד זה מיועד למאמנים אישיים בלבד לניהול תוכניות ותזונת מתאמנים."
				})
			]
		})
	});
	const filteredClients = clients.filter((c) => {
		const emailStr = (c.profiles?.email || "").toLowerCase();
		const nameStr = (c.profiles?.full_name || "").toLowerCase();
		const q = clientSearch.toLowerCase();
		return !q || emailStr.includes(q) || nameStr.includes(q);
	});
	const selectedClientInfo = clients.find((c) => c.client_id === selectedClientId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: isOwner ? "ניהול מערכת ובעלים" : "לוח בקרה למאמן",
		subtitle: "ניהול תוכניות אימון, תזונה, הרשאות ומעקב מתאמנים",
		kicker: isOwner ? "בעלי הפלטפורמה" : "מאמן מוסמך",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => setShowAddModal(true),
			className: "flex items-center gap-1 rounded-full bg-primary px-3.5 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-primary/90 transition-colors cursor-pointer",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "הוסף מתאמן" })]
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5 text-start",
			children: [
				isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card p-5 rounded-3xl space-y-3 bg-purple-50/60 border border-purple-200",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-purple-200/60 pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-5 w-5 text-purple-700" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-bold text-sm text-purple-950",
								children: "אזור ניהול בעלים (Owner Management)"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[11px] font-bold text-purple-800 bg-purple-100 px-2 py-0.5 rounded-full",
							children: [allProfiles.length, " משתמשים במערכת"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-purple-900 font-semibold",
							children: "משתמשים והרשאות תפקיד:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-1.5 max-h-48 overflow-y-auto",
							children: allProfiles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between rounded-xl bg-white p-2.5 text-xs border border-purple-100",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-ink",
									children: p.full_name || p.email
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground mr-1",
									children: [
										"(",
										p.role || "client",
										")"
									]
								})] }), p.role !== "owner" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-1",
									children: p.role === "client" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => handleOwnerChangeRole(p.id, "coach"),
										className: "rounded-lg bg-amber-100 px-2 py-1 text-[11px] font-bold text-amber-800 hover:bg-amber-200 cursor-pointer",
										children: "הפוך למאמן"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => handleOwnerChangeRole(p.id, "client"),
										className: "rounded-lg bg-gray-100 px-2 py-1 text-[11px] font-bold text-gray-700 hover:bg-gray-200 cursor-pointer",
										children: "הסר הרשאת מאמן"
									})
								})]
							}, p.id))
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "surface-card p-5 rounded-3xl space-y-3 bg-linear-to-br from-rose-50/60 to-primary/5 border border-primary/15",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-10 w-10 items-center justify-center rounded-2xl bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-bold text-base text-ink",
								children: "לוח מאמן פעיל"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [clients.length, " מתאמנים רשומים תחת לוח זה"]
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-0.5 text-[11px] font-bold text-emerald-800",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "h-3 w-3" }), " מחובר כמאמן"]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-between px-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-bold text-sm text-ink flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-primary" }), " רשימת המתאמנים שלי"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "num-pill flex h-10 items-center gap-2 px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-3.5 w-3.5 text-muted-foreground shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: clientSearch,
								onChange: (e) => setClientSearch(e.target.value),
								placeholder: "סינון מתאמנים לפי שם או אימייל...",
								className: "w-full bg-transparent text-xs outline-none"
							})]
						}),
						filteredClients.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "surface-card p-6 text-center text-muted-foreground rounded-2xl text-xs space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "לא נמצאו מתאמנים רשומים." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setShowAddModal(true),
								className: "text-primary font-bold hover:underline cursor-pointer",
								children: "לחצי כאן להוספת מתאמן לפי אימייל"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 gap-2.5",
							children: filteredClients.map((c) => {
								const isSelected = c.client_id === selectedClientId;
								const emailStr = c.profiles?.email || "מתאמן";
								const nameStr = c.profiles?.full_name || emailStr.split("@")[0];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									onClick: () => {
										setSelectedClientId(isSelected ? null : c.client_id);
										setEditingProgramId(null);
										setEditingDayId(null);
									},
									className: `surface-card p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${isSelected ? "border-primary bg-primary/5 shadow-xs" : "border-border/60 hover:border-border"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary font-bold text-sm",
											children: nameStr.charAt(0).toUpperCase()
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-sm text-ink",
											children: nameStr
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: emailStr
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: (e) => {
												e.stopPropagation();
												handleRemoveClient(c.id);
											},
											className: "p-1.5 text-muted-foreground hover:text-red-600 rounded-lg transition-colors cursor-pointer",
											title: "הסר מתאמן",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: `h-5 w-5 text-muted-foreground transition-transform ${isSelected ? "-rotate-90 text-primary" : ""}` })]
									})]
								}, c.id);
							})
						})
					]
				}),
				selectedClientId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 pt-2 border-t border-border/40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-bold text-base text-ink flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "תיק מתאמן:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary font-extrabold",
								children: selectedClientInfo?.profiles?.full_name || selectedClientInfo?.profiles?.email
							})]
						})
					}), loadingDetails ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "surface-card p-6 text-center text-xs text-muted-foreground animate-pulse",
						children: "טוען נתוני מתאמן מ-Supabase..."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "surface-card p-4 rounded-2xl space-y-2.5 border border-primary/20 bg-primary/5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "font-bold text-xs text-primary flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "h-4 w-4" }), " שליחת הודעת חיזוק / הנחיה למתאמן"]
									}),
									msgSentNotice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold text-emerald-700 bg-emerald-50 p-2 rounded-xl border border-emerald-200",
										children: msgSentNotice
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										onSubmit: handleSendCoachMessage,
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											required: true,
											value: coachMsgText,
											onChange: (e) => setCoachMsgText(e.target.value),
											placeholder: "הקלידי הודעה שתופיע במסך הבית של המתאמן...",
											className: "flex-1 rounded-xl border border-border bg-white px-3 py-1.5 text-xs outline-none focus:border-primary"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "submit",
											className: "rounded-xl bg-primary px-3 py-1.5 text-xs font-bold text-white shadow-xs cursor-pointer hover:bg-primary/90",
											children: "שלח"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "surface-card p-4 rounded-2xl space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center justify-between border-b pb-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "font-bold text-sm text-ink flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, { className: "h-4 w-4 text-primary" }), " בונה התוכניות והאימונים למתאמן"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										onSubmit: handleCreateClientProgram,
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											required: true,
											value: newProgramName,
											onChange: (e) => setNewProgramName(e.target.value),
											placeholder: "שם תוכנית אימון חדשה...",
											className: "flex-1 rounded-xl border border-border px-3 py-1.5 text-xs outline-none focus:border-primary"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "submit",
											className: "flex items-center gap-1 rounded-xl bg-primary px-3 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-primary/90 cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "צור" })]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-3 pt-2",
										children: clientDetails?.programs?.map((prog) => {
											const isProgActive = editingProgramId === prog.id;
											const progDays = clientDetails?.workouts?.filter((w) => prog.dayIds?.includes(w.id));
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-2xl border border-border/70 p-3 space-y-2.5 bg-muted/20",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-sm text-ink",
														children: prog.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => setEditingProgramId(isProgActive ? null : prog.id),
														className: "text-xs font-bold text-primary hover:underline flex items-center gap-1 cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "h-3 w-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isProgActive ? "סגור עריכה" : "נהל ימי אימון" })]
													})]
												}), isProgActive && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-3 pt-2 border-t border-border/40",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
														onSubmit: handleAddProgramDay,
														className: "flex gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "text",
															required: true,
															value: newDayName,
															onChange: (e) => setNewDayName(e.target.value),
															placeholder: "שם יום אימון (למשל: A - פלג גוף עליון)...",
															className: "flex-1 rounded-xl border border-border px-3 py-1.5 text-xs outline-none focus:border-primary"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "submit",
															className: "rounded-xl bg-primary/10 px-3 py-1.5 text-xs font-bold text-primary hover:bg-primary/20 cursor-pointer",
															children: "+ יום"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "space-y-2",
														children: progDays?.map((dayItem) => {
															const isDayActive = editingDayId === dayItem.id;
															return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "rounded-xl bg-white p-3 border border-border/60 space-y-2",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "flex items-center justify-between",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																			className: "font-bold text-xs text-ink",
																			children: [
																				dayItem.name,
																				" (",
																				dayItem.items?.length || 0,
																				" תרגילים)"
																			]
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																			onClick: () => setEditingDayId(isDayActive ? null : dayItem.id),
																			className: "text-[11px] font-bold text-primary hover:underline cursor-pointer",
																			children: isDayActive ? "סגור" : "+ שייך תרגיל מותאם"
																		})]
																	}),
																	dayItem.items?.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "space-y-1.5 pt-1",
																		children: dayItem.items.map((exItem) => {
																			const exMeta = store.exercises.find((e) => e.id === exItem.exerciseId);
																			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																				className: "flex items-center justify-between rounded-lg bg-secondary/50 p-2 text-xs",
																				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																					className: "font-bold text-ink",
																					children: exMeta?.name || "תרגיל"
																				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																					className: "text-muted-foreground mr-1",
																					children: [
																						"· ",
																						exItem.targetWeight || exItem.weight,
																						" ק\"ג ·",
																						" ",
																						exItem.sets,
																						"×",
																						exItem.repMin || exItem.reps,
																						exItem.repMax ? `-${exItem.repMax}` : ""
																					]
																				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																					onClick: () => handleRemoveExerciseFromDay(dayItem.id, exItem.id),
																					className: "text-muted-foreground hover:text-red-600 p-1 cursor-pointer",
																					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" })
																				})]
																			}, exItem.id);
																		})
																	}),
																	isDayActive && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
																		onSubmit: handleAddExerciseToDay,
																		className: "pt-2 border-t border-border/40 space-y-2 text-xs",
																		children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
																				className: "block text-[10px] font-bold text-muted-foreground mb-1",
																				children: "בחר תרגיל מספרייה"
																			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
																				required: true,
																				value: selectedExId,
																				onChange: (e) => setSelectedExId(e.target.value),
																				className: "w-full rounded-lg border border-border px-2 py-1.5 text-xs outline-none",
																				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																					value: "",
																					children: "-- בחר תרגיל --"
																				}), store.exercises.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																					value: e.id,
																					children: [
																						e.name,
																						" (",
																						e.muscleGroup,
																						")"
																					]
																				}, e.id))]
																			})] }),
																			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																				className: "grid grid-cols-4 gap-1.5",
																				children: [
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
																						className: "block text-[9px] font-bold text-muted-foreground",
																						children: "משקל יעד (kg)"
																					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																						type: "number",
																						value: targetWeight,
																						onChange: (e) => setTargetWeight(Number(e.target.value)),
																						className: "w-full rounded-md border p-1 text-center"
																					})] }),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
																						className: "block text-[9px] font-bold text-muted-foreground",
																						children: "סטים"
																					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																						type: "number",
																						value: setsCount,
																						onChange: (e) => setSetsCount(Number(e.target.value)),
																						className: "w-full rounded-md border p-1 text-center"
																					})] }),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
																						className: "block text-[9px] font-bold text-muted-foreground",
																						children: "חזרות מינ'"
																					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																						type: "number",
																						value: repMin,
																						onChange: (e) => setRepMin(Number(e.target.value)),
																						className: "w-full rounded-md border p-1 text-center"
																					})] }),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
																						className: "block text-[9px] font-bold text-muted-foreground",
																						children: "חזרות מקס'"
																					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																						type: "number",
																						value: repMax,
																						onChange: (e) => setRepMax(Number(e.target.value)),
																						className: "w-full rounded-md border p-1 text-center"
																					})] })
																				]
																			}),
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																				type: "submit",
																				className: "w-full rounded-lg bg-primary py-1.5 font-bold text-white shadow-xs cursor-pointer",
																				children: "שמור תרגיל ליום אימון"
																			})
																		]
																	})
																]
															}, dayItem.id);
														})
													})]
												})]
											}, prog.id);
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "surface-card p-4 rounded-2xl space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "font-bold text-sm text-ink flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Apple, { className: "h-4 w-4 text-primary" }), " יעד קלורי ותזונה למתאמן"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setEditingNutrition(!editingNutrition),
										className: "text-primary text-xs font-bold hover:underline flex items-center gap-1 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "h-3 w-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: editingNutrition ? "ביטול" : "ערוך יעדים" })]
									})]
								}), editingNutrition ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-bold text-muted-foreground mb-1",
											children: "קלוריות (kcal)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											value: calTarget,
											onChange: (e) => setCalTarget(Number(e.target.value)),
											className: "w-full rounded-xl border border-border px-3 py-1.5 text-xs outline-none focus:border-primary"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-bold text-muted-foreground mb-1",
											children: "חלבון (g)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											value: protTarget,
											onChange: (e) => setProtTarget(Number(e.target.value)),
											className: "w-full rounded-xl border border-border px-3 py-1.5 text-xs outline-none focus:border-primary"
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: handleSaveNutritionTargets,
										className: "w-full rounded-xl bg-primary py-2 text-xs font-bold text-white shadow-xs hover:bg-primary/90 cursor-pointer flex items-center justify-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "שמור יעד מותאם למתאמן" })]
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2 text-center text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-primary/5 p-2 border border-primary/10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[10px] text-muted-foreground",
											children: "קלוריות"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-bold text-ink",
											children: [clientDetails?.nutritionDays?.[0]?.target_calories || 2e3, " kcal"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-emerald-50 p-2 border border-emerald-100",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[10px] text-emerald-600",
											children: "ימי מעקב"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-bold text-emerald-800",
											children: [clientDetails?.nutritionDays?.length || 0, " ימים"]
										})]
									})]
								})]
							})
						]
					})]
				}),
				showAddModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-sm rounded-3xl border border-white/80 bg-white p-6 shadow-2xl space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between border-b pb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-bold text-base text-ink flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-5 w-5 text-primary" }), " שיוך מתאמן חדש"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setShowAddModal(false),
									className: "text-muted-foreground hover:text-ink font-bold text-sm px-2 cursor-pointer",
									children: "✕"
								})]
							}),
							inviteMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `rounded-xl p-3 text-xs font-semibold border ${inviteMsg.includes("בהצלחה") ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-red-50 text-red-600 border-red-200"}`,
								children: inviteMsg
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleAddClient,
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-muted-foreground mb-1",
									children: "אימייל המתאמן הרשום במערכת"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									value: inviteEmail,
									onChange: (e) => setInviteEmail(e.target.value),
									className: "w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-primary",
									placeholder: "client@example.com"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "w-full rounded-2xl bg-primary py-2.5 text-sm font-bold text-white shadow-md hover:bg-primary/90 cursor-pointer",
									children: "שייך מתאמן לחשבוני"
								})]
							})
						]
					})
				})
			]
		})
	});
}
//#endregion
export { CoachDashboardPage as component };
