//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BNuqC3Qy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/src/routes/__root.tsx",
		children: [
			"/",
			"/coach",
			"/exercises/$exerciseId",
			"/programs/$programId",
			"/session/$workoutId",
			"/workouts/$workoutId",
			"/exercises/",
			"/nutrition/",
			"/programs/",
			"/workouts/",
			"/nutrition/foods/$foodId",
			"/nutrition/foods/"
		],
		css: ["/assets/index-B0cbc7E1.css"],
		preloads: [
			"/assets/index-hPE_G0sv.js",
			"/assets/link-yee4p_0-.js",
			"/assets/preload-helper-BjxpSAmc.js",
			"/assets/exercises._exerciseId-BeCc3ZKH.js",
			"/assets/programs._programId-Uc_F4C6Q.js",
			"/assets/session._workoutId-Djfy6GEg.js",
			"/assets/workouts._workoutId-DwH1fQcL.js",
			"/assets/nutrition.foods._foodId-CEXSpdSj.js",
			"/assets/programs._programId._dayId-DXupF51D.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-hPE_G0sv.js"
		} }]
	},
	"/": {
		filePath: "/app/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-bUTzK3Ht.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/chevron-left-Bket5n8Z.js",
			"/assets/flame-jblFR0GR.js",
			"/assets/message-square-C6s3uJNP.js",
			"/assets/play-C1GJrWKJ.js",
			"/assets/plus-uCm-h4KE.js",
			"/assets/utensils-BFPIkwNt.js",
			"/assets/primitives-D5LuL0I9.js"
		]
	},
	"/coach": {
		filePath: "/app/src/routes/coach.tsx",
		children: void 0,
		preloads: [
			"/assets/coach-D32HnGwa.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/award-0rcO9xJo.js",
			"/assets/chevron-left-Bket5n8Z.js",
			"/assets/message-square-C6s3uJNP.js",
			"/assets/plus-uCm-h4KE.js",
			"/assets/save-DOwPy-dO.js",
			"/assets/search-CFZW9Ii3.js",
			"/assets/trash-2-YR-wzKnZ.js"
		]
	},
	"/exercises/$exerciseId": {
		filePath: "/app/src/routes/exercises.$exerciseId.tsx",
		children: void 0,
		preloads: [
			"/assets/exercises._exerciseId-CcLwki1-.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/arrow-right-vwfY00jK.js",
			"/assets/check-BlPOCqKX.js",
			"/assets/pencil-BKki-UVz.js",
			"/assets/save-DOwPy-dO.js",
			"/assets/trash-2-YR-wzKnZ.js",
			"/assets/x-BYaubBQm.js",
			"/assets/primitives-D5LuL0I9.js"
		]
	},
	"/programs/$programId": {
		filePath: "/app/src/routes/programs.$programId.tsx",
		children: ["/programs/$programId/$dayId"],
		preloads: [
			"/assets/programs._programId-C0Nsl7Cz.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/arrow-right-vwfY00jK.js",
			"/assets/grip-vertical-DNlZ6iKt.js",
			"/assets/pencil-BKki-UVz.js",
			"/assets/play-C1GJrWKJ.js",
			"/assets/plus-uCm-h4KE.js",
			"/assets/save-DOwPy-dO.js",
			"/assets/trash-2-YR-wzKnZ.js",
			"/assets/x-BYaubBQm.js",
			"/assets/primitives-D5LuL0I9.js",
			"/assets/sortable.esm-D6X6Ol3k.js",
			"/assets/ConfirmSheet-O5ouLyqC.js"
		]
	},
	"/session/$workoutId": {
		filePath: "/app/src/routes/session.$workoutId.tsx",
		children: void 0,
		preloads: [
			"/assets/session._workoutId-DciLfqPo.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/award-0rcO9xJo.js",
			"/assets/check-BlPOCqKX.js",
			"/assets/Stepper-iFyn65nM.js",
			"/assets/play-C1GJrWKJ.js",
			"/assets/sparkles-DgFTihfE.js",
			"/assets/x-BYaubBQm.js",
			"/assets/zap-BXHyPPEJ.js",
			"/assets/primitives-D5LuL0I9.js",
			"/assets/ConfirmSheet-O5ouLyqC.js"
		]
	},
	"/workouts/$workoutId": {
		filePath: "/app/src/routes/workouts.$workoutId.tsx",
		children: void 0,
		preloads: [
			"/assets/workouts._workoutId-Pq6bSibv.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/arrow-right-vwfY00jK.js",
			"/assets/grip-vertical-DNlZ6iKt.js",
			"/assets/Stepper-iFyn65nM.js",
			"/assets/plus-uCm-h4KE.js",
			"/assets/trash-2-YR-wzKnZ.js",
			"/assets/x-BYaubBQm.js"
		]
	},
	"/exercises/": {
		filePath: "/app/src/routes/exercises.index.tsx",
		children: void 0,
		preloads: [
			"/assets/exercises.index-Brq1V2l6.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/chevron-left-Bket5n8Z.js",
			"/assets/plus-uCm-h4KE.js",
			"/assets/search-CFZW9Ii3.js",
			"/assets/sliders-horizontal-DN9tU0qH.js",
			"/assets/primitives-D5LuL0I9.js"
		]
	},
	"/nutrition/": {
		filePath: "/app/src/routes/nutrition.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.index-kJulzzN2.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/arrow-left-DgaAc-YO.js",
			"/assets/chevron-left-Bket5n8Z.js",
			"/assets/Stepper-iFyn65nM.js",
			"/assets/plus-uCm-h4KE.js",
			"/assets/shuffle-BY3ypF2b.js",
			"/assets/sparkles-DgFTihfE.js",
			"/assets/trash-2-YR-wzKnZ.js",
			"/assets/utensils-BFPIkwNt.js",
			"/assets/x-BYaubBQm.js",
			"/assets/zap-BXHyPPEJ.js",
			"/assets/primitives-D5LuL0I9.js"
		]
	},
	"/programs/": {
		filePath: "/app/src/routes/programs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/programs.index-DwXteopI.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/arrow-left-DgaAc-YO.js",
			"/assets/plus-uCm-h4KE.js",
			"/assets/sparkles-DgFTihfE.js",
			"/assets/trash-2-YR-wzKnZ.js",
			"/assets/x-BYaubBQm.js",
			"/assets/primitives-D5LuL0I9.js",
			"/assets/ConfirmSheet-O5ouLyqC.js"
		]
	},
	"/workouts/": {
		filePath: "/app/src/routes/workouts.index.tsx",
		children: void 0,
		preloads: [
			"/assets/workouts.index-ChQFRdZ5.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js"
		]
	},
	"/nutrition/foods/$foodId": {
		filePath: "/app/src/routes/nutrition.foods.$foodId.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.foods._foodId-BwAsmm2p.js",
			"/assets/useNavigate-B4W8BEpo.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/arrow-right-vwfY00jK.js",
			"/assets/check-BlPOCqKX.js",
			"/assets/Stepper-iFyn65nM.js",
			"/assets/shuffle-BY3ypF2b.js",
			"/assets/trash-2-YR-wzKnZ.js",
			"/assets/primitives-D5LuL0I9.js"
		]
	},
	"/programs/$programId/$dayId": {
		filePath: "/app/src/routes/programs.$programId.$dayId.tsx",
		children: void 0,
		preloads: [
			"/assets/programs._programId._dayId-BbaxdxGd.js",
			"/assets/flame-jblFR0GR.js",
			"/assets/Stepper-iFyn65nM.js",
			"/assets/search-CFZW9Ii3.js",
			"/assets/sliders-horizontal-DN9tU0qH.js"
		]
	},
	"/nutrition/foods/": {
		filePath: "/app/src/routes/nutrition.foods.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nutrition.foods.index-zQxW-S_A.js",
			"/assets/AppShell-vK154XkK.js",
			"/assets/arrow-right-vwfY00jK.js",
			"/assets/plus-uCm-h4KE.js",
			"/assets/search-CFZW9Ii3.js",
			"/assets/primitives-D5LuL0I9.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
